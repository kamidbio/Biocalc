
-- Add missing columns to the profiles table
ALTER TABLE public.profiles 
ADD COLUMN age INTEGER,
ADD COLUMN weight NUMERIC,
ADD COLUMN height NUMERIC,
ADD COLUMN phone TEXT;
