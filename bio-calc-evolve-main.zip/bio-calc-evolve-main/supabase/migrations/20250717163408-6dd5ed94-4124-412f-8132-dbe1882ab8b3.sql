-- Create comprehensive admin privileges and global app settings
-- This will replace and enhance the existing admin_settings table

-- First, let's add more comprehensive settings to admin_settings table
ALTER TABLE public.admin_settings ADD COLUMN IF NOT EXISTS category TEXT DEFAULT 'general';
ALTER TABLE public.admin_settings ADD COLUMN IF NOT EXISTS priority INTEGER DEFAULT 0;
ALTER TABLE public.admin_settings ADD COLUMN IF NOT EXISTS affects_frontend BOOLEAN DEFAULT true;
ALTER TABLE public.admin_settings ADD COLUMN IF NOT EXISTS affects_backend BOOLEAN DEFAULT false;

-- Insert comprehensive admin privilege settings
INSERT INTO public.admin_settings (setting_key, setting_value, description, category, priority, affects_frontend, affects_backend, is_active) VALUES
('maintenance_mode', '{"enabled": false, "message": "System is under maintenance. Please try again later.", "allowed_roles": ["admin"], "estimated_duration": null}'::jsonb, 'Global maintenance mode settings', 'system', 100, true, true, true),
('app_name', '"PeptideCalc Pro"'::jsonb, 'Application name displayed throughout the app', 'branding', 90, true, false, true),
('app_logo_url', '""'::jsonb, 'URL to the main application logo', 'branding', 90, true, false, true),
('app_theme', '{"primary_color": "hsl(var(--primary))", "secondary_color": "hsl(var(--secondary))", "dark_mode_enabled": true}'::jsonb, 'Global theme settings', 'appearance', 80, true, false, true),
('user_registration_enabled', 'true'::jsonb, 'Allow new user registrations', 'security', 85, true, true, true),
('calculator_enabled', 'true'::jsonb, 'Enable/disable calculator functionality', 'features', 70, true, false, true),
('education_enabled', 'true'::jsonb, 'Enable/disable education section', 'features', 70, true, false, true),
('protocols_enabled', 'true'::jsonb, 'Enable/disable protocols section', 'features', 70, true, false, true),
('tracking_enabled', 'true'::jsonb, 'Enable/disable tracking functionality', 'features', 70, true, false, true),
('max_calculations_per_user', '100'::jsonb, 'Maximum calculations allowed per user', 'limits', 60, false, true, true),
('max_file_size_mb', '10'::jsonb, 'Maximum file upload size in MB', 'limits', 60, true, true, true),
('session_timeout_minutes', '1440'::jsonb, 'User session timeout in minutes', 'security', 75, false, true, true),
('global_announcement', '{"enabled": false, "message": "", "type": "info", "dismissible": true}'::jsonb, 'Global announcement banner', 'notifications', 95, true, false, true),
('contact_email', '"support@peptidecalc.com"'::jsonb, 'Support contact email', 'contact', 50, true, false, true),
('privacy_policy_url', '""'::jsonb, 'URL to privacy policy', 'legal', 40, true, false, true),
('terms_of_service_url', '""'::jsonb, 'URL to terms of service', 'legal', 40, true, false, true),
('backup_enabled', 'true'::jsonb, 'Enable automatic data backups', 'system', 30, false, true, true),
('audit_logging_enabled', 'true'::jsonb, 'Enable comprehensive audit logging', 'security', 80, false, true, true),
('password_requirements', '{"min_length": 8, "require_uppercase": true, "require_lowercase": true, "require_numbers": true, "require_special": false}'::jsonb, 'Password complexity requirements', 'security', 75, true, true, true),
('rate_limiting', '{"enabled": true, "requests_per_minute": 60, "burst_limit": 100}'::jsonb, 'API rate limiting settings', 'security', 70, false, true, true),
('feature_flags', '{"beta_features": false, "experimental_ui": false, "advanced_analytics": false}'::jsonb, 'Feature flag toggles', 'features', 65, true, true, true)
ON CONFLICT (setting_key) DO UPDATE SET
  setting_value = EXCLUDED.setting_value,
  description = EXCLUDED.description,
  category = EXCLUDED.category,
  priority = EXCLUDED.priority,
  affects_frontend = EXCLUDED.affects_frontend,
  affects_backend = EXCLUDED.affects_backend,
  updated_at = now();

-- Create a view for easy access to active settings by category
CREATE OR REPLACE VIEW public.admin_settings_by_category AS
SELECT 
  category,
  jsonb_object_agg(setting_key, setting_value) as settings,
  array_agg(setting_key ORDER BY priority DESC) as setting_keys,
  max(updated_at) as last_updated
FROM public.admin_settings 
WHERE is_active = true 
GROUP BY category;

-- Create function to get all active settings as a single JSON object
CREATE OR REPLACE FUNCTION public.get_active_admin_settings()
RETURNS jsonb
LANGUAGE sql
STABLE SECURITY DEFINER
AS $$
  SELECT jsonb_object_agg(setting_key, setting_value)
  FROM public.admin_settings 
  WHERE is_active = true;
$$;

-- Create function to check if a feature is enabled
CREATE OR REPLACE FUNCTION public.is_feature_enabled(feature_key text)
RETURNS boolean
LANGUAGE sql
STABLE SECURITY DEFINER
AS $$
  SELECT COALESCE(
    (setting_value)::boolean, 
    true
  )
  FROM public.admin_settings 
  WHERE setting_key = feature_key AND is_active = true;
$$;

-- Create function to get maintenance mode status
CREATE OR REPLACE FUNCTION public.get_maintenance_status()
RETURNS jsonb
LANGUAGE sql
STABLE SECURITY DEFINER
AS $$
  SELECT COALESCE(
    setting_value,
    '{"enabled": false}'::jsonb
  )
  FROM public.admin_settings 
  WHERE setting_key = 'maintenance_mode' AND is_active = true;
$$;

-- Add index for better performance
CREATE INDEX IF NOT EXISTS idx_admin_settings_category ON public.admin_settings(category);
CREATE INDEX IF NOT EXISTS idx_admin_settings_priority ON public.admin_settings(priority DESC);
CREATE INDEX IF NOT EXISTS idx_admin_settings_affects ON public.admin_settings(affects_frontend, affects_backend);