
-- Create enum for user roles
CREATE TYPE public.user_role AS ENUM ('admin', 'user');

-- Create user_roles table to manage role assignments
CREATE TABLE public.user_roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  role user_role NOT NULL DEFAULT 'user',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  UNIQUE(user_id)
);

-- Enable RLS on user_roles
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

-- Create security definer function to check user roles
CREATE OR REPLACE FUNCTION public.get_user_role(user_uuid UUID)
RETURNS user_role
LANGUAGE SQL
SECURITY DEFINER
STABLE
AS $$
  SELECT role FROM public.user_roles WHERE user_id = user_uuid;
$$;

-- Create function to check if user is admin
CREATE OR REPLACE FUNCTION public.is_admin(user_uuid UUID)
RETURNS BOOLEAN
LANGUAGE SQL
SECURITY DEFINER
STABLE
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.user_roles 
    WHERE user_id = user_uuid AND role = 'admin'
  );
$$;

-- RLS policies for user_roles
CREATE POLICY "Admins can view all user roles" ON public.user_roles
  FOR SELECT USING (public.is_admin(auth.uid()));

CREATE POLICY "Admins can insert user roles" ON public.user_roles
  FOR INSERT WITH CHECK (public.is_admin(auth.uid()));

CREATE POLICY "Admins can update user roles" ON public.user_roles
  FOR UPDATE USING (public.is_admin(auth.uid()));

CREATE POLICY "Users can view their own role" ON public.user_roles
  FOR SELECT USING (auth.uid() = user_id);

-- Create pages management table
CREATE TABLE public.pages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  slug TEXT UNIQUE NOT NULL,
  title TEXT NOT NULL,
  content JSONB,
  layout_config JSONB,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  created_by UUID REFERENCES auth.users(id)
);

ALTER TABLE public.pages ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view active pages" ON public.pages
  FOR SELECT USING (is_active = true);

CREATE POLICY "Admins can manage all pages" ON public.pages
  FOR ALL USING (public.is_admin(auth.uid()));

-- Create library resources table
CREATE TABLE public.library_resources (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title TEXT NOT NULL,
  description TEXT,
  content JSONB,
  category TEXT,
  tags TEXT[],
  stacks JSONB,
  frequencies JSONB,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  created_by UUID REFERENCES auth.users(id)
);

ALTER TABLE public.library_resources ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view active library resources" ON public.library_resources
  FOR SELECT USING (is_active = true);

CREATE POLICY "Admins can manage all library resources" ON public.library_resources
  FOR ALL USING (public.is_admin(auth.uid()));

-- Create protocols table for saved protocols
CREATE TABLE public.protocols (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  peptide_data JSONB NOT NULL,
  calculator_settings JSONB,
  schedule JSONB,
  notes TEXT,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

ALTER TABLE public.protocols ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their own protocols" ON public.protocols
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can manage their own protocols" ON public.protocols
  FOR ALL USING (auth.uid() = user_id);

CREATE POLICY "Admins can view all protocols" ON public.protocols
  FOR SELECT USING (public.is_admin(auth.uid()));

CREATE POLICY "Admins can manage all protocols" ON public.protocols
  FOR ALL USING (public.is_admin(auth.uid()));

-- Create health logs table
CREATE TABLE public.health_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  log_type TEXT NOT NULL,
  value NUMERIC,
  unit TEXT,
  notes TEXT,
  logged_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

ALTER TABLE public.health_logs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their own health logs" ON public.health_logs
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can manage their own health logs" ON public.health_logs
  FOR ALL USING (auth.uid() = user_id);

CREATE POLICY "Admins can view all health logs" ON public.health_logs
  FOR SELECT USING (public.is_admin(auth.uid()));

CREATE POLICY "Admins can manage all health logs" ON public.health_logs
  FOR ALL USING (public.is_admin(auth.uid()));

-- Create calculator settings table
CREATE TABLE public.calculator_settings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  setting_key TEXT UNIQUE NOT NULL,
  setting_value JSONB NOT NULL,
  description TEXT,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

ALTER TABLE public.calculator_settings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view active calculator settings" ON public.calculator_settings
  FOR SELECT USING (is_active = true);

CREATE POLICY "Admins can manage calculator settings" ON public.calculator_settings
  FOR ALL USING (public.is_admin(auth.uid()));

-- Create admin audit logs table
CREATE TABLE public.admin_audit_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  admin_user_id UUID REFERENCES auth.users(id) NOT NULL,
  action TEXT NOT NULL,
  target_table TEXT,
  target_id UUID,
  old_data JSONB,
  new_data JSONB,
  ip_address INET,
  user_agent TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

ALTER TABLE public.admin_audit_logs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can view audit logs" ON public.admin_audit_logs
  FOR SELECT USING (public.is_admin(auth.uid()));

-- Create trigger function to automatically assign user role on signup
CREATE OR REPLACE FUNCTION public.handle_new_user_role()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = ''
AS $$
BEGIN
  INSERT INTO public.user_roles (user_id, role)
  VALUES (NEW.id, 'user');
  RETURN NEW;
END;
$$;

-- Create trigger for new user role assignment
CREATE OR REPLACE TRIGGER on_auth_user_created_role
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user_role();

-- Insert default calculator settings
INSERT INTO public.calculator_settings (setting_key, setting_value, description) VALUES
  ('default_syringe_settings', '{"type": "1ml", "units": "ml", "tick_marks": 100, "volume": 1}', 'Default syringe configuration'),
  ('default_vial_settings', '{"water_amount": 2, "peptide_amount": 10}', 'Default vial configuration'),
  ('dosage_units', '["mg", "mcg", "iu", "units"]', 'Available dosage units'),
  ('syringe_types', '["0.3ml", "0.5ml", "1ml", "3ml", "5ml"]', 'Available syringe types');

-- Insert sample library resources
INSERT INTO public.library_resources (title, description, content, category, tags) VALUES
  ('Peptide Cheat Sheet', 'Comprehensive guide to peptide usage and protocols', '{"sections": [{"title": "Basic Peptides", "content": "Overview of common peptides and their applications"}]}', 'reference', ARRAY['peptides', 'reference', 'guide']),
  ('MEAFY Protocol', 'Metabolic Enhancement and Fat Yield protocol guide', '{"protocol": {"description": "Advanced metabolic protocol", "steps": []}}', 'protocol', ARRAY['metabolism', 'protocol', 'advanced']),
  ('Blueprint Basics', 'Foundation protocols for optimization', '{"basics": {"overview": "Essential protocols for beginners"}}', 'protocol', ARRAY['beginner', 'foundation', 'protocol']);

-- Insert sample pages
INSERT INTO public.pages (slug, title, content, layout_config) VALUES
  ('home', 'Home Page', '{"hero": {"title": "B.I.O | CALC", "subtitle": "Your Optimization Journey Starts Here"}, "sections": []}', '{"layout": "hero_with_sections"}'),
  ('calculator', 'Peptide Calculator', '{"title": "Peptide Calculator", "description": "Calculate precise dosages for your protocols"}', '{"layout": "calculator_layout"}'),
  ('protocols', 'Protocols', '{"title": "Protocols", "description": "Manage and track your optimization protocols"}', '{"layout": "protocols_layout"}'),
  ('education', 'Education Hub', '{"title": "Education Hub", "description": "Learn about peptides and optimization"}', '{"layout": "education_layout"}');
