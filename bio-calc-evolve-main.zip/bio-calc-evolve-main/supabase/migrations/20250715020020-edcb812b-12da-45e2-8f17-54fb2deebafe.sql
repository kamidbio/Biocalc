
-- Create storage bucket for education files
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'education-files',
  'education-files',
  true,
  52428800, -- 50MB limit
  ARRAY[
    'video/mp4', 'video/avi', 'video/mov', 'video/wmv', 'video/webm',
    'audio/mp3', 'audio/wav', 'audio/ogg', 'audio/m4a', 'audio/flac',
    'application/pdf',
    'application/msword',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'application/vnd.ms-excel',
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    'application/vnd.ms-powerpoint',
    'application/vnd.openxmlformats-officedocument.presentationml.presentation',
    'text/plain',
    'image/jpeg', 'image/png', 'image/gif', 'image/webp'
  ]
);

-- Create storage policies for education files
CREATE POLICY "Anyone can view education files"
ON storage.objects FOR SELECT
USING (bucket_id = 'education-files');

CREATE POLICY "Admins can upload education files"
ON storage.objects FOR INSERT
WITH CHECK (bucket_id = 'education-files' AND is_admin(auth.uid()));

CREATE POLICY "Admins can update education files"
ON storage.objects FOR UPDATE
USING (bucket_id = 'education-files' AND is_admin(auth.uid()));

CREATE POLICY "Admins can delete education files"
ON storage.objects FOR DELETE
USING (bucket_id = 'education-files' AND is_admin(auth.uid()));

-- Create admin registration tokens table
CREATE TABLE public.admin_registration_tokens (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  token TEXT NOT NULL UNIQUE,
  created_by UUID REFERENCES auth.users(id),
  used_by UUID REFERENCES auth.users(id),
  expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
  is_used BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS on admin registration tokens
ALTER TABLE public.admin_registration_tokens ENABLE ROW LEVEL SECURITY;

-- Create policy for admin registration tokens
CREATE POLICY "Admins can manage registration tokens"
ON public.admin_registration_tokens
FOR ALL
USING (is_admin(auth.uid()));

-- Update library_resources to include file_url and file_type
ALTER TABLE public.library_resources 
ADD COLUMN file_url TEXT,
ADD COLUMN file_type TEXT,
ADD COLUMN file_size BIGINT;

-- Create updated_at trigger for admin_registration_tokens
CREATE TRIGGER update_admin_registration_tokens_updated_at
  BEFORE UPDATE ON public.admin_registration_tokens
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();
