-- Create calculator_calculations table to store user calculations
CREATE TABLE public.calculator_calculations (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid NOT NULL,
  calculation_name text,
  syringe_type text NOT NULL,
  syringe_units numeric,
  syringe_volume numeric,
  water_amount numeric NOT NULL,
  peptide_amount numeric NOT NULL,
  desired_dose numeric NOT NULL,
  calculated_draw_units numeric,
  calculated_draw_volume numeric,
  calculated_concentration numeric,
  calculated_remaining_doses integer,
  notes text,
  is_favorite boolean DEFAULT false,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.calculator_calculations ENABLE ROW LEVEL SECURITY;

-- Create policies for calculator calculations
CREATE POLICY "Users can view their own calculations" 
ON public.calculator_calculations 
FOR SELECT 
USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own calculations" 
ON public.calculator_calculations 
FOR INSERT 
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own calculations" 
ON public.calculator_calculations 
FOR UPDATE 
USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own calculations" 
ON public.calculator_calculations 
FOR DELETE 
USING (auth.uid() = user_id);

CREATE POLICY "Admins can manage all calculations" 
ON public.calculator_calculations 
FOR ALL 
USING (is_admin(auth.uid()));

-- Create calculator_presets table for common peptide configurations
CREATE TABLE public.calculator_presets (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  peptide_name text NOT NULL,
  common_dosages jsonb NOT NULL, -- Array of common dosage amounts
  typical_concentration numeric,
  recommended_syringe_type text,
  description text,
  category text DEFAULT 'general',
  is_active boolean DEFAULT true,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now(),
  created_by uuid
);

-- Enable RLS for presets
ALTER TABLE public.calculator_presets ENABLE ROW LEVEL SECURITY;

-- Create policies for calculator presets
CREATE POLICY "Anyone can view active presets" 
ON public.calculator_presets 
FOR SELECT 
USING (is_active = true);

CREATE POLICY "Admins can manage all presets" 
ON public.calculator_presets 
FOR ALL 
USING (is_admin(auth.uid()));

-- Insert common peptide presets
INSERT INTO public.calculator_presets (peptide_name, common_dosages, typical_concentration, recommended_syringe_type, description, category) VALUES
('BPC-157', '["0.25", "0.5", "1.0"]', 5.0, 'U-100', 'Body Protective Compound for healing and recovery', 'healing'),
('TB-500', '["2.0", "2.5", "5.0"]', 2.0, 'U-100', 'Thymosin Beta-4 for tissue repair and anti-inflammatory effects', 'healing'),
('PT-141', '["1.0", "2.0"]', 10.0, 'U-100', 'Bremelanotide for enhanced libido and sexual function', 'enhancement'),
('Melanotan II', '["0.25", "0.5", "1.0"]', 10.0, 'U-100', 'Peptide for tanning and appetite suppression', 'enhancement'),
('CJC-1295', '["0.1", "0.2", "0.3"]', 2.0, 'U-100', 'Growth hormone releasing hormone analog', 'growth'),
('Ipamorelin', '["0.1", "0.2", "0.3"]', 2.0, 'U-100', 'Growth hormone releasing peptide', 'growth'),
('GHK-Cu', '["1.0", "2.0", "3.0"]', 50.0, 'U-100', 'Copper peptide for skin and hair health', 'cosmetic'),
('AOD-9604', '["0.25", "0.5"]', 2.0, 'U-100', 'Anti-obesity drug for fat loss', 'weight'),
('Fragment 176-191', '["0.25", "0.5"]', 2.0, 'U-100', 'HGH fragment for fat burning', 'weight'),
('Selank', '["0.25", "0.5"]', 5.0, 'U-100', 'Nootropic peptide for cognitive enhancement', 'nootropic');

-- Create calculator_reminders table for dosing schedules
CREATE TABLE public.calculator_reminders (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid NOT NULL,
  calculation_id uuid REFERENCES public.calculator_calculations(id) ON DELETE CASCADE,
  reminder_name text NOT NULL,
  frequency_type text NOT NULL, -- 'daily', 'weekly', 'custom'
  frequency_value text, -- JSON for custom schedules
  next_reminder timestamp with time zone NOT NULL,
  is_active boolean DEFAULT true,
  notes text,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Enable RLS for reminders
ALTER TABLE public.calculator_reminders ENABLE ROW LEVEL SECURITY;

-- Create policies for calculator reminders
CREATE POLICY "Users can manage their own reminders" 
ON public.calculator_reminders 
FOR ALL 
USING (auth.uid() = user_id);

CREATE POLICY "Admins can view all reminders" 
ON public.calculator_reminders 
FOR SELECT 
USING (is_admin(auth.uid()));

-- Create trigger for updated_at timestamps
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Add triggers for updated_at
CREATE TRIGGER update_calculator_calculations_updated_at
  BEFORE UPDATE ON public.calculator_calculations
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_calculator_presets_updated_at
  BEFORE UPDATE ON public.calculator_presets
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_calculator_reminders_updated_at
  BEFORE UPDATE ON public.calculator_reminders
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();