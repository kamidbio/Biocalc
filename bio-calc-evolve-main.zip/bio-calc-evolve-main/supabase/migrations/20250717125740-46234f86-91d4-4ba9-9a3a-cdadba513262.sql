-- Find and promote user to admin role
-- First, let's update the user role to admin for the specified email
UPDATE user_roles 
SET role = 'admin', updated_at = now()
WHERE user_id = (
  SELECT id FROM profiles WHERE email = 'masteejoejoe@gmail.com'
);

-- If no existing role record, insert one
INSERT INTO user_roles (user_id, role)
SELECT id, 'admin'::user_role
FROM profiles 
WHERE email = 'masteejoejoe@gmail.com'
AND NOT EXISTS (
  SELECT 1 FROM user_roles WHERE user_id = profiles.id
);