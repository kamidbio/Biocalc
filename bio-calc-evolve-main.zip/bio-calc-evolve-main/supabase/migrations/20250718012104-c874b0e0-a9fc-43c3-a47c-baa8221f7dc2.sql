-- Create admin role for the existing user
INSERT INTO public.user_roles (user_id, role) 
VALUES ('47241e66-c149-4dd2-9be0-6753fc608f13', 'admin');