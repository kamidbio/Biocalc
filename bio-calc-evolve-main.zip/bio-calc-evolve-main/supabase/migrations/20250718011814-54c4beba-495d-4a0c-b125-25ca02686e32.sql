-- Add unique constraint to user_roles table if it doesn't exist
DO $$ 
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'user_roles_user_id_role_key'
    ) THEN
        ALTER TABLE public.user_roles 
        ADD CONSTRAINT user_roles_user_id_role_key UNIQUE (user_id, role);
    END IF;
END $$;

-- Create admin role for the existing user
INSERT INTO public.user_roles (user_id, role) 
VALUES ('47241e66-c149-4dd2-9be0-6753fc608f13', 'admin')
ON CONFLICT (user_id, role) DO NOTHING;