-- Create homepage sections table for dynamic content management
CREATE TABLE public.homepage_sections (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  title TEXT NOT NULL,
  content JSONB NOT NULL,
  section_type TEXT NOT NULL DEFAULT 'text',
  display_order INTEGER NOT NULL DEFAULT 0,
  is_active BOOLEAN NOT NULL DEFAULT true,
  layout_config JSONB,
  background_style JSONB,
  created_by UUID,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.homepage_sections ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Admins can manage all homepage sections" 
ON public.homepage_sections 
FOR ALL 
USING (is_admin(auth.uid()));

CREATE POLICY "Anyone can view active homepage sections" 
ON public.homepage_sections 
FOR SELECT 
USING (is_active = true);

-- Add trigger for timestamps
CREATE TRIGGER update_homepage_sections_updated_at
BEFORE UPDATE ON public.homepage_sections
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Insert default homepage sections
INSERT INTO public.homepage_sections (title, content, section_type, display_order, is_active) VALUES
('Welcome Section', '{"heading": "Welcome to PeptideCalc", "subheading": "Professional peptide dosage calculator", "description": "Calculate precise peptide dosages with our advanced calculator. Designed for healthcare professionals and researchers.", "showButton": true, "buttonText": "Get Started", "buttonLink": "/calculator"}', 'hero', 1, true),
('Features Section', '{"heading": "Key Features", "features": [{"title": "Precise Calculations", "description": "Advanced algorithms for accurate dosage calculations", "icon": "calculator"}, {"title": "Save & Track", "description": "Save calculations and track your protocols", "icon": "save"}, {"title": "Professional Tools", "description": "Built for healthcare professionals", "icon": "stethoscope"}]}', 'features', 2, true),
('About Section', '{"heading": "About PeptideCalc", "description": "Our platform provides healthcare professionals with reliable tools for peptide dosage calculations. Built with precision and safety in mind.", "image": "", "layout": "text-image"}', 'content', 3, true);