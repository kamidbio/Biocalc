
import React, { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { toast } from 'sonner';
import { Shield, UserPlus, AlertCircle, Loader } from 'lucide-react';

const AdminRegistration = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [tokenValid, setTokenValid] = useState(false);
  const [checkingToken, setCheckingToken] = useState(true);
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    confirmPassword: ''
  });

  const token = searchParams.get('token');

  useEffect(() => {
    console.log('AdminRegistration: Component mounted');
    console.log('AdminRegistration: Token from URL:', token);
    console.log('AdminRegistration: Current user:', user);

    if (user) {
      console.log('AdminRegistration: User already logged in, redirecting to home');
      navigate('/');
      return;
    }
    
    if (token) {
      console.log('AdminRegistration: Token found, validating...');
      validateToken();
    } else {
      console.log('AdminRegistration: No token found');
      setCheckingToken(false);
    }
  }, [user, token, navigate]);

  const validateToken = async () => {
    console.log('AdminRegistration: Starting token validation for token:', token);
    try {
      const { data, error } = await supabase
        .from('admin_registration_tokens')
        .select('*')
        .eq('token', token)
        .eq('is_used', false)
        .gte('expires_at', new Date().toISOString())
        .maybeSingle();

      console.log('AdminRegistration: Token validation response:', { data, error });

      if (error) {
        console.error('AdminRegistration: Error validating token:', error);
        throw error;
      }
      
      if (data) {
        console.log('AdminRegistration: Token is valid');
        setTokenValid(true);
        toast.success('Valid registration token found');
      } else {
        console.log('AdminRegistration: Token is invalid or expired');
        toast.error('Invalid or expired registration token');
      }
    } catch (error) {
      console.error('AdminRegistration: Error in token validation:', error);
      toast.error('Error validating registration token');
    } finally {
      setCheckingToken(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    console.log('AdminRegistration: Form submitted');
    
    if (formData.password !== formData.confirmPassword) {
      toast.error('Passwords do not match');
      return;
    }

    if (formData.password.length < 6) {
      toast.error('Password must be at least 6 characters long');
      return;
    }

    if (!tokenValid) {
      toast.error('Invalid registration token');
      return;
    }

    setLoading(true);
    console.log('AdminRegistration: Creating user account...');
    
    try {
      // Create the user account
      const { data: authData, error: authError } = await supabase.auth.signUp({
        email: formData.email,
        password: formData.password,
        options: {
          emailRedirectTo: `${window.location.origin}/`
        }
      });

      console.log('AdminRegistration: Auth signup response:', { authData, authError });

      if (authError) throw authError;

      if (authData.user) {
        console.log('AdminRegistration: User created, marking token as used...');
        
        // Mark token as used
        const { error: tokenError } = await supabase
          .from('admin_registration_tokens')
          .update({ 
            is_used: true, 
            used_by: authData.user.id 
          })
          .eq('token', token);

        if (tokenError) {
          console.error('AdminRegistration: Error marking token as used:', tokenError);
          throw tokenError;
        }

        console.log('AdminRegistration: Assigning admin role...');
        
        // Assign admin role
        const { error: roleError } = await supabase
          .from('user_roles')
          .upsert({ 
            user_id: authData.user.id, 
            role: 'admin' 
          });

        if (roleError) {
          console.error('AdminRegistration: Error assigning admin role:', roleError);
          throw roleError;
        }

        console.log('AdminRegistration: Admin account created successfully');
        toast.success('Admin account created successfully! Please check your email to verify your account.');
        
        // Redirect after a short delay
        setTimeout(() => {
          navigate('/auth');
        }, 2000);
      }
    } catch (error) {
      console.error('AdminRegistration: Error creating admin account:', error);
      toast.error(`Failed to create admin account: ${error.message || 'Unknown error'}`);
    } finally {
      setLoading(false);
    }
  };

  if (checkingToken) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-purple-950 via-indigo-950 to-purple-900 p-6">
        <div className="text-center support-card p-8">
          <Loader className="h-12 w-12 mx-auto mb-4 text-purple-400 animate-spin" />
          <p className="text-purple-200">Validating registration token...</p>
        </div>
      </div>
    );
  }

  if (!token || !tokenValid) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-purple-950 via-indigo-950 to-purple-900 p-6">
        <Card className="w-full max-w-md support-card border-red-500/30">
          <CardHeader className="text-center">
            <AlertCircle className="h-12 w-12 mx-auto mb-4 text-red-400" />
            <CardTitle className="text-red-300">Invalid Registration Link</CardTitle>
            <CardDescription className="text-purple-300/80">
              This registration link is invalid, expired, or has already been used. Please contact an administrator for a new link.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button 
              onClick={() => navigate('/auth')} 
              className="w-full bg-purple-600 hover:bg-purple-700"
            >
              Go to Sign In
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-purple-950 via-indigo-950 to-purple-900 p-6">
      <Card className="w-full max-w-md support-card border-purple-400/30">
        <CardHeader className="text-center">
          <Shield className="h-12 w-12 mx-auto mb-4 text-purple-400" />
          <CardTitle className="text-2xl text-purple-200">Admin Registration</CardTitle>
          <CardDescription className="text-purple-300/80">
            Create your administrator account using the valid token
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <Label htmlFor="email" className="text-purple-300">Email Address</Label>
              <Input
                id="email"
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                className="bg-purple-950/50 border-purple-400/30 text-purple-100 placeholder:text-purple-400/60"
                placeholder="Enter your email"
                required
              />
            </div>
            <div>
              <Label htmlFor="password" className="text-purple-300">Password</Label>
              <Input
                id="password"
                type="password"
                value={formData.password}
                onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                className="bg-purple-950/50 border-purple-400/30 text-purple-100 placeholder:text-purple-400/60"
                placeholder="Create a password"
                required
                minLength={6}
              />
            </div>
            <div>
              <Label htmlFor="confirmPassword" className="text-purple-300">Confirm Password</Label>
              <Input
                id="confirmPassword"
                type="password"
                value={formData.confirmPassword}
                onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
                className="bg-purple-950/50 border-purple-400/30 text-purple-100 placeholder:text-purple-400/60"
                placeholder="Confirm your password"
                required
                minLength={6}
              />
            </div>
            <Button 
              type="submit" 
              className="w-full bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white"
              disabled={loading}
            >
              {loading ? (
                <>
                  <Loader className="h-4 w-4 mr-2 animate-spin" />
                  Creating Account...
                </>
              ) : (
                <>
                  <UserPlus className="h-4 w-4 mr-2" />
                  Create Admin Account
                </>
              )}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
};

export default AdminRegistration;
