
import React from 'react';
import { Calculator, Activity, BookOpen, Settings } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const Index = () => {
  const navigate = useNavigate();

  const features = [
    {
      icon: Calculator,
      title: "Peptide Calculator",
      description: "Calculate precise dosages and dilutions",
      action: () => navigate('/calculator')
    },
    {
      icon: Activity,
      title: "Health Tracking",
      description: "Monitor your progress and metrics",
      action: () => navigate('/tracking')
    },
    {
      icon: BookOpen,
      title: "Protocols & Education", 
      description: "Learn about peptides and protocols",
      action: () => navigate('/protocols')
    },
    {
      icon: Settings,
      title: "Settings & Support",
      description: "Customize your experience",
      action: () => navigate('/settings')
    }
  ];

  return (
    <div className="min-h-screen homepage-gradient relative overflow-hidden">
      {/* Animated background elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-20 left-10 w-32 h-32 bg-purple-500/20 rounded-full blur-xl animate-pulse"></div>
        <div className="absolute bottom-32 right-16 w-24 h-24 bg-blue-500/20 rounded-full blur-lg animate-pulse delay-700"></div>
        <div className="absolute top-1/3 right-8 w-16 h-16 bg-pink-500/20 rounded-full blur-md animate-pulse delay-1000"></div>
      </div>

      {/* Main content */}
      <div className="relative z-10 flex flex-col items-center justify-center min-h-screen p-4">
        {/* App title */}
        <div className="text-center mb-8">
          <h1 className="text-5xl md:text-6xl font-black mb-2 homepage-title-glow">
            BIO CALC
          </h1>
          <div className="w-16 h-1 bg-gradient-to-r from-purple-400 to-blue-400 mx-auto rounded-full"></div>
        </div>

        {/* Main card */}
        <div className="homepage-card w-full max-w-sm mx-auto p-6 space-y-4">
          {features.map((feature, index) => (
            <button
              key={index}
              onClick={feature.action}
              className="w-full p-4 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 hover:border-white/20 transition-all duration-300 group text-left backdrop-blur-sm"
            >
              <div className="flex items-center space-x-3">
                <div className="p-2 rounded-lg bg-gradient-to-br from-purple-500/20 to-blue-500/20 group-hover:from-purple-500/30 group-hover:to-blue-500/30 transition-all duration-300">
                  <feature.icon className="w-5 h-5 text-white/90" />
                </div>
                <div>
                  <h3 className="font-semibold text-white/90 text-sm">{feature.title}</h3>
                  <p className="text-xs text-white/60 leading-relaxed">{feature.description}</p>
                </div>
              </div>
            </button>
          ))}
        </div>

        {/* Assistant character placeholder */}
        <div className="absolute bottom-8 left-8">
          <div className="w-16 h-16 rounded-full bg-gradient-to-br from-purple-500 to-blue-500 flex items-center justify-center animate-bounce shadow-lg">
            <div className="w-3 h-3 bg-white rounded-full"></div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Index;
