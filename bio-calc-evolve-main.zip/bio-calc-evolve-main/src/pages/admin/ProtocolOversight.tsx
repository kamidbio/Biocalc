
import React, { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAdmin } from '@/hooks/useAdmin';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { toast } from 'sonner';
import { FileCheck, Eye, Edit, Trash2, Users, Calendar, Activity } from 'lucide-react';

interface Protocol {
  id: string;
  name: string;
  peptide_data: any;
  schedule: any;
  notes: string;
  is_active: boolean;
  user_id: string;
  created_at: string;
  updated_at: string;
  calculator_settings: any;
}

interface ProtocolStats {
  total_protocols: number;
  active_protocols: number;
  inactive_protocols: number;
  total_users_with_protocols: number;
}

const ProtocolOversight = () => {
  const [protocols, setProtocols] = useState<Protocol[]>([]);
  const [stats, setStats] = useState<ProtocolStats>({
    total_protocols: 0,
    active_protocols: 0,
    inactive_protocols: 0,
    total_users_with_protocols: 0
  });
  const [loading, setLoading] = useState(true);
  const [selectedProtocol, setSelectedProtocol] = useState<Protocol | null>(null);
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false);
  const { logAdminAction } = useAdmin();

  useEffect(() => {
    fetchProtocols();
    fetchStats();
  }, []);

  const fetchProtocols = async () => {
    try {
      const { data, error } = await supabase
        .from('protocols')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setProtocols(data || []);
    } catch (error) {
      console.error('Error fetching protocols:', error);
      toast.error('Failed to fetch protocols');
    } finally {
      setLoading(false);
    }
  };

  const fetchStats = async () => {
    try {
      const { data: allProtocols, error: protocolsError } = await supabase
        .from('protocols')
        .select('id, is_active, user_id');

      if (protocolsError) throw protocolsError;

      const totalProtocols = allProtocols?.length || 0;
      const activeProtocols = allProtocols?.filter(p => p.is_active).length || 0;
      const inactiveProtocols = totalProtocols - activeProtocols;
      const uniqueUsers = new Set(allProtocols?.map(p => p.user_id)).size;

      setStats({
        total_protocols: totalProtocols,
        active_protocols: activeProtocols,
        inactive_protocols: inactiveProtocols,
        total_users_with_protocols: uniqueUsers
      });
    } catch (error) {
      console.error('Error fetching stats:', error);
    }
  };

  const toggleProtocolStatus = async (protocol: Protocol) => {
    try {
      const newStatus = !protocol.is_active;
      const { error } = await supabase
        .from('protocols')
        .update({ is_active: newStatus })
        .eq('id', protocol.id);

      if (error) throw error;

      await logAdminAction(
        'UPDATE_PROTOCOL_STATUS',
        'protocols',
        protocol.id,
        { is_active: protocol.is_active },
        { is_active: newStatus }
      );

      setProtocols(prev => prev.map(p => 
        p.id === protocol.id ? { ...p, is_active: newStatus } : p
      ));

      toast.success(`Protocol ${newStatus ? 'activated' : 'deactivated'}`);
      fetchStats();
    } catch (error) {
      console.error('Error updating protocol status:', error);
      toast.error('Failed to update protocol status');
    }
  };

  const deleteProtocol = async (protocol: Protocol) => {
    if (!confirm('Are you sure you want to delete this protocol?')) return;

    try {
      const { error } = await supabase
        .from('protocols')
        .delete()
        .eq('id', protocol.id);

      if (error) throw error;

      await logAdminAction(
        'DELETE_PROTOCOL',
        'protocols',
        protocol.id,
        protocol,
        null
      );

      setProtocols(prev => prev.filter(p => p.id !== protocol.id));
      toast.success('Protocol deleted successfully');
      fetchStats();
    } catch (error) {
      console.error('Error deleting protocol:', error);
      toast.error('Failed to delete protocol');
    }
  };

  const viewProtocol = (protocol: Protocol) => {
    setSelectedProtocol(protocol);
    setIsViewDialogOpen(true);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="text-center">
          <FileCheck className="h-12 w-12 mx-auto mb-4 text-purple-400 animate-pulse" />
          <p className="text-purple-300">Loading protocols...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold text-white mb-2">Protocol Oversight</h2>
        <p className="text-purple-300">Monitor and manage user protocols across the platform</p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="glass-card">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-purple-300">Total Protocols</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-white">{stats.total_protocols}</div>
          </CardContent>
        </Card>

        <Card className="glass-card">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-purple-300">Active Protocols</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-400">{stats.active_protocols}</div>
          </CardContent>
        </Card>

        <Card className="glass-card">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-purple-300">Inactive Protocols</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-400">{stats.inactive_protocols}</div>
          </CardContent>
        </Card>

        <Card className="glass-card">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-purple-300">Users with Protocols</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-400">{stats.total_users_with_protocols}</div>
          </CardContent>
        </Card>
      </div>

      {/* Protocols Table */}
      <div className="glass-card rounded-xl p-6">
        <Table>
          <TableHeader>
            <TableRow className="border-purple-400/20">
              <TableHead className="text-purple-300">Protocol Name</TableHead>
              <TableHead className="text-purple-300">Status</TableHead>
              <TableHead className="text-purple-300">User ID</TableHead>
              <TableHead className="text-purple-300">Created</TableHead>
              <TableHead className="text-purple-300">Updated</TableHead>
              <TableHead className="text-purple-300">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {protocols.map((protocol) => (
              <TableRow key={protocol.id} className="border-purple-400/10">
                <TableCell className="text-white font-medium">{protocol.name}</TableCell>
                <TableCell>
                  <Badge 
                    variant={protocol.is_active ? 'default' : 'secondary'}
                    className={protocol.is_active 
                      ? 'bg-green-500/20 text-green-300' 
                      : 'bg-gray-500/20 text-gray-300'
                    }
                  >
                    {protocol.is_active ? 'Active' : 'Inactive'}
                  </Badge>
                </TableCell>
                <TableCell className="text-purple-300 font-mono text-sm">
                  {protocol.user_id.substring(0, 8)}...
                </TableCell>
                <TableCell className="text-purple-300">
                  {new Date(protocol.created_at).toLocaleDateString()}
                </TableCell>
                <TableCell className="text-purple-300">
                  {new Date(protocol.updated_at).toLocaleDateString()}
                </TableCell>
                <TableCell>
                  <div className="flex space-x-2">
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => viewProtocol(protocol)}
                      className="text-blue-400 hover:text-blue-300"
                    >
                      <Eye className="h-4 w-4" />
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => toggleProtocolStatus(protocol)}
                      className={protocol.is_active 
                        ? "text-yellow-400 hover:text-yellow-300" 
                        : "text-green-400 hover:text-green-300"
                      }
                    >
                      <Activity className="h-4 w-4" />
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => deleteProtocol(protocol)}
                      className="text-red-400 hover:text-red-300"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      {/* View Protocol Dialog */}
      <Dialog open={isViewDialogOpen} onOpenChange={setIsViewDialogOpen}>
        <DialogContent className="glass-card border-purple-400/30 max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-white">Protocol Details</DialogTitle>
          </DialogHeader>
          {selectedProtocol && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-purple-300">Protocol Name</Label>
                  <p className="text-white mt-1">{selectedProtocol.name}</p>
                </div>
                <div>
                  <Label className="text-purple-300">Status</Label>
                  <Badge 
                    variant={selectedProtocol.is_active ? 'default' : 'secondary'}
                    className={selectedProtocol.is_active 
                      ? 'bg-green-500/20 text-green-300 mt-1' 
                      : 'bg-gray-500/20 text-gray-300 mt-1'
                    }
                  >
                    {selectedProtocol.is_active ? 'Active' : 'Inactive'}
                  </Badge>
                </div>
              </div>

              <div>
                <Label className="text-purple-300">User ID</Label>
                <p className="text-white mt-1 font-mono">{selectedProtocol.user_id}</p>
              </div>

              <div>
                <Label className="text-purple-300">Notes</Label>
                <p className="text-white mt-1">{selectedProtocol.notes || 'No notes available'}</p>
              </div>

              <div>
                <Label className="text-purple-300">Peptide Data</Label>
                <pre className="text-white mt-1 bg-background/50 p-3 rounded text-sm overflow-x-auto">
                  {JSON.stringify(selectedProtocol.peptide_data, null, 2)}
                </pre>
              </div>

              <div>
                <Label className="text-purple-300">Schedule</Label>
                <pre className="text-white mt-1 bg-background/50 p-3 rounded text-sm overflow-x-auto">
                  {JSON.stringify(selectedProtocol.schedule, null, 2)}
                </pre>
              </div>

              <div>
                <Label className="text-purple-300">Calculator Settings</Label>
                <pre className="text-white mt-1 bg-background/50 p-3 rounded text-sm overflow-x-auto">
                  {JSON.stringify(selectedProtocol.calculator_settings, null, 2)}
                </pre>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-purple-300">Created</Label>
                  <p className="text-white mt-1">{new Date(selectedProtocol.created_at).toLocaleString()}</p>
                </div>
                <div>
                  <Label className="text-purple-300">Updated</Label>
                  <p className="text-white mt-1">{new Date(selectedProtocol.updated_at).toLocaleString()}</p>
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default ProtocolOversight;
