
import React, { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAdmin } from '@/hooks/useAdmin';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import { Activity, TrendingUp, Users, Calendar, Trash2, Download } from 'lucide-react';

interface HealthLog {
  id: string;
  user_id: string;
  log_type: string;
  value: number;
  unit: string;
  notes: string;
  logged_at: string;
  created_at: string;
}

interface HealthStats {
  total_logs: number;
  active_users: number;
  log_types: { [key: string]: number };
  recent_logs: number;
}

const HealthData = () => {
  const [healthLogs, setHealthLogs] = useState<HealthLog[]>([]);
  const [stats, setStats] = useState<HealthStats>({
    total_logs: 0,
    active_users: 0,
    log_types: {},
    recent_logs: 0
  });
  const [loading, setLoading] = useState(true);
  const [selectedLogType, setSelectedLogType] = useState<string>('all');
  const { logAdminAction } = useAdmin();

  useEffect(() => {
    fetchHealthLogs();
    fetchStats();
  }, [selectedLogType]);

  const fetchHealthLogs = async () => {
    try {
      let query = supabase
        .from('health_logs')
        .select('*')
        .order('logged_at', { ascending: false })
        .limit(100);

      if (selectedLogType !== 'all') {
        query = query.eq('log_type', selectedLogType);
      }

      const { data, error } = await query;

      if (error) throw error;
      setHealthLogs(data || []);
    } catch (error) {
      console.error('Error fetching health logs:', error);
      toast.error('Failed to fetch health logs');
    } finally {
      setLoading(false);
    }
  };

  const fetchStats = async () => {
    try {
      const { data: allLogs, error } = await supabase
        .from('health_logs')
        .select('id, user_id, log_type, logged_at');

      if (error) throw error;

      const totalLogs = allLogs?.length || 0;
      const activeUsers = new Set(allLogs?.map(log => log.user_id)).size;
      
      const logTypes: { [key: string]: number } = {};
      allLogs?.forEach(log => {
        logTypes[log.log_type] = (logTypes[log.log_type] || 0) + 1;
      });

      const sevenDaysAgo = new Date();
      sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);
      const recentLogs = allLogs?.filter(log => 
        new Date(log.logged_at) >= sevenDaysAgo
      ).length || 0;

      setStats({
        total_logs: totalLogs,
        active_users: activeUsers,
        log_types: logTypes,
        recent_logs: recentLogs
      });
    } catch (error) {
      console.error('Error fetching stats:', error);
    }
  };

  const deleteHealthLog = async (logId: string) => {
    if (!confirm('Are you sure you want to delete this health log?')) return;

    try {
      const logToDelete = healthLogs.find(log => log.id === logId);
      const { error } = await supabase
        .from('health_logs')
        .delete()
        .eq('id', logId);

      if (error) throw error;

      await logAdminAction(
        'DELETE_HEALTH_LOG',
        'health_logs',
        logId,
        logToDelete,
        null
      );

      setHealthLogs(prev => prev.filter(log => log.id !== logId));
      toast.success('Health log deleted successfully');
      fetchStats();
    } catch (error) {
      console.error('Error deleting health log:', error);
      toast.error('Failed to delete health log');
    }
  };

  const exportHealthData = async () => {
    try {
      const { data, error } = await supabase
        .from('health_logs')
        .select('*')
        .order('logged_at', { ascending: false });

      if (error) throw error;

      const csvContent = [
        ['ID', 'User ID', 'Log Type', 'Value', 'Unit', 'Notes', 'Logged At', 'Created At'],
        ...data.map(log => [
          log.id,
          log.user_id,
          log.log_type,
          log.value,
          log.unit,
          log.notes,
          log.logged_at,
          log.created_at
        ])
      ].map(row => row.join(',')).join('\n');

      const blob = new Blob([csvContent], { type: 'text/csv' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `health-data-${new Date().toISOString().split('T')[0]}.csv`;
      a.click();
      URL.revokeObjectURL(url);

      toast.success('Health data exported successfully');
    } catch (error) {
      console.error('Error exporting health data:', error);
      toast.error('Failed to export health data');
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="text-center">
          <Activity className="h-12 w-12 mx-auto mb-4 text-purple-400 animate-pulse" />
          <p className="text-purple-300">Loading health data...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-bold text-white mb-2">Health Data Management</h2>
          <p className="text-purple-300">Monitor and manage user health logs and metrics</p>
        </div>
        <Button onClick={exportHealthData} className="bg-green-600 hover:bg-green-700">
          <Download className="h-4 w-4 mr-2" />
          Export Data
        </Button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="glass-card">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-purple-300">Total Logs</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-white">{stats.total_logs}</div>
          </CardContent>
        </Card>

        <Card className="glass-card">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-purple-300">Active Users</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-400">{stats.active_users}</div>
          </CardContent>
        </Card>

        <Card className="glass-card">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-purple-300">Recent Logs (7 days)</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-400">{stats.recent_logs}</div>
          </CardContent>
        </Card>

        <Card className="glass-card">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-purple-300">Log Types</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-400">{Object.keys(stats.log_types).length}</div>
          </CardContent>
        </Card>
      </div>

      {/* Log Types Overview */}
      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="text-white">Log Types Distribution</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {Object.entries(stats.log_types).map(([type, count]) => (
              <div key={type} className="text-center">
                <div className="text-lg font-bold text-white">{count}</div>
                <div className="text-sm text-purple-300 capitalize">{type}</div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Filter Controls */}
      <div className="flex gap-2">
        <Button
          variant={selectedLogType === 'all' ? 'default' : 'outline'}
          onClick={() => setSelectedLogType('all')}
        >
          All Logs
        </Button>
        {Object.keys(stats.log_types).map(type => (
          <Button
            key={type}
            variant={selectedLogType === type ? 'default' : 'outline'}
            onClick={() => setSelectedLogType(type)}
          >
            {type.charAt(0).toUpperCase() + type.slice(1)}
          </Button>
        ))}
      </div>

      {/* Health Logs Table */}
      <div className="glass-card rounded-xl p-6">
        <Table>
          <TableHeader>
            <TableRow className="border-purple-400/20">
              <TableHead className="text-purple-300">User ID</TableHead>
              <TableHead className="text-purple-300">Log Type</TableHead>
              <TableHead className="text-purple-300">Value</TableHead>
              <TableHead className="text-purple-300">Unit</TableHead>
              <TableHead className="text-purple-300">Notes</TableHead>
              <TableHead className="text-purple-300">Logged At</TableHead>
              <TableHead className="text-purple-300">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {healthLogs.map((log) => (
              <TableRow key={log.id} className="border-purple-400/10">
                <TableCell className="text-purple-300 font-mono text-sm">
                  {log.user_id.substring(0, 8)}...
                </TableCell>
                <TableCell>
                  <Badge variant="outline" className="text-purple-300">
                    {log.log_type}
                  </Badge>
                </TableCell>
                <TableCell className="text-white font-medium">
                  {log.value}
                </TableCell>
                <TableCell className="text-purple-300">
                  {log.unit || 'N/A'}
                </TableCell>
                <TableCell className="text-white">
                  {log.notes ? (
                    <span className="truncate max-w-xs">{log.notes}</span>
                  ) : (
                    <span className="text-gray-400">No notes</span>
                  )}
                </TableCell>
                <TableCell className="text-purple-300">
                  {new Date(log.logged_at).toLocaleString()}
                </TableCell>
                <TableCell>
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => deleteHealthLog(log.id)}
                    className="text-red-400 hover:text-red-300"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
};

export default HealthData;
