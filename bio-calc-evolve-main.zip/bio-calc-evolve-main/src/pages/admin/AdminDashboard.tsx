
import React, { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Users, FileText, BookOpen, Activity, BarChart3 } from 'lucide-react';

const AdminDashboard = () => {
  const [stats, setStats] = useState({
    totalUsers: 0,
    totalPages: 0,
    totalResources: 0,
    totalProtocols: 0,
    totalHealthLogs: 0,
  });

  useEffect(() => {
    const fetchStats = async () => {
      try {
        // Get user count from profiles
        const { count: userCount } = await supabase
          .from('profiles')
          .select('*', { count: 'exact', head: true });

        // Get pages count
        const { count: pageCount } = await supabase
          .from('pages')
          .select('*', { count: 'exact', head: true });

        // Get resources count
        const { count: resourceCount } = await supabase
          .from('library_resources')
          .select('*', { count: 'exact', head: true });

        // Get protocols count
        const { count: protocolCount } = await supabase
          .from('protocols')
          .select('*', { count: 'exact', head: true });

        // Get health logs count
        const { count: healthLogCount } = await supabase
          .from('health_logs')
          .select('*', { count: 'exact', head: true });

        setStats({
          totalUsers: userCount || 0,
          totalPages: pageCount || 0,
          totalResources: resourceCount || 0,
          totalProtocols: protocolCount || 0,
          totalHealthLogs: healthLogCount || 0,
        });
      } catch (error) {
        console.error('Error fetching stats:', error);
      }
    };

    fetchStats();
  }, []);

  const statCards = [
    { title: 'Total Users', value: stats.totalUsers, icon: Users, color: 'text-blue-400' },
    { title: 'Pages', value: stats.totalPages, icon: FileText, color: 'text-green-400' },
    { title: 'Resources', value: stats.totalResources, icon: BookOpen, color: 'text-purple-400' },
    { title: 'Protocols', value: stats.totalProtocols, icon: BarChart3, color: 'text-yellow-400' },
    { title: 'Health Logs', value: stats.totalHealthLogs, icon: Activity, color: 'text-red-400' },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold text-white mb-2">Dashboard Overview</h2>
        <p className="text-purple-300">Monitor your application's key metrics</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-6">
        {statCards.map((stat, index) => (
          <div key={index} className="glass-card p-6 rounded-xl">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-purple-300 text-sm font-medium">{stat.title}</p>
                <p className="text-3xl font-bold text-white mt-2">{stat.value}</p>
              </div>
              <stat.icon className={`h-8 w-8 ${stat.color}`} />
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="glass-card p-6 rounded-xl">
          <h3 className="text-xl font-semibold text-white mb-4">Recent Activity</h3>
          <p className="text-purple-300">Activity monitoring coming soon...</p>
        </div>

        <div className="glass-card p-6 rounded-xl">
          <h3 className="text-xl font-semibold text-white mb-4">System Health</h3>
          <div className="space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-purple-300">Database</span>
              <span className="text-green-400 font-medium">Healthy</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-purple-300">Authentication</span>
              <span className="text-green-400 font-medium">Active</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-purple-300">Storage</span>
              <span className="text-green-400 font-medium">Available</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
