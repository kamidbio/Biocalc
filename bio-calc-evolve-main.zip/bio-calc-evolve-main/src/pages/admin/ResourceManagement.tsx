import React, { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAdmin } from '@/hooks/useAdmin';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { toast } from 'sonner';
import { BookOpen, Plus, Edit, Trash2, Upload, Download, FileText } from 'lucide-react';
import FileUploadDialog from '@/components/admin/FileUploadDialog';

interface LibraryResource {
  id: string;
  title: string;
  description: string;
  content: any;
  category: string;
  tags: string[];
  stacks: any;
  frequencies: any;
  is_active: boolean;
  created_at: string;
  updated_at: string;
  file_url?: string;
  file_type?: string;
  file_size?: number;
}

const ResourceManagement = () => {
  const [resources, setResources] = useState<LibraryResource[]>([]);
  const [loading, setLoading] = useState(true);
  const [editingResource, setEditingResource] = useState<LibraryResource | null>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const { logAdminAction } = useAdmin();
  const [fileUploadOpen, setFileUploadOpen] = useState(false);

  useEffect(() => {
    fetchResources();
  }, []);

  const fetchResources = async () => {
    try {
      const { data, error } = await supabase
        .from('library_resources')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setResources(data || []);
    } catch (error) {
      console.error('Error fetching resources:', error);
      toast.error('Failed to fetch resources');
    } finally {
      setLoading(false);
    }
  };

  const handleSaveResource = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const formData = new FormData(event.currentTarget);
    
    try {
      const resourceData = {
        title: formData.get('title') as string,
        description: formData.get('description') as string,
        content: JSON.parse((formData.get('content') as string) || '{}'),
        category: formData.get('category') as string,
        tags: (formData.get('tags') as string).split(',').map(tag => tag.trim()).filter(Boolean),
        stacks: JSON.parse((formData.get('stacks') as string) || '{}'),
        frequencies: JSON.parse((formData.get('frequencies') as string) || '{}'),
        is_active: formData.get('is_active') === 'on',
      };

      if (editingResource) {
        const { error } = await supabase
          .from('library_resources')
          .update(resourceData)
          .eq('id', editingResource.id);

        if (error) throw error;

        await logAdminAction('UPDATE_RESOURCE', 'library_resources', editingResource.id, editingResource, resourceData);
        toast.success('Resource updated successfully');
      } else {
        const { error } = await supabase
          .from('library_resources')
          .insert(resourceData);

        if (error) throw error;

        await logAdminAction('CREATE_RESOURCE', 'library_resources', undefined, undefined, resourceData);
        toast.success('Resource created successfully');
      }

      setIsDialogOpen(false);
      setEditingResource(null);
      fetchResources();
    } catch (error) {
      console.error('Error saving resource:', error);
      toast.error('Failed to save resource');
    }
  };

  const handleDeleteResource = async (resource: LibraryResource) => {
    if (!confirm('Are you sure you want to delete this resource?')) return;

    try {
      const { error } = await supabase
        .from('library_resources')
        .delete()
        .eq('id', resource.id);

      if (error) throw error;

      await logAdminAction('DELETE_RESOURCE', 'library_resources', resource.id, resource, undefined);
      toast.success('Resource deleted successfully');
      fetchResources();
    } catch (error) {
      console.error('Error deleting resource:', error);
      toast.error('Failed to delete resource');
    }
  };

  const handleDownload = (resource: LibraryResource) => {
    if (resource.file_url) {
      window.open(resource.file_url, '_blank');
    }
  };

  const formatFileSize = (bytes: number | null) => {
    if (!bytes) return '';
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(1024));
    return `${Math.round(bytes / Math.pow(1024, i) * 100) / 100} ${sizes[i]}`;
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="text-center">
          <BookOpen className="h-12 w-12 mx-auto mb-4 text-purple-400 animate-pulse" />
          <p className="text-purple-300">Loading resources...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-bold text-white mb-2">Library Resource Management</h2>
          <p className="text-purple-300">Manage educational resources and content</p>
        </div>
        <div className="flex gap-2">
          <Button 
            onClick={() => setFileUploadOpen(true)}
            className="bg-green-600 hover:bg-green-700"
          >
            <Upload className="h-4 w-4 mr-2" />
            Upload File
          </Button>
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button 
                onClick={() => setEditingResource(null)}
                className="bg-purple-600 hover:bg-purple-700"
              >
                <Plus className="h-4 w-4 mr-2" />
                Add Resource
              </Button>
            </DialogTrigger>
            <DialogContent className="glass-card border-purple-400/30 max-w-4xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle className="text-white">
                  {editingResource ? 'Edit Resource' : 'Create New Resource'}
                </DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSaveResource} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="title" className="text-purple-300">Title</Label>
                    <Input
                      id="title"
                      name="title"
                      defaultValue={editingResource?.title}
                      className="bg-background/50 border-purple-400/30"
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="category" className="text-purple-300">Category</Label>
                    <Input
                      id="category"
                      name="category"
                      defaultValue={editingResource?.category}
                      className="bg-background/50 border-purple-400/30"
                    />
                  </div>
                </div>
                <div>
                  <Label htmlFor="description" className="text-purple-300">Description</Label>
                  <Textarea
                    id="description"
                    name="description"
                    defaultValue={editingResource?.description}
                    className="bg-background/50 border-purple-400/30"
                  />
                </div>
                <div>
                  <Label htmlFor="tags" className="text-purple-300">Tags (comma-separated)</Label>
                  <Input
                    id="tags"
                    name="tags"
                    defaultValue={editingResource?.tags?.join(', ')}
                    className="bg-background/50 border-purple-400/30"
                  />
                </div>
                <div>
                  <Label htmlFor="content" className="text-purple-300">Content (JSON)</Label>
                  <Textarea
                    id="content"
                    name="content"
                    defaultValue={JSON.stringify(editingResource?.content || {}, null, 2)}
                    className="bg-background/50 border-purple-400/30 h-32"
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="stacks" className="text-purple-300">Stacks (JSON)</Label>
                    <Textarea
                      id="stacks"
                      name="stacks"
                      defaultValue={JSON.stringify(editingResource?.stacks || {}, null, 2)}
                      className="bg-background/50 border-purple-400/30 h-24"
                    />
                  </div>
                  <div>
                    <Label htmlFor="frequencies" className="text-purple-300">Frequencies (JSON)</Label>
                    <Textarea
                      id="frequencies"
                      name="frequencies"
                      defaultValue={JSON.stringify(editingResource?.frequencies || {}, null, 2)}
                      className="bg-background/50 border-purple-400/30 h-24"
                    />
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <Switch
                    id="is_active"
                    name="is_active"
                    defaultChecked={editingResource?.is_active ?? true}
                  />
                  <Label htmlFor="is_active" className="text-purple-300">Active</Label>
                </div>
                <Button type="submit" className="w-full bg-purple-600 hover:bg-purple-700">
                  {editingResource ? 'Update Resource' : 'Create Resource'}
                </Button>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      
      <div className="glass-card rounded-xl p-6">
        <Table>
          <TableHeader>
            <TableRow className="border-purple-400/20">
              <TableHead className="text-purple-300">Title</TableHead>
              <TableHead className="text-purple-300">Type</TableHead>
              <TableHead className="text-purple-300">Category</TableHead>
              <TableHead className="text-purple-300">Size</TableHead>
              <TableHead className="text-purple-300">Status</TableHead>
              <TableHead className="text-purple-300">Updated</TableHead>
              <TableHead className="text-purple-300">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {resources.map((resource) => (
              <TableRow key={resource.id} className="border-purple-400/10">
                <TableCell className="text-white font-medium">
                  <div className="flex items-center gap-2">
                    {resource.file_url && <FileText className="h-4 w-4 text-purple-400" />}
                    {resource.title}
                  </div>
                </TableCell>
                <TableCell className="text-purple-300">
                  {resource.file_type ? (
                    <Badge variant="outline" className="text-xs">
                      {resource.file_type.split('/')[1]?.toUpperCase() || 'FILE'}
                    </Badge>
                  ) : (
                    <Badge variant="outline" className="text-xs">TEXT</Badge>
                  )}
                </TableCell>
                <TableCell className="text-purple-300">{resource.category}</TableCell>
                <TableCell className="text-purple-300 text-xs">
                  {formatFileSize(resource.file_size)}
                </TableCell>
                <TableCell>
                  <Badge 
                    variant={resource.is_active ? 'default' : 'secondary'}
                    className={resource.is_active 
                      ? 'bg-green-500/20 text-green-300' 
                      : 'bg-gray-500/20 text-gray-300'
                    }
                  >
                    {resource.is_active ? 'Active' : 'Inactive'}
                  </Badge>
                </TableCell>
                <TableCell className="text-purple-300">
                  {new Date(resource.updated_at).toLocaleDateString()}
                </TableCell>
                <TableCell>
                  <div className="flex space-x-2">
                    {resource.file_url && (
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => handleDownload(resource)}
                        className="text-blue-400 hover:text-blue-300"
                      >
                        <Download className="h-4 w-4" />
                      </Button>
                    )}
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => {
                        setEditingResource(resource);
                        setIsDialogOpen(true);
                      }}
                      className="text-purple-300 hover:text-purple-200"
                    >
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => handleDeleteResource(resource)}
                      className="text-red-400 hover:text-red-300"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      <FileUploadDialog
        open={fileUploadOpen}
        onOpenChange={setFileUploadOpen}
        onUploadSuccess={fetchResources}
      />
    </div>
  );
};

export default ResourceManagement;
