import React, { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAdmin } from '@/hooks/useAdmin';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { toast } from 'sonner';
import { FileText, Plus, Edit, Trash2 } from 'lucide-react';

interface Page {
  id: string;
  slug: string;
  title: string;
  content: any;
  layout_config: any;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

const PageManagement = () => {
  const [pages, setPages] = useState<Page[]>([]);
  const [loading, setLoading] = useState(true);
  const [editingPage, setEditingPage] = useState<Page | null>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const { logAdminAction } = useAdmin();

  useEffect(() => {
    fetchPages();
  }, []);

  const fetchPages = async () => {
    try {
      const { data, error } = await supabase
        .from('pages')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setPages(data || []);
    } catch (error) {
      console.error('Error fetching pages:', error);
      toast.error('Failed to fetch pages');
    } finally {
      setLoading(false);
    }
  };

  const handleSavePage = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const formData = new FormData(event.currentTarget);
    
    try {
      const pageData = {
        slug: formData.get('slug') as string,
        title: formData.get('title') as string,
        content: JSON.parse((formData.get('content') as string) || '{}'),
        layout_config: JSON.parse((formData.get('layout_config') as string) || '{}'),
        is_active: formData.get('is_active') === 'on',
      };

      if (editingPage) {
        const { error } = await supabase
          .from('pages')
          .update(pageData)
          .eq('id', editingPage.id);

        if (error) throw error;

        await logAdminAction('UPDATE_PAGE', 'pages', editingPage.id, editingPage, pageData);
        toast.success('Page updated successfully');
      } else {
        const { error } = await supabase
          .from('pages')
          .insert(pageData);

        if (error) throw error;

        await logAdminAction('CREATE_PAGE', 'pages', undefined, undefined, pageData);
        toast.success('Page created successfully');
      }

      setIsDialogOpen(false);
      setEditingPage(null);
      fetchPages();
    } catch (error) {
      console.error('Error saving page:', error);
      toast.error('Failed to save page');
    }
  };

  const handleDeletePage = async (page: Page) => {
    if (!confirm('Are you sure you want to delete this page?')) return;

    try {
      const { error } = await supabase
        .from('pages')
        .delete()
        .eq('id', page.id);

      if (error) throw error;

      await logAdminAction('DELETE_PAGE', 'pages', page.id, page, undefined);
      toast.success('Page deleted successfully');
      fetchPages();
    } catch (error) {
      console.error('Error deleting page:', error);
      toast.error('Failed to delete page');
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="text-center">
          <FileText className="h-12 w-12 mx-auto mb-4 text-purple-400 animate-pulse" />
          <p className="text-purple-300">Loading pages...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-bold text-white mb-2">Page Management</h2>
          <p className="text-purple-300">Manage your application pages</p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button 
              onClick={() => setEditingPage(null)}
              className="bg-purple-600 hover:bg-purple-700"
            >
              <Plus className="h-4 w-4 mr-2" />
              Add Page
            </Button>
          </DialogTrigger>
          <DialogContent className="glass-card border-purple-400/30 max-w-2xl">
            <DialogHeader>
              <DialogTitle className="text-white">
                {editingPage ? 'Edit Page' : 'Create New Page'}
              </DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSavePage} className="space-y-4">
              <div>
                <Label htmlFor="slug" className="text-purple-300">Slug</Label>
                <Input
                  id="slug"
                  name="slug"
                  defaultValue={editingPage?.slug}
                  className="bg-background/50 border-purple-400/30"
                  required
                />
              </div>
              <div>
                <Label htmlFor="title" className="text-purple-300">Title</Label>
                <Input
                  id="title"
                  name="title"
                  defaultValue={editingPage?.title}
                  className="bg-background/50 border-purple-400/30"
                  required
                />
              </div>
              <div>
                <Label htmlFor="content" className="text-purple-300">Content (JSON)</Label>
                <Textarea
                  id="content"
                  name="content"
                  defaultValue={JSON.stringify(editingPage?.content || {}, null, 2)}
                  className="bg-background/50 border-purple-400/30 h-32"
                />
              </div>
              <div>
                <Label htmlFor="layout_config" className="text-purple-300">Layout Config (JSON)</Label>
                <Textarea
                  id="layout_config"
                  name="layout_config"
                  defaultValue={JSON.stringify(editingPage?.layout_config || {}, null, 2)}
                  className="bg-background/50 border-purple-400/30 h-32"
                />
              </div>
              <div className="flex items-center space-x-2">
                <Switch
                  id="is_active"
                  name="is_active"
                  defaultChecked={editingPage?.is_active ?? true}
                />
                <Label htmlFor="is_active" className="text-purple-300">Active</Label>
              </div>
              <Button type="submit" className="w-full bg-purple-600 hover:bg-purple-700">
                {editingPage ? 'Update Page' : 'Create Page'}
              </Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="glass-card rounded-xl p-6">
        <Table>
          <TableHeader>
            <TableRow className="border-purple-400/20">
              <TableHead className="text-purple-300">Title</TableHead>
              <TableHead className="text-purple-300">Slug</TableHead>
              <TableHead className="text-purple-300">Status</TableHead>
              <TableHead className="text-purple-300">Updated</TableHead>
              <TableHead className="text-purple-300">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {pages.map((page) => (
              <TableRow key={page.id} className="border-purple-400/10">
                <TableCell className="text-white font-medium">{page.title}</TableCell>
                <TableCell className="text-purple-300">/{page.slug}</TableCell>
                <TableCell>
                  <Badge 
                    variant={page.is_active ? 'default' : 'secondary'}
                    className={page.is_active 
                      ? 'bg-green-500/20 text-green-300' 
                      : 'bg-gray-500/20 text-gray-300'
                    }
                  >
                    {page.is_active ? 'Active' : 'Inactive'}
                  </Badge>
                </TableCell>
                <TableCell className="text-purple-300">
                  {new Date(page.updated_at).toLocaleDateString()}
                </TableCell>
                <TableCell>
                  <div className="flex space-x-2">
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => {
                        setEditingPage(page);
                        setIsDialogOpen(true);
                      }}
                      className="text-purple-300 hover:text-purple-200"
                    >
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => handleDeletePage(page)}
                      className="text-red-400 hover:text-red-300"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
};

export default PageManagement;
