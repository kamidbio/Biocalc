
import React, { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAdmin } from '@/hooks/useAdmin';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { toast } from 'sonner';
import { Settings, Plus, Edit, Trash2, Save, Upload, Image } from 'lucide-react';

interface AdminSetting {
  id: string;
  setting_key: string;
  setting_value: any;
  description: string | null;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

const AdminSettings = () => {
  const [settings, setSettings] = useState<AdminSetting[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingSetting, setEditingSetting] = useState<AdminSetting | null>(null);
  const [logoFile, setLogoFile] = useState<File | null>(null);
  const [logoUploading, setLogoUploading] = useState(false);
  const [currentLogo, setCurrentLogo] = useState<string>('');
  const { logAdminAction } = useAdmin();

  const defaultSettings = [
    {
      setting_key: 'site_name',
      setting_value: 'PeptideCalc Pro',
      description: 'The name of your application'
    },
    {
      setting_key: 'site_description',
      setting_value: 'Professional peptide calculator and protocol management',
      description: 'Brief description of your application'
    },
    {
      setting_key: 'site_logo',
      setting_value: '',
      description: 'URL to your site logo'
    },
    {
      setting_key: 'maintenance_mode',
      setting_value: false,
      description: 'Enable maintenance mode to prevent user access'
    },
    {
      setting_key: 'user_registration',
      setting_value: true,
      description: 'Allow new user registrations'
    },
    {
      setting_key: 'app_theme',
      setting_value: 'dark',
      description: 'Default application theme'
    },
    {
      setting_key: 'max_file_size',
      setting_value: 50,
      description: 'Maximum file upload size in MB'
    }
  ];

  useEffect(() => {
    loadSettings();
  }, []);

  const loadSettings = async () => {
    try {
      setLoading(true);
      
      const { data: existingSettings, error } = await supabase
        .from('admin_settings')
        .select('*')
        .order('setting_key');

      if (error) {
        console.error('Error loading settings:', error);
        toast.error('Failed to load admin settings');
        return;
      }

      // If no settings exist, create defaults
      if (!existingSettings || existingSettings.length === 0) {
        await createDefaultSettings();
      } else {
        setSettings(existingSettings);
        // Find and set current logo - properly handle Json type
        const logoSetting = existingSettings.find(s => s.setting_key === 'site_logo');
        if (logoSetting && logoSetting.setting_value) {
          // Ensure we convert the Json value to string
          const logoValue = typeof logoSetting.setting_value === 'string' 
            ? logoSetting.setting_value 
            : String(logoSetting.setting_value);
          setCurrentLogo(logoValue);
        }
      }
    } catch (error) {
      console.error('Error loading settings:', error);
      toast.error('Failed to load admin settings');
    } finally {
      setLoading(false);
    }
  };

  const createDefaultSettings = async () => {
    try {
      setSaving(true);
      const { data, error } = await supabase
        .from('admin_settings')
        .insert(defaultSettings.map(setting => ({
          setting_key: setting.setting_key,
          setting_value: setting.setting_value,
          description: setting.description,
          is_active: true
        })))
        .select();

      if (error) throw error;

      setSettings(data || []);
      await logAdminAction('CREATE_DEFAULT_SETTINGS', 'admin_settings', undefined, undefined, { count: defaultSettings.length });
      toast.success('Default settings created and saved successfully');
    } catch (error) {
      console.error('Error creating default settings:', error);
      toast.error('Failed to create default settings');
    } finally {
      setSaving(false);
    }
  };

  const handleSaveSetting = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const formData = new FormData(event.currentTarget);
    
    try {
      setSaving(true);
      let settingValue: any = formData.get('setting_value') as string;
      
      // Try to parse as JSON for complex values
      try {
        settingValue = JSON.parse(settingValue);
      } catch {
        // Keep as string if not valid JSON
      }

      const settingData = {
        setting_key: formData.get('setting_key') as string,
        setting_value: settingValue,
        description: formData.get('description') as string,
        is_active: formData.get('is_active') === 'on',
      };

      if (editingSetting) {
        const { error } = await supabase
          .from('admin_settings')
          .update(settingData)
          .eq('id', editingSetting.id);

        if (error) throw error;

        await logAdminAction('UPDATE_SETTING', 'admin_settings', editingSetting.id, editingSetting, settingData);
        toast.success('Setting updated and saved successfully');
      } else {
        const { error } = await supabase
          .from('admin_settings')
          .insert(settingData);

        if (error) throw error;

        await logAdminAction('CREATE_SETTING', 'admin_settings', undefined, undefined, settingData);
        toast.success('Setting created and saved successfully');
      }

      setIsDialogOpen(false);
      setEditingSetting(null);
      loadSettings();
    } catch (error) {
      console.error('Error saving setting:', error);
      toast.error('Failed to save setting');
    } finally {
      setSaving(false);
    }
  };

  const handleDeleteSetting = async (setting: AdminSetting) => {
    if (!confirm('Are you sure you want to delete this setting? This action cannot be undone.')) return;

    try {
      setSaving(true);
      const { error } = await supabase
        .from('admin_settings')
        .delete()
        .eq('id', setting.id);

      if (error) throw error;

      await logAdminAction('DELETE_SETTING', 'admin_settings', setting.id, setting, undefined);
      toast.success('Setting deleted successfully');
      loadSettings();
    } catch (error) {
      console.error('Error deleting setting:', error);
      toast.error('Failed to delete setting');
    } finally {
      setSaving(false);
    }
  };

  const handleLogoUpload = async () => {
    if (!logoFile) {
      toast.error('Please select a logo file');
      return;
    }

    setLogoUploading(true);

    try {
      // Generate unique filename
      const fileExt = logoFile.name.split('.').pop();
      const timestamp = Date.now();
      const fileName = `logo-${timestamp}.${fileExt}`;
      const filePath = `logos/${fileName}`;

      // Upload file to storage
      const { data: uploadData, error: uploadError } = await supabase.storage
        .from('education-files')
        .upload(filePath, logoFile, {
          cacheControl: '3600',
          upsert: false
        });

      if (uploadError) throw uploadError;

      // Get public URL
      const { data: { publicUrl } } = supabase.storage
        .from('education-files')
        .getPublicUrl(filePath);

      // Update logo setting with proper upsert
      const { error: updateError } = await supabase
        .from('admin_settings')
        .upsert({
          setting_key: 'site_logo',
          setting_value: publicUrl,
          description: 'URL to your site logo',
          is_active: true
        }, { 
          onConflict: 'setting_key',
          ignoreDuplicates: false 
        });

      if (updateError) throw updateError;

      setCurrentLogo(publicUrl);
      setLogoFile(null);
      await logAdminAction('UPDATE_LOGO', 'admin_settings', undefined, { logo: currentLogo }, { logo: publicUrl });
      toast.success('Logo uploaded and saved successfully!');
      loadSettings();
    } catch (error) {
      console.error('Error uploading logo:', error);
      toast.error('Failed to upload logo');
    } finally {
      setLogoUploading(false);
    }
  };

  const quickUpdateSetting = async (key: string, value: any) => {
    try {
      setSaving(true);
      const { error } = await supabase
        .from('admin_settings')
        .upsert({
          setting_key: key,
          setting_value: value,
          is_active: true
        }, { 
          onConflict: 'setting_key',
          ignoreDuplicates: false 
        });

      if (error) throw error;

      await logAdminAction('QUICK_UPDATE_SETTING', 'admin_settings', undefined, undefined, { key, value });
      toast.success(`${key} updated and saved successfully`);
      loadSettings();
    } catch (error) {
      console.error('Error updating setting:', error);
      toast.error('Failed to update setting');
    } finally {
      setSaving(false);
    }
  };

  const saveAllSettings = async () => {
    try {
      setSaving(true);
      
      // Validate that all settings are properly saved
      const { data: currentSettings, error } = await supabase
        .from('admin_settings')
        .select('*')
        .eq('is_active', true);

      if (error) throw error;

      await logAdminAction('SAVE_ALL_SETTINGS', 'admin_settings', undefined, undefined, { 
        count: currentSettings?.length || 0,
        timestamp: new Date().toISOString()
      });
      
      toast.success(`All ${currentSettings?.length || 0} settings saved and applied globally!`);
    } catch (error) {
      console.error('Error saving all settings:', error);
      toast.error('Failed to save all settings');
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="text-center">
          <Settings className="h-12 w-12 mx-auto mb-4 text-purple-400 animate-pulse" />
          <p className="text-purple-300">Loading settings...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-bold text-white mb-2">Admin Settings</h2>
          <p className="text-purple-300">Configure application settings and preferences - You are the GOD of this app!</p>
        </div>
        <div className="flex gap-2">
          <Button 
            onClick={saveAllSettings}
            disabled={saving}
            className="bg-green-600 hover:bg-green-700"
          >
            <Save className="h-4 w-4 mr-2" />
            {saving ? 'Saving...' : 'Save All Settings'}
          </Button>
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button 
                onClick={() => setEditingSetting(null)}
                className="bg-purple-600 hover:bg-purple-700"
                disabled={saving}
              >
                <Plus className="h-4 w-4 mr-2" />
                Add Setting
              </Button>
            </DialogTrigger>
            <DialogContent className="glass-card border-purple-400/30">
              <DialogHeader>
                <DialogTitle className="text-white">
                  {editingSetting ? 'Edit Setting' : 'Add New Setting'}
                </DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSaveSetting} className="space-y-4">
                <div>
                  <Label htmlFor="setting_key" className="text-purple-300">Setting Key</Label>
                  <Input
                    id="setting_key"
                    name="setting_key"
                    defaultValue={editingSetting?.setting_key}
                    className="bg-background/50 border-purple-400/30"
                    required
                    disabled={saving}
                  />
                </div>
                <div>
                  <Label htmlFor="setting_value" className="text-purple-300">Setting Value</Label>
                  <Textarea
                    id="setting_value"
                    name="setting_value"
                    defaultValue={typeof editingSetting?.setting_value === 'string' 
                      ? editingSetting.setting_value 
                      : JSON.stringify(editingSetting?.setting_value, null, 2)}
                    className="bg-background/50 border-purple-400/30"
                    required
                    disabled={saving}
                  />
                </div>
                <div>
                  <Label htmlFor="description" className="text-purple-300">Description</Label>
                  <Input
                    id="description"
                    name="description"
                    defaultValue={editingSetting?.description || ''}
                    className="bg-background/50 border-purple-400/30"
                    disabled={saving}
                  />
                </div>
                <div className="flex items-center space-x-2">
                  <Switch
                    id="is_active"
                    name="is_active"
                    defaultChecked={editingSetting?.is_active ?? true}
                    disabled={saving}
                  />
                  <Label htmlFor="is_active" className="text-purple-300">Active</Label>
                </div>
                <Button type="submit" className="w-full bg-purple-600 hover:bg-purple-700" disabled={saving}>
                  {saving ? 'Saving...' : (editingSetting ? 'Update Setting' : 'Create Setting')}
                </Button>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Logo Upload Section */}
      <Card className="glass-card border-purple-400/30">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Image className="h-5 w-5" />
            Site Logo
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {currentLogo && (
            <div className="flex items-center gap-4">
              <img 
                src={currentLogo} 
                alt="Current Logo" 
                className="h-16 w-16 object-contain bg-white rounded-lg p-2"
              />
              <span className="text-purple-300">Current Logo</span>
            </div>
          )}
          <div className="flex items-center gap-4">
            <Input
              type="file"
              accept="image/*"
              onChange={(e) => setLogoFile(e.target.files?.[0] || null)}
              disabled={logoUploading || saving}
              className="bg-background/50 border-purple-400/30"
            />
            <Button
              onClick={handleLogoUpload}
              disabled={!logoFile || logoUploading || saving}
              className="bg-green-600 hover:bg-green-700"
            >
              <Upload className="h-4 w-4 mr-2" />
              {logoUploading ? 'Uploading...' : 'Upload Logo'}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Quick Settings */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card className="glass-card border-purple-400/30">
          <CardHeader>
            <CardTitle className="text-white">Site Name</CardTitle>
          </CardHeader>
          <CardContent>
            <Input
              value={(() => {
                try {
                  const siteName = settings.find(s => s.setting_key === 'site_name')?.setting_value;
                  return typeof siteName === 'string' ? siteName : (siteName ? JSON.stringify(siteName) : 'PeptideCalc Pro');
                } catch {
                  return 'PeptideCalc Pro';
                }
              })()}
              onChange={(e) => quickUpdateSetting('site_name', e.target.value)}
              className="bg-background/50 border-purple-400/30"
              disabled={saving}
              placeholder="Enter site name"
            />
            <p className="text-purple-300 text-sm mt-2">Application name displayed throughout the app</p>
          </CardContent>
        </Card>

        <Card className="glass-card border-purple-400/30">
          <CardHeader>
            <CardTitle className="text-white">Maintenance Mode</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <p className="text-purple-300 text-sm">
                  Enable to put the app in maintenance mode
                </p>
              </div>
              <Switch
                checked={(() => {
                  try {
                    const maintenanceMode = settings.find(s => s.setting_key === 'maintenance_mode')?.setting_value;
                    return typeof maintenanceMode === 'boolean' ? maintenanceMode : false;
                  } catch {
                    return false;
                  }
                })()}
                onCheckedChange={(checked) => quickUpdateSetting('maintenance_mode', checked)}
                disabled={saving}
              />
            </div>
          </CardContent>
        </Card>

        <Card className="glass-card border-purple-400/30">
          <CardHeader>
            <CardTitle className="text-white">Dark Mode Theme</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <p className="text-purple-300 text-sm">
                  Enable dark theme for the application
                </p>
              </div>
              <Switch
                checked={(() => {
                  try {
                    const appTheme = settings.find(s => s.setting_key === 'app_theme')?.setting_value;
                    return appTheme === 'dark' || appTheme === true;
                  } catch {
                    return true;
                  }
                })()}
                onCheckedChange={(checked) => quickUpdateSetting('app_theme', checked ? 'dark' : 'light')}
                disabled={saving}
              />
            </div>
          </CardContent>
        </Card>

        <Card className="glass-card border-purple-400/30">
          <CardHeader>
            <CardTitle className="text-white">User Registration</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <p className="text-purple-300 text-sm">
                  Allow new user registrations
                </p>
              </div>
              <Switch
                checked={(() => {
                  try {
                    const userRegistration = settings.find(s => s.setting_key === 'user_registration')?.setting_value;
                    return typeof userRegistration === 'boolean' ? userRegistration : true;
                  } catch {
                    return true;
                  }
                })()}
                onCheckedChange={(checked) => quickUpdateSetting('user_registration', checked)}
                disabled={saving}
              />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* All Settings Table */}
      <Card className="glass-card border-purple-400/30">
        <CardHeader>
          <CardTitle className="text-white">All Settings ({settings.length})</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {settings.map((setting) => (
              <div key={setting.id} className="flex items-center justify-between p-4 border border-purple-400/20 rounded-lg">
                <div className="flex-1">
                  <h4 className="text-white font-medium">{setting.setting_key}</h4>
                  <p className="text-purple-300 text-sm">{setting.description}</p>
                  <p className="text-gray-400 text-xs mt-1">
                    Value: {typeof setting.setting_value === 'string' 
                      ? setting.setting_value 
                      : JSON.stringify(setting.setting_value)}
                  </p>
                  <p className="text-gray-500 text-xs">
                    Status: {setting.is_active ? 'Active' : 'Inactive'}
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => {
                      setEditingSetting(setting);
                      setIsDialogOpen(true);
                    }}
                    className="text-blue-400 hover:text-blue-300"
                    disabled={saving}
                  >
                    <Edit className="h-4 w-4" />
                  </Button>
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => handleDeleteSetting(setting)}
                    className="text-red-400 hover:text-red-300"
                    disabled={saving}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default AdminSettings;
