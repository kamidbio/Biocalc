import React, { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAdmin } from '@/hooks/useAdmin';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Plus, Edit2, Trash2, Save, X, ArrowUp, ArrowDown } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { toast } from 'sonner';

interface HomepageSection {
  id: string;
  title: string;
  content: any;
  section_type: string;
  display_order: number;
  is_active: boolean;
  layout_config?: any;
  background_style?: any;
}

const HomepageSettings = () => {
  const { isAdmin, logAdminAction } = useAdmin();
  const [sections, setSections] = useState<HomepageSection[]>([]);
  const [loading, setLoading] = useState(true);
  const [editingSection, setEditingSection] = useState<HomepageSection | null>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [formData, setFormData] = useState({
    title: '',
    content: '{}',
    section_type: 'text',
    display_order: 0,
    is_active: true
  });

  useEffect(() => {
    if (isAdmin) {
      fetchSections();
    }
  }, [isAdmin]);

  const fetchSections = async () => {
    try {
      const { data, error } = await supabase
        .from('homepage_sections')
        .select('*')
        .order('display_order');

      if (error) throw error;
      setSections(data || []);
    } catch (error) {
      console.error('Error fetching sections:', error);
      toast.error('Failed to load homepage sections');
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    try {
      let contentJson;
      try {
        contentJson = JSON.parse(formData.content);
      } catch {
        toast.error('Invalid JSON in content field');
        return;
      }

      const sectionData = {
        title: formData.title,
        content: contentJson,
        section_type: formData.section_type,
        display_order: formData.display_order,
        is_active: formData.is_active,
        ...(editingSection ? {} : { created_by: (await supabase.auth.getUser()).data.user?.id })
      };

      if (editingSection) {
        const { error } = await supabase
          .from('homepage_sections')
          .update(sectionData)
          .eq('id', editingSection.id);

        if (error) throw error;
        
        await logAdminAction('UPDATE', 'homepage_sections', editingSection.id);
        toast.success('Section updated successfully');
      } else {
        const { error } = await supabase
          .from('homepage_sections')
          .insert([sectionData]);

        if (error) throw error;
        
        await logAdminAction('INSERT', 'homepage_sections');
        toast.success('Section created successfully');
      }

      setIsDialogOpen(false);
      setEditingSection(null);
      resetForm();
      fetchSections();
    } catch (error) {
      console.error('Error saving section:', error);
      toast.error('Failed to save section');
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to delete this section?')) return;

    try {
      const { error } = await supabase
        .from('homepage_sections')
        .delete()
        .eq('id', id);

      if (error) throw error;
      
      await logAdminAction('DELETE', 'homepage_sections', id);
      toast.success('Section deleted successfully');
      fetchSections();
    } catch (error) {
      console.error('Error deleting section:', error);
      toast.error('Failed to delete section');
    }
  };

  const handleReorder = async (id: string, direction: 'up' | 'down') => {
    const currentSection = sections.find(s => s.id === id);
    if (!currentSection) return;

    const newOrder = direction === 'up' ? currentSection.display_order - 1 : currentSection.display_order + 1;
    
    try {
      const { error } = await supabase
        .from('homepage_sections')
        .update({ display_order: newOrder })
        .eq('id', id);

      if (error) throw error;
      
      await logAdminAction('UPDATE', 'homepage_sections', id);
      fetchSections();
    } catch (error) {
      console.error('Error reordering section:', error);
      toast.error('Failed to reorder section');
    }
  };

  const openEditDialog = (section?: HomepageSection) => {
    if (section) {
      setEditingSection(section);
      setFormData({
        title: section.title,
        content: JSON.stringify(section.content, null, 2),
        section_type: section.section_type,
        display_order: section.display_order,
        is_active: section.is_active
      });
    } else {
      setEditingSection(null);
      resetForm();
    }
    setIsDialogOpen(true);
  };

  const resetForm = () => {
    setFormData({
      title: '',
      content: '{}',
      section_type: 'text',
      display_order: sections.length + 1,
      is_active: true
    });
  };

  if (!isAdmin) {
    return (
      <div className="text-center py-8">
        <p className="text-muted-foreground">Access denied. Admin privileges required.</p>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="text-center py-8">
        <p className="text-muted-foreground">Loading homepage settings...</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">Homepage Settings</h1>
          <p className="text-muted-foreground">Manage dynamic sections for the homepage</p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={() => openEditDialog()}>
              <Plus className="h-4 w-4 mr-2" />
              Add Section
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>
                {editingSection ? 'Edit Section' : 'Add New Section'}
              </DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="title">Section Title</Label>
                <Input
                  id="title"
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  placeholder="Enter section title"
                />
              </div>
              
              <div>
                <Label htmlFor="section_type">Section Type</Label>
                <Select value={formData.section_type} onValueChange={(value) => setFormData({ ...formData, section_type: value })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="hero">Hero Section</SelectItem>
                    <SelectItem value="features">Features Grid</SelectItem>
                    <SelectItem value="content">Content Block</SelectItem>
                    <SelectItem value="testimonials">Testimonials</SelectItem>
                    <SelectItem value="cta">Call to Action</SelectItem>
                    <SelectItem value="stats">Statistics</SelectItem>
                    <SelectItem value="text">Text Section</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="display_order">Display Order</Label>
                <Input
                  id="display_order"
                  type="number"
                  value={formData.display_order}
                  onChange={(e) => setFormData({ ...formData, display_order: parseInt(e.target.value) || 0 })}
                />
              </div>

              <div>
                <Label htmlFor="content">Content (JSON)</Label>
                <Textarea
                  id="content"
                  value={formData.content}
                  onChange={(e) => setFormData({ ...formData, content: e.target.value })}
                  placeholder='{"heading": "Example Title", "description": "Example content"}'
                  rows={8}
                  className="font-mono text-sm"
                />
              </div>

              <div className="flex items-center space-x-2">
                <Switch
                  id="is_active"
                  checked={formData.is_active}
                  onCheckedChange={(checked) => setFormData({ ...formData, is_active: checked })}
                />
                <Label htmlFor="is_active">Active</Label>
              </div>

              <div className="flex gap-2 justify-end">
                <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
                  <X className="h-4 w-4 mr-2" />
                  Cancel
                </Button>
                <Button onClick={handleSave}>
                  <Save className="h-4 w-4 mr-2" />
                  Save Section
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid gap-4">
        {sections.map((section) => (
          <Card key={section.id}>
            <CardHeader>
              <div className="flex justify-between items-start">
                <div>
                  <CardTitle className="flex items-center gap-2">
                    {section.title}
                    <Badge variant={section.is_active ? "default" : "secondary"}>
                      {section.is_active ? "Active" : "Inactive"}
                    </Badge>
                    <Badge variant="outline">{section.section_type}</Badge>
                  </CardTitle>
                  <CardDescription>Order: {section.display_order}</CardDescription>
                </div>
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleReorder(section.id, 'up')}
                    disabled={section.display_order === 1}
                  >
                    <ArrowUp className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleReorder(section.id, 'down')}
                  >
                    <ArrowDown className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => openEditDialog(section)}
                  >
                    <Edit2 className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="destructive"
                    size="sm"
                    onClick={() => handleDelete(section.id)}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <pre className="text-xs bg-muted p-3 rounded overflow-auto max-h-32">
                {JSON.stringify(section.content, null, 2)}
              </pre>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default HomepageSettings;