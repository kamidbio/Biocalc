import React, { useState, useEffect } from 'react';
import { useAdmin } from '@/hooks/useAdmin';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { Calculator, Plus, Pencil, Trash2, Save, Settings } from 'lucide-react';
import { toast } from 'sonner';

interface CalculatorSetting {
  id: string;
  setting_key: string;
  setting_value: any;
  description: string;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

const AdminCalculatorSettings = () => {
  const { logAdminAction } = useAdmin();
  const [settings, setSettings] = useState<CalculatorSetting[]>([]);
  const [loading, setLoading] = useState(true);
  const [editingSettings, setEditingSettings] = useState<{[key: string]: any}>({});
  const [newSetting, setNewSetting] = useState({
    setting_key: '',
    setting_value: '',
    description: '',
    is_active: true
  });
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);

  // Predefined calculator settings categories
  const settingCategories = {
    ui_config: {
      name: 'UI Configuration',
      description: 'Controls calculator interface appearance and behavior',
      defaultSettings: [
        {
          key: 'show_product_name_field',
          value: true,
          description: 'Show product name input field'
        },
        {
          key: 'show_vial_count_field',
          value: true,
          description: 'Show vial count input field'
        },
        {
          key: 'show_usage_planning',
          value: true,
          description: 'Show usage planning section'
        },
        {
          key: 'show_advanced_options',
          value: true,
          description: 'Show advanced calculator options'
        },
        {
          key: 'default_syringe_size',
          value: '1ml',
          description: 'Default syringe size selection'
        },
        {
          key: 'default_units',
          value: 'units',
          description: 'Default unit type (units/ml)'
        }
      ]
    },
    calculation_rules: {
      name: 'Calculation Rules',
      description: 'Controls calculation logic and validation',
      defaultSettings: [
        {
          key: 'min_peptide_amount',
          value: 1,
          description: 'Minimum peptide amount (mg)'
        },
        {
          key: 'max_peptide_amount',
          value: 10000,
          description: 'Maximum peptide amount (mg)'
        },
        {
          key: 'min_liquid_amount',
          value: 0.1,
          description: 'Minimum liquid amount (ml)'
        },
        {
          key: 'max_liquid_amount',
          value: 10,
          description: 'Maximum liquid amount (ml)'
        },
        {
          key: 'precision_decimal_places',
          value: 2,
          description: 'Number of decimal places for results'
        }
      ]
    },
    content: {
      name: 'Content & Labels',
      description: 'Customizable text content and labels',
      defaultSettings: [
        {
          key: 'calculator_title',
          value: 'B.I.O | CALC',
          description: 'Main calculator title'
        },
        {
          key: 'calculator_subtitle',
          value: 'Calculate your dosing, track your protocols, and manage your peptide schedule',
          description: 'Calculator subtitle/description'
        },
        {
          key: 'help_text',
          value: 'Fill in 3 out of 4 fields and we\'ll calculate the missing value for you.',
          description: 'Help text for users'
        },
        {
          key: 'warning_message',
          value: 'Always consult with a healthcare professional before starting any peptide protocol.',
          description: 'Safety warning message'
        }
      ]
    }
  };

  useEffect(() => {
    loadSettings();
  }, []);

  const loadSettings = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('calculator_settings')
        .select('*')
        .order('setting_key');

      if (error) throw error;
      setSettings(data || []);
    } catch (error) {
      console.error('Error loading settings:', error);
      toast.error('Failed to load calculator settings');
    } finally {
      setLoading(false);
    }
  };

  const handleSettingChange = (settingId: string, field: string, value: any) => {
    setEditingSettings(prev => ({
      ...prev,
      [settingId]: {
        ...prev[settingId],
        [field]: value
      }
    }));
  };

  const saveSetting = async (setting: CalculatorSetting) => {
    try {
      const updates = editingSettings[setting.id] || {};
      const oldData = { ...setting };
      const newData = { ...setting, ...updates, updated_at: new Date().toISOString() };

      const { error } = await supabase
        .from('calculator_settings')
        .update(newData)
        .eq('id', setting.id);

      if (error) throw error;

      await logAdminAction(
        'UPDATE',
        'calculator_settings',
        setting.id,
        oldData,
        newData
      );

      // Remove from editing state
      setEditingSettings(prev => {
        const newState = { ...prev };
        delete newState[setting.id];
        return newState;
      });

      await loadSettings();
      toast.success('Setting updated successfully');
    } catch (error) {
      console.error('Error updating setting:', error);
      toast.error('Failed to update setting');
    }
  };

  const deleteSetting = async (setting: CalculatorSetting) => {
    try {
      const { error } = await supabase
        .from('calculator_settings')
        .delete()
        .eq('id', setting.id);

      if (error) throw error;

      await logAdminAction(
        'DELETE',
        'calculator_settings',
        setting.id,
        setting,
        null
      );

      await loadSettings();
      toast.success('Setting deleted successfully');
    } catch (error) {
      console.error('Error deleting setting:', error);
      toast.error('Failed to delete setting');
    }
  };

  const addNewSetting = async () => {
    try {
      let settingValue = newSetting.setting_value;
      
      // Try to parse as JSON if it looks like JSON
      if (typeof settingValue === 'string' && (settingValue.startsWith('{') || settingValue.startsWith('['))) {
        try {
          settingValue = JSON.parse(settingValue);
        } catch {
          // Keep as string if not valid JSON
        }
      }

      const { data, error } = await supabase
        .from('calculator_settings')
        .insert({
          setting_key: newSetting.setting_key,
          setting_value: settingValue,
          description: newSetting.description,
          is_active: newSetting.is_active
        })
        .select()
        .single();

      if (error) throw error;

      await logAdminAction(
        'INSERT',
        'calculator_settings',
        data.id,
        null,
        data
      );

      setNewSetting({
        setting_key: '',
        setting_value: '',
        description: '',
        is_active: true
      });
      setIsAddDialogOpen(false);
      await loadSettings();
      toast.success('Setting added successfully');
    } catch (error) {
      console.error('Error adding setting:', error);
      toast.error('Failed to add setting');
    }
  };

  const initializeDefaultSettings = async (category: string) => {
    try {
      const categoryConfig = settingCategories[category as keyof typeof settingCategories];
      if (!categoryConfig) return;

      const settingsToInsert = categoryConfig.defaultSettings.map(setting => ({
        setting_key: setting.key,
        setting_value: setting.value,
        description: setting.description,
        is_active: true
      }));

      const { error } = await supabase
        .from('calculator_settings')
        .insert(settingsToInsert);

      if (error) throw error;

      await logAdminAction(
        'BULK_INSERT',
        'calculator_settings',
        null,
        null,
        { category, count: settingsToInsert.length }
      );

      await loadSettings();
      toast.success(`Initialized ${categoryConfig.name} settings`);
    } catch (error) {
      console.error('Error initializing settings:', error);
      toast.error('Failed to initialize default settings');
    }
  };

  const renderSettingValue = (setting: CalculatorSetting) => {
    const editedValue = editingSettings[setting.id]?.setting_value;
    const currentValue = editedValue !== undefined ? editedValue : setting.setting_value;
    
    if (typeof currentValue === 'boolean') {
      return (
        <Switch
          checked={currentValue}
          onCheckedChange={(value) => handleSettingChange(setting.id, 'setting_value', value)}
        />
      );
    }
    
    if (typeof currentValue === 'object') {
      return (
        <Textarea
          value={JSON.stringify(currentValue, null, 2)}
          onChange={(e) => {
            try {
              const parsed = JSON.parse(e.target.value);
              handleSettingChange(setting.id, 'setting_value', parsed);
            } catch {
              handleSettingChange(setting.id, 'setting_value', e.target.value);
            }
          }}
          className="font-mono text-sm"
          rows={3}
        />
      );
    }
    
    return (
      <Input
        value={currentValue?.toString() || ''}
        onChange={(e) => {
          let value: any = e.target.value;
          // Try to convert to number if it looks numeric
          if (!isNaN(Number(value)) && value !== '') {
            value = Number(value);
          }
          handleSettingChange(setting.id, 'setting_value', value);
        }}
      />
    );
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="text-center">
          <div className="animate-spin h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading calculator settings...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-primary">Calculator Settings</h1>
          <p className="text-muted-foreground">Manage calculator configuration and content</p>
        </div>
        
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="h-4 w-4 mr-2" />
              Add Setting
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Add New Calculator Setting</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="setting_key">Setting Key</Label>
                <Input
                  id="setting_key"
                  value={newSetting.setting_key}
                  onChange={(e) => setNewSetting(prev => ({ ...prev, setting_key: e.target.value }))}
                  placeholder="e.g., show_advanced_options"
                />
              </div>
              <div>
                <Label htmlFor="setting_value">Setting Value</Label>
                <Input
                  id="setting_value"
                  value={newSetting.setting_value}
                  onChange={(e) => setNewSetting(prev => ({ ...prev, setting_value: e.target.value }))}
                  placeholder="e.g., true, 1ml, or JSON object"
                />
              </div>
              <div>
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  value={newSetting.description}
                  onChange={(e) => setNewSetting(prev => ({ ...prev, description: e.target.value }))}
                  placeholder="Describe what this setting controls"
                />
              </div>
              <div className="flex items-center space-x-2">
                <Switch
                  id="is_active"
                  checked={newSetting.is_active}
                  onCheckedChange={(checked) => setNewSetting(prev => ({ ...prev, is_active: checked }))}
                />
                <Label htmlFor="is_active">Active</Label>
              </div>
              <Button onClick={addNewSetting} className="w-full">
                Add Setting
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <Tabs defaultValue="current" className="space-y-6">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="current">Current Settings</TabsTrigger>
          <TabsTrigger value="initialize">Initialize Defaults</TabsTrigger>
        </TabsList>

        <TabsContent value="current" className="space-y-4">
          {settings.length === 0 ? (
            <Card>
              <CardContent className="text-center py-8">
                <Calculator className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-semibold mb-2">No Settings Configured</h3>
                <p className="text-muted-foreground mb-4">
                  Start by initializing default settings or adding custom ones.
                </p>
              </CardContent>
            </Card>
          ) : (
            settings.map((setting) => (
              <Card key={setting.id} className="glass-card">
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="text-lg">{setting.setting_key}</CardTitle>
                      <p className="text-sm text-muted-foreground mt-1">
                        {editingSettings[setting.id]?.description !== undefined 
                          ? editingSettings[setting.id].description 
                          : setting.description}
                      </p>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Badge variant={setting.is_active ? "default" : "secondary"}>
                        {editingSettings[setting.id]?.is_active !== undefined 
                          ? (editingSettings[setting.id].is_active ? 'Active' : 'Inactive')
                          : (setting.is_active ? 'Active' : 'Inactive')}
                      </Badge>
                      {editingSettings[setting.id] && (
                        <Button
                          size="sm"
                          onClick={() => saveSetting(setting)}
                          className="h-8"
                        >
                          <Save className="h-3 w-3 mr-1" />
                          Save
                        </Button>
                      )}
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button size="sm" variant="destructive" className="h-8">
                            <Trash2 className="h-3 w-3" />
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>Delete Setting</AlertDialogTitle>
                            <AlertDialogDescription>
                              Are you sure you want to delete "{setting.setting_key}"? This action cannot be undone.
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>Cancel</AlertDialogCancel>
                            <AlertDialogAction onClick={() => deleteSetting(setting)}>
                              Delete
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label>Value</Label>
                    <div className="mt-2">
                      {renderSettingValue(setting)}
                    </div>
                  </div>
                  
                  <div>
                    <Label>Description</Label>
                    <Textarea
                      value={editingSettings[setting.id]?.description !== undefined 
                        ? editingSettings[setting.id].description 
                        : setting.description}
                      onChange={(e) => handleSettingChange(setting.id, 'description', e.target.value)}
                      className="mt-2"
                    />
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <Switch
                      checked={editingSettings[setting.id]?.is_active !== undefined 
                        ? editingSettings[setting.id].is_active 
                        : setting.is_active}
                      onCheckedChange={(checked) => handleSettingChange(setting.id, 'is_active', checked)}
                    />
                    <Label>Active</Label>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </TabsContent>

        <TabsContent value="initialize" className="space-y-4">
          {Object.entries(settingCategories).map(([key, category]) => (
            <Card key={key} className="glass-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Settings className="h-5 w-5" />
                  {category.name}
                </CardTitle>
                <p className="text-sm text-muted-foreground">{category.description}</p>
              </CardHeader>
              <CardContent>
                <div className="space-y-3 mb-4">
                  {category.defaultSettings.map((setting, index) => (
                    <div key={index} className="flex justify-between items-center p-3 bg-background/50 rounded-lg">
                      <div>
                        <span className="font-medium">{setting.key}</span>
                        <p className="text-sm text-muted-foreground">{setting.description}</p>
                      </div>
                      <Badge variant="outline">
                        {typeof setting.value === 'object' ? 'Object' : String(setting.value)}
                      </Badge>
                    </div>
                  ))}
                </div>
                <Button 
                  onClick={() => initializeDefaultSettings(key)}
                  className="w-full"
                >
                  Initialize {category.name}
                </Button>
              </CardContent>
            </Card>
          ))}
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default AdminCalculatorSettings;
