
import React, { useState } from 'react';
import ProfileSettings from '@/components/settings/ProfileSettings';
import NotificationSettings from '@/components/settings/NotificationSettings';
import DeviceIntegration from '@/components/settings/DeviceIntegration';
import TelehealthIntegration from '@/components/settings/TelehealthIntegration';
import DataPrivacy from '@/components/settings/DataPrivacy';
import ExportBackup from '@/components/settings/ExportBackup';
import { useDataExport } from '@/hooks/useDataExport';

const Settings = () => {
  const { exportUserData, exportHealthReport, exportLoading } = useDataExport();

  return (
    <div className="min-h-screen pt-24 pb-16 px-6 hero-background">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold text-gradient mb-4">
            Settings & Preferences
          </h1>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            Customize your B.I.O | CALC experience and manage your account settings
          </p>
        </div>

        <div className="grid gap-8 mb-16">
          {/* Profile Settings */}
          <div className="glass-card rounded-2xl p-6 md:p-8">
            <ProfileSettings />
          </div>

          {/* Notification Settings */}
          <div className="glass-card rounded-2xl p-6 md:p-8">
            <NotificationSettings />
          </div>

          {/* Device Integration */}
          <div className="glass-card rounded-2xl p-6 md:p-8">
            <DeviceIntegration />
          </div>

          {/* Telehealth Integration */}
          <div className="glass-card rounded-2xl p-6 md:p-8">
            <TelehealthIntegration />
          </div>

          {/* Data Privacy */}
          <div className="glass-card rounded-2xl p-6 md:p-8">
            <DataPrivacy 
              exportUserData={exportUserData}
              exportLoading={exportLoading}
            />
          </div>

          {/* Export & Backup */}
          <div className="glass-card rounded-2xl p-6 md:p-8">
            <ExportBackup 
              exportUserData={exportUserData}
              exportHealthReport={exportHealthReport}
              exportLoading={exportLoading}
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default Settings;
