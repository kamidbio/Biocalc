
import React from 'react';
import { useCalculator } from '@/hooks/useCalculator';
import CalculatorForm from '@/components/calculator/CalculatorForm';
import SavedCalculations from '@/components/calculator/SavedCalculations';
import PeptidePresets from '@/components/calculator/PeptidePresets';
import { toast } from 'sonner';

const Calculator = () => {
  const { 
    presets, 
    savedCalculations, 
    saveCalculation, 
    deleteCalculation,
    toggleFavorite,
    loadSavedCalculations 
  } = useCalculator();

  const handleSaveCalculation = async (calculationData: any, result: any) => {
    try {
      await saveCalculation(calculationData, result);
      loadSavedCalculations();
    } catch (error) {
      toast.error('Failed to save calculation');
    }
  };

  const handlePresetSelect = (preset: any, dosage: string) => {
    // This would populate the calculator form with preset values
    toast.success(`Selected ${preset.peptide_name} with ${dosage}mg dosage`);
  };

  return (
    <div className="min-h-screen pt-24 pb-32 md:pb-12 px-6">
      <div className="max-w-6xl mx-auto">

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <CalculatorForm onSave={handleSaveCalculation} />
          </div>
          
          <div className="grid gap-6">
            <PeptidePresets 
              presets={presets} 
              onPresetSelect={handlePresetSelect}
            />
            <SavedCalculations 
              calculations={savedCalculations}
              onLoad={() => {}}
              onDelete={deleteCalculation}
              onToggleFavorite={toggleFavorite}
              onCreateReminder={() => {}}
              loading={false}
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default Calculator;
