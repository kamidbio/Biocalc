
import React, { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import AuthForm from '@/components/auth/AuthForm';
import { Loader2 } from 'lucide-react';

const Auth = () => {
  const [authMode, setAuthMode] = useState<'signin' | 'signup'>('signin');
  const { user, loading } = useAuth();

  useEffect(() => {
    if (user) {
      window.location.href = '/';
    }
  }, [user]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center hero-background">
        <div className="text-center glass-card p-8 rounded-2xl">
          <Loader2 className="h-12 w-12 animate-spin mx-auto mb-6 text-primary" />
          <p className="text-muted-foreground text-lg">Loading your experience...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen hero-background relative overflow-hidden">
      {/* Floating Orbs */}
      <div className="absolute top-20 right-20 w-32 h-32 floating-orb rounded-full opacity-20" />
      <div className="absolute bottom-32 left-20 w-28 h-28 floating-orb rounded-full opacity-15"
           style={{ animationDelay: '10s' }} />
      
      {/* Particle Effects */}
      <div className="absolute inset-0 opacity-20">
        {Array.from({ length: 15 }).map((_, i) => (
          <div
            key={i}
            className="absolute w-1 h-1 bg-primary rounded-full animate-pulse"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 3}s`,
              animationDuration: `${2 + Math.random() * 3}s`
            }}
          />
        ))}
      </div>
      
      <div className="relative min-h-screen flex items-center justify-center p-6">
        <div className="w-full max-w-lg">
          <div className="glass-card rounded-3xl p-8 md:p-10 shadow-2xl border border-primary/20">
            <AuthForm
              mode={authMode}
              onToggleMode={() => setAuthMode(authMode === 'signin' ? 'signup' : 'signin')}
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default Auth;
