
import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area } from 'recharts';
import { Activity, Heart, Moon, Scale, Zap, TrendingUp } from 'lucide-react';
import { toast } from 'sonner';

const Tracking = () => {
  const [healthData] = useState([
    { date: '2024-01-01', weight: 175, hrv: 45, sleep: 7.5, heartRate: 65 },
    { date: '2024-01-02', weight: 174.5, hrv: 48, sleep: 8.0, heartRate: 63 },
    { date: '2024-01-03', weight: 174, hrv: 52, sleep: 7.8, heartRate: 62 },
    { date: '2024-01-04', weight: 173.8, hrv: 49, sleep: 7.2, heartRate: 64 },
    { date: '2024-01-05', weight: 173.5, hrv: 53, sleep: 8.2, heartRate: 61 },
    { date: '2024-01-06', weight: 173.2, hrv: 55, sleep: 8.5, heartRate: 60 },
    { date: '2024-01-07', weight: 172.8, hrv: 58, sleep: 8.0, heartRate: 59 },
  ]);

  const [connectedDevices, setConnectedDevices] = useState([
    { name: 'Apple Health', connected: true },
    { name: 'Fitbit', connected: true },
    { name: 'Oura Ring', connected: false },
    { name: 'WHOOP', connected: false },
  ]);

  const handleDeviceToggle = (deviceName: string) => {
    setConnectedDevices(prev => 
      prev.map(device => 
        device.name === deviceName 
          ? { ...device, connected: !device.connected }
          : device
      )
    );
    toast.success(`${deviceName} ${connectedDevices.find(d => d.name === deviceName)?.connected ? 'disconnected' : 'connected'}`);
  };

  const metrics = [
    {
      title: 'Weight',
      value: '172.8',
      unit: 'lbs',
      change: '-2.2',
      icon: Scale,
      color: 'text-blue-400',
      trend: 'down'
    },
    {
      title: 'HRV',
      value: '58',
      unit: 'ms',
      change: '+13',
      icon: Activity,
      color: 'text-green-400',
      trend: 'up'
    },
    {
      title: 'Sleep',
      value: '8.0',
      unit: 'hours',
      change: '+0.5',
      icon: Moon,
      color: 'text-purple-400',
      trend: 'up'
    },
    {
      title: 'Resting HR',
      value: '59',
      unit: 'bpm',
      change: '-6',
      icon: Heart,
      color: 'text-red-400',
      trend: 'down'
    }
  ];

  return (
    <div className="min-h-screen pt-24 pb-32 md:pb-12 px-6">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-4">
            Health Tracking
          </h1>
          <p className="text-xl text-muted-foreground">
            Comprehensive wellness monitoring with trend analysis
          </p>
        </div>

        {/* Metrics Overview */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {metrics.map((metric) => {
            const IconComponent = metric.icon;
            return (
              <Card key={metric.title} className="glass-effect border-primary/20">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <IconComponent className={`h-6 w-6 ${metric.color}`} />
                    <div className={`flex items-center text-sm ${
                      metric.trend === 'up' ? 'text-green-400' : 'text-blue-400'
                    }`}>
                      <TrendingUp className={`h-4 w-4 mr-1 ${
                        metric.trend === 'down' ? 'rotate-180' : ''
                      }`} />
                      {metric.change}
                    </div>
                  </div>
                  <div className="space-y-1">
                    <div className="text-2xl font-bold">
                      {metric.value}
                      <span className="text-sm text-muted-foreground ml-1">
                        {metric.unit}
                      </span>
                    </div>
                    <div className="text-sm text-muted-foreground">
                      {metric.title}
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Charts */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <Card className="glass-effect border-primary/20">
            <CardHeader>
              <CardTitle>Weight Progress</CardTitle>
              <CardDescription>Track your weight changes over time</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={healthData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(147, 51, 234, 0.1)" />
                  <XAxis 
                    dataKey="date" 
                    stroke="rgba(255, 255, 255, 0.5)"
                    fontSize={12}
                    tickFormatter={(value) => new Date(value).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                  />
                  <YAxis 
                    stroke="rgba(255, 255, 255, 0.5)"
                    fontSize={12}
                    domain={['dataMin - 1', 'dataMax + 1']}
                  />
                  <Tooltip 
                    contentStyle={{
                      backgroundColor: 'rgba(34, 30, 44, 0.9)',
                      border: '1px solid rgba(147, 51, 234, 0.3)',
                      borderRadius: '8px'
                    }}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="weight" 
                    stroke="#3b82f6" 
                    strokeWidth={3}
                    dot={{ fill: '#3b82f6', strokeWidth: 2, r: 4 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <Card className="glass-effect border-primary/20">
            <CardHeader>
              <CardTitle>HRV Trends</CardTitle>
              <CardDescription>Monitor your heart rate variability</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <AreaChart data={healthData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(147, 51, 234, 0.1)" />
                  <XAxis 
                    dataKey="date" 
                    stroke="rgba(255, 255, 255, 0.5)"
                    fontSize={12}
                    tickFormatter={(value) => new Date(value).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                  />
                  <YAxis 
                    stroke="rgba(255, 255, 255, 0.5)"
                    fontSize={12}
                  />
                  <Tooltip 
                    contentStyle={{
                      backgroundColor: 'rgba(34, 30, 44, 0.9)',
                      border: '1px solid rgba(147, 51, 234, 0.3)',
                      borderRadius: '8px'
                    }}
                  />
                  <Area 
                    type="monotone" 
                    dataKey="hrv" 
                    stroke="#10b981" 
                    fill="rgba(16, 185, 129, 0.2)"
                    strokeWidth={3}
                  />
                </AreaChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <Card className="glass-effect border-primary/20">
            <CardHeader>
              <CardTitle>Sleep Quality</CardTitle>
              <CardDescription>Your sleep duration and quality metrics</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={healthData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(147, 51, 234, 0.1)" />
                  <XAxis 
                    dataKey="date" 
                    stroke="rgba(255, 255, 255, 0.5)"
                    fontSize={12}
                    tickFormatter={(value) => new Date(value).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                  />
                  <YAxis 
                    stroke="rgba(255, 255, 255, 0.5)"
                    fontSize={12}
                    domain={[6, 9]}
                  />
                  <Tooltip 
                    contentStyle={{
                      backgroundColor: 'rgba(34, 30, 44, 0.9)',
                      border: '1px solid rgba(147, 51, 234, 0.3)',
                      borderRadius: '8px'
                    }}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="sleep" 
                    stroke="#a855f7" 
                    strokeWidth={3}
                    dot={{ fill: '#a855f7', strokeWidth: 2, r: 4 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <Card className="glass-effect border-primary/20">
            <CardHeader>
              <CardTitle>Heart Rate</CardTitle>
              <CardDescription>Resting heart rate monitoring</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <AreaChart data={healthData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(147, 51, 234, 0.1)" />
                  <XAxis 
                    dataKey="date" 
                    stroke="rgba(255, 255, 255, 0.5)"
                    fontSize={12}
                    tickFormatter={(value) => new Date(value).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                  />
                  <YAxis 
                    stroke="rgba(255, 255, 255, 0.5)"
                    fontSize={12}
                    domain={[55, 70]}
                  />
                  <Tooltip 
                    contentStyle={{
                      backgroundColor: 'rgba(34, 30, 44, 0.9)',
                      border: '1px solid rgba(147, 51, 234, 0.3)',
                      borderRadius: '8px'
                    }}
                  />
                  <Area 
                    type="monotone" 
                    dataKey="heartRate" 
                    stroke="#ef4444" 
                    fill="rgba(239, 68, 68, 0.2)"
                    strokeWidth={3}
                  />
                </AreaChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>

        {/* Device Integration */}
        <Card className="glass-effect border-primary/20 mt-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Zap className="h-5 w-5 text-primary" />
              Device Integrations
            </CardTitle>
            <CardDescription>Connect your health devices for automatic data sync</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {connectedDevices.map((device) => (
                <Button
                  key={device.name}
                  variant="outline"
                  onClick={() => handleDeviceToggle(device.name)}
                  className="flex flex-col items-center p-4 h-auto bg-card border-primary/20 hover:border-primary/40 transition-all duration-300"
                >
                  <div className={`w-12 h-12 ${device.connected ? 'bg-primary/20' : 'bg-muted/20'} rounded-full flex items-center justify-center mb-3`}>
                    <Activity className={`h-6 w-6 ${device.connected ? 'text-primary' : 'text-muted-foreground'}`} />
                  </div>
                  <div className="font-medium text-sm text-center">{device.name}</div>
                  <div className={`text-xs mt-1 ${device.connected ? 'text-green-400' : 'text-muted-foreground'}`}>
                    {device.connected ? 'Connected' : 'Not Connected'}
                  </div>
                </Button>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Tracking;
