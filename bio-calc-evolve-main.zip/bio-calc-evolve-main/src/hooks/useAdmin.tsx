
import { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

export const useAdmin = () => {
  const { user } = useAuth();
  const [isAdmin, setIsAdmin] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const checkAdminStatus = async () => {
      if (!user) {
        console.log('No user found, setting isAdmin to false');
        setIsAdmin(false);
        setLoading(false);
        return;
      }

      console.log('Checking admin status for user:', user.id, user.email);

      try {
        // First check current session
        const { data: { session } } = await supabase.auth.getSession();
        console.log('Current session:', session?.user?.id);

        const { data, error } = await supabase
          .from('user_roles')
          .select('role')
          .eq('user_id', user.id)
          .maybeSingle();

        console.log('User roles query result:', { data, error });

        if (error) {
          console.error('Error checking admin status:', error);
          setIsAdmin(false);
          toast.error('Error checking admin permissions');
        } else {
          const adminStatus = data?.role === 'admin';
          console.log('Admin status:', adminStatus);
          setIsAdmin(adminStatus);
          
          if (!adminStatus) {
            toast.error('You do not have admin privileges');
          }
        }
      } catch (error) {
        console.error('Error checking admin status:', error);
        setIsAdmin(false);
        toast.error('Failed to verify admin status');
      } finally {
        setLoading(false);
      }
    };

    checkAdminStatus();
  }, [user]);

  const logAdminAction = async (action: string, targetTable?: string, targetId?: string, oldData?: any, newData?: any) => {
    if (!user || !isAdmin) return;

    try {
      await supabase.from('admin_audit_logs').insert({
        admin_user_id: user.id,
        action,
        target_table: targetTable,
        target_id: targetId,
        old_data: oldData,
        new_data: newData,
      });
    } catch (error) {
      console.error('Error logging admin action:', error);
    }
  };

  return { isAdmin, loading, logAdminAction };
};
