
import { useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

export const useDataExport = () => {
  const { user } = useAuth();
  const [exportLoading, setExportLoading] = useState<string | null>(null);

  const exportUserData = async (dataType: 'profile' | 'protocols' | 'health' | 'all') => {
    if (!user) {
      toast.error('You must be logged in to export data');
      return;
    }

    setExportLoading(dataType);
    
    try {
      let data: any = {};
      
      if (dataType === 'profile' || dataType === 'all') {
        const { data: profile } = await supabase
          .from('profiles')
          .select('*')
          .eq('id', user.id)
          .single();
        data.profile = profile;
      }

      if (dataType === 'protocols' || dataType === 'all') {
        const { data: protocols } = await supabase
          .from('protocols')
          .select('*')
          .eq('user_id', user.id);
        data.protocols = protocols;
      }

      if (dataType === 'health' || dataType === 'all') {
        const { data: healthLogs } = await supabase
          .from('health_logs')
          .select('*')
          .eq('user_id', user.id);
        data.health_logs = healthLogs;
      }

      // Create and download JSON file
      const exportData = {
        exported_at: new Date().toISOString(),
        user_id: user.id,
        data_type: dataType,
        ...data
      };

      const blob = new Blob([JSON.stringify(exportData, null, 2)], { 
        type: 'application/json' 
      });
      
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `biocalc-${dataType}-export-${new Date().toISOString().split('T')[0]}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);

      toast.success(`${dataType} data exported successfully`);
    } catch (error) {
      console.error('Export error:', error);
      toast.error('Failed to export data');
    } finally {
      setExportLoading(null);
    }
  };

  const exportHealthReport = async () => {
    if (!user) {
      toast.error('You must be logged in to export health report');
      return;
    }

    setExportLoading('health-report');
    
    try {
      const { data: healthLogs } = await supabase
        .from('health_logs')
        .select('*')
        .eq('user_id', user.id)
        .order('logged_at', { ascending: false });

      if (!healthLogs || healthLogs.length === 0) {
        toast.error('No health data found to export');
        return;
      }

      // Create CSV format for health report
      const headers = ['Date', 'Type', 'Value', 'Unit', 'Notes'];
      const csvData = healthLogs.map(log => [
        new Date(log.logged_at || log.created_at).toLocaleDateString(),
        log.log_type,
        log.value || '',
        log.unit || '',
        log.notes || ''
      ]);

      const csvContent = [
        headers.join(','),
        ...csvData.map(row => row.map(cell => `"${cell}"`).join(','))
      ].join('\n');

      const blob = new Blob([csvContent], { type: 'text/csv' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `biocalc-health-report-${new Date().toISOString().split('T')[0]}.csv`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);

      toast.success('Health report exported successfully');
    } catch (error) {
      console.error('Health report export error:', error);
      toast.error('Failed to export health report');
    } finally {
      setExportLoading(null);
    }
  };

  return {
    exportUserData,
    exportHealthReport,
    exportLoading
  };
};
