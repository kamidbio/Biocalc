
import { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

export interface CalculationResult {
  drawUnits: string;
  drawVolume: string;
  concentration: string;
  remainingDoses: number;
}

export interface PeptidePreset {
  id: string;
  peptide_name: string;
  common_dosages: string[];
  typical_concentration: number;
  recommended_syringe_type: string;
  description: string;
  category: string;
}

export interface SavedCalculation {
  id: string;
  calculation_name: string;
  syringe_type: string;
  syringe_units: number;
  syringe_volume: number;
  water_amount: number;
  peptide_amount: number;
  desired_dose: number;
  calculated_draw_units: number;
  calculated_draw_volume: number;
  calculated_concentration: number;
  calculated_remaining_doses: number;
  notes: string;
  is_favorite: boolean;
  created_at: string;
}

export const useCalculator = () => {
  const { user } = useAuth();
  const [presets, setPresets] = useState<PeptidePreset[]>([]);
  const [savedCalculations, setSavedCalculations] = useState<SavedCalculation[]>([]);
  const [loading, setLoading] = useState(false);

  // Load presets and saved calculations
  useEffect(() => {
    loadPresets();
    if (user) {
      loadSavedCalculations();
    }
  }, [user]);

  const loadPresets = async () => {
    try {
      const { data, error } = await supabase
        .from('calculator_presets')
        .select('*')
        .eq('is_active', true)
        .order('peptide_name');

      if (error) throw error;
      
      // Transform the data to match our interface
      const transformedPresets = (data || []).map(preset => ({
        ...preset,
        common_dosages: Array.isArray(preset.common_dosages) 
          ? preset.common_dosages as string[]
          : typeof preset.common_dosages === 'string'
          ? JSON.parse(preset.common_dosages)
          : []
      }));
      
      setPresets(transformedPresets);
    } catch (error) {
      console.error('Error loading presets:', error);
      toast.error('Failed to load peptide presets');
    }
  };

  const loadSavedCalculations = async () => {
    if (!user) return;

    try {
      const { data, error } = await supabase
        .from('calculator_calculations')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setSavedCalculations(data || []);
    } catch (error) {
      console.error('Error loading saved calculations:', error);
      toast.error('Failed to load saved calculations');
    }
  };

  const calculateDosage = (
    syringeType: string,
    units: string,
    waterAmount: string,
    peptideAmount: string,
    desiredDose: string
  ): CalculationResult | null => {
    if (!units || !waterAmount || !peptideAmount || !desiredDose) return null;
    
    // Calculate concentration in mg/ml
    const concentration = parseFloat(peptideAmount) / parseFloat(waterAmount);
    
    // Calculate draw volume in ml
    const drawVolume = parseFloat(desiredDose) / concentration;
    
    // Convert volume to units based on syringe type
    // U-100: 100 units = 1ml, U-40: 40 units = 1ml
    const unitsPerMl = syringeType === 'U-100' ? 100 : 40;
    const drawUnits = drawVolume * unitsPerMl;
    
    // Calculate remaining doses from the vial
    const remainingDoses = parseFloat(waterAmount) / drawVolume;
    
    return {
      drawUnits: drawUnits.toFixed(2),
      drawVolume: drawVolume.toFixed(3),
      concentration: concentration.toFixed(3),
      remainingDoses: Math.floor(remainingDoses)
    };
  };

  const saveCalculation = async (
    calculationData: {
      calculationName?: string;
      syringeType: string;
      syringeUnits: string;
      syringeVolume: string;
      waterAmount: string;
      peptideAmount: string;
      desiredDose: string;
      notes?: string;
    },
    result: CalculationResult
  ) => {
    if (!user) {
      toast.error('Please log in to save calculations');
      return;
    }

    console.log('Saving calculation with data:', calculationData);
    console.log('Calculation result:', result);

    setLoading(true);
    try {
      const insertData = {
        user_id: user.id,
        calculation_name: calculationData.calculationName || `Calculation ${new Date().toLocaleDateString()}`,
        syringe_type: calculationData.syringeType || '1ml', // Provide default if missing
        syringe_units: parseFloat(calculationData.syringeUnits) || 0,
        syringe_volume: parseFloat(calculationData.syringeVolume) || 0,
        water_amount: parseFloat(calculationData.waterAmount) || 0,
        peptide_amount: parseFloat(calculationData.peptideAmount) || 0,
        desired_dose: parseFloat(calculationData.desiredDose) || 0,
        calculated_draw_units: parseFloat(result.drawUnits) || 0,
        calculated_draw_volume: parseFloat(result.drawVolume) || 0,
        calculated_concentration: parseFloat(result.concentration) || 0,
        calculated_remaining_doses: result.remainingDoses || 0,
        notes: calculationData.notes || ''
      };

      console.log('Insert data:', insertData);

      const { error } = await supabase
        .from('calculator_calculations')
        .insert(insertData);

      if (error) {
        console.error('Supabase error:', error);
        throw error;
      }

      toast.success('Calculation saved successfully');
      loadSavedCalculations(); // Reload the list
    } catch (error) {
      console.error('Error saving calculation:', error);
      toast.error('Failed to save calculation');
    } finally {
      setLoading(false);
    }
  };

  const deleteCalculation = async (calculationId: string) => {
    if (!user) return;

    setLoading(true);
    try {
      const { error } = await supabase
        .from('calculator_calculations')
        .delete()
        .eq('id', calculationId)
        .eq('user_id', user.id);

      if (error) throw error;

      toast.success('Calculation deleted');
      loadSavedCalculations();
    } catch (error) {
      console.error('Error deleting calculation:', error);
      toast.error('Failed to delete calculation');
    } finally {
      setLoading(false);
    }
  };

  const toggleFavorite = async (calculationId: string, isFavorite: boolean) => {
    if (!user) return;

    try {
      const { error } = await supabase
        .from('calculator_calculations')
        .update({ is_favorite: !isFavorite })
        .eq('id', calculationId)
        .eq('user_id', user.id);

      if (error) throw error;

      toast.success(isFavorite ? 'Removed from favorites' : 'Added to favorites');
      loadSavedCalculations();
    } catch (error) {
      console.error('Error updating favorite:', error);
      toast.error('Failed to update favorite');
    }
  };

  const createReminder = async (reminderData: {
    reminderName: string;
    frequencyType: string;
    frequencyValue?: string;
    nextReminder: Date;
    notes?: string;
  }, calculationId?: string) => {
    if (!user) {
      toast.error('Please log in to create reminders');
      return;
    }

    setLoading(true);
    try {
      const { error } = await supabase
        .from('calculator_reminders')
        .insert({
          user_id: user.id,
          calculation_id: calculationId || null,
          reminder_name: reminderData.reminderName,
          frequency_type: reminderData.frequencyType,
          frequency_value: reminderData.frequencyValue,
          next_reminder: reminderData.nextReminder.toISOString(),
          notes: reminderData.notes || ''
        });

      if (error) throw error;

      toast.success('Reminder created successfully');
    } catch (error) {
      console.error('Error creating reminder:', error);
      toast.error('Failed to create reminder');
    } finally {
      setLoading(false);
    }
  };

  return {
    presets,
    savedCalculations,
    loading,
    calculateDosage,
    saveCalculation,
    deleteCalculation,
    toggleFavorite,
    createReminder,
    loadSavedCalculations
  };
};
