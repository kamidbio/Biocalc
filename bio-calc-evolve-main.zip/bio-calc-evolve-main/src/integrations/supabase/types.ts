export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instanciate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "12.2.3 (519615d)"
  }
  public: {
    Tables: {
      admin_audit_logs: {
        Row: {
          action: string
          admin_user_id: string
          created_at: string | null
          id: string
          ip_address: unknown | null
          new_data: Json | null
          old_data: Json | null
          target_id: string | null
          target_table: string | null
          user_agent: string | null
        }
        Insert: {
          action: string
          admin_user_id: string
          created_at?: string | null
          id?: string
          ip_address?: unknown | null
          new_data?: Json | null
          old_data?: Json | null
          target_id?: string | null
          target_table?: string | null
          user_agent?: string | null
        }
        Update: {
          action?: string
          admin_user_id?: string
          created_at?: string | null
          id?: string
          ip_address?: unknown | null
          new_data?: Json | null
          old_data?: Json | null
          target_id?: string | null
          target_table?: string | null
          user_agent?: string | null
        }
        Relationships: []
      }
      admin_registration_tokens: {
        Row: {
          created_at: string
          created_by: string | null
          expires_at: string
          id: string
          is_used: boolean
          token: string
          used_by: string | null
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          expires_at: string
          id?: string
          is_used?: boolean
          token: string
          used_by?: string | null
        }
        Update: {
          created_at?: string
          created_by?: string | null
          expires_at?: string
          id?: string
          is_used?: boolean
          token?: string
          used_by?: string | null
        }
        Relationships: []
      }
      admin_settings: {
        Row: {
          affects_backend: boolean | null
          affects_frontend: boolean | null
          category: string | null
          created_at: string
          description: string | null
          id: string
          is_active: boolean
          priority: number | null
          setting_key: string
          setting_value: Json
          updated_at: string
        }
        Insert: {
          affects_backend?: boolean | null
          affects_frontend?: boolean | null
          category?: string | null
          created_at?: string
          description?: string | null
          id?: string
          is_active?: boolean
          priority?: number | null
          setting_key: string
          setting_value: Json
          updated_at?: string
        }
        Update: {
          affects_backend?: boolean | null
          affects_frontend?: boolean | null
          category?: string | null
          created_at?: string
          description?: string | null
          id?: string
          is_active?: boolean
          priority?: number | null
          setting_key?: string
          setting_value?: Json
          updated_at?: string
        }
        Relationships: []
      }
      calculator_calculations: {
        Row: {
          calculated_concentration: number | null
          calculated_draw_units: number | null
          calculated_draw_volume: number | null
          calculated_remaining_doses: number | null
          calculation_name: string | null
          created_at: string
          desired_dose: number
          id: string
          is_favorite: boolean | null
          notes: string | null
          peptide_amount: number
          syringe_type: string
          syringe_units: number | null
          syringe_volume: number | null
          updated_at: string
          user_id: string
          water_amount: number
        }
        Insert: {
          calculated_concentration?: number | null
          calculated_draw_units?: number | null
          calculated_draw_volume?: number | null
          calculated_remaining_doses?: number | null
          calculation_name?: string | null
          created_at?: string
          desired_dose: number
          id?: string
          is_favorite?: boolean | null
          notes?: string | null
          peptide_amount: number
          syringe_type: string
          syringe_units?: number | null
          syringe_volume?: number | null
          updated_at?: string
          user_id: string
          water_amount: number
        }
        Update: {
          calculated_concentration?: number | null
          calculated_draw_units?: number | null
          calculated_draw_volume?: number | null
          calculated_remaining_doses?: number | null
          calculation_name?: string | null
          created_at?: string
          desired_dose?: number
          id?: string
          is_favorite?: boolean | null
          notes?: string | null
          peptide_amount?: number
          syringe_type?: string
          syringe_units?: number | null
          syringe_volume?: number | null
          updated_at?: string
          user_id?: string
          water_amount?: number
        }
        Relationships: []
      }
      calculator_presets: {
        Row: {
          category: string | null
          common_dosages: Json
          created_at: string
          created_by: string | null
          description: string | null
          id: string
          is_active: boolean | null
          peptide_name: string
          recommended_syringe_type: string | null
          typical_concentration: number | null
          updated_at: string
        }
        Insert: {
          category?: string | null
          common_dosages: Json
          created_at?: string
          created_by?: string | null
          description?: string | null
          id?: string
          is_active?: boolean | null
          peptide_name: string
          recommended_syringe_type?: string | null
          typical_concentration?: number | null
          updated_at?: string
        }
        Update: {
          category?: string | null
          common_dosages?: Json
          created_at?: string
          created_by?: string | null
          description?: string | null
          id?: string
          is_active?: boolean | null
          peptide_name?: string
          recommended_syringe_type?: string | null
          typical_concentration?: number | null
          updated_at?: string
        }
        Relationships: []
      }
      calculator_reminders: {
        Row: {
          calculation_id: string | null
          created_at: string
          frequency_type: string
          frequency_value: string | null
          id: string
          is_active: boolean | null
          next_reminder: string
          notes: string | null
          reminder_name: string
          updated_at: string
          user_id: string
        }
        Insert: {
          calculation_id?: string | null
          created_at?: string
          frequency_type: string
          frequency_value?: string | null
          id?: string
          is_active?: boolean | null
          next_reminder: string
          notes?: string | null
          reminder_name: string
          updated_at?: string
          user_id: string
        }
        Update: {
          calculation_id?: string | null
          created_at?: string
          frequency_type?: string
          frequency_value?: string | null
          id?: string
          is_active?: boolean | null
          next_reminder?: string
          notes?: string | null
          reminder_name?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "calculator_reminders_calculation_id_fkey"
            columns: ["calculation_id"]
            isOneToOne: false
            referencedRelation: "calculator_calculations"
            referencedColumns: ["id"]
          },
        ]
      }
      calculator_settings: {
        Row: {
          created_at: string | null
          description: string | null
          id: string
          is_active: boolean | null
          setting_key: string
          setting_value: Json
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          description?: string | null
          id?: string
          is_active?: boolean | null
          setting_key: string
          setting_value: Json
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          description?: string | null
          id?: string
          is_active?: boolean | null
          setting_key?: string
          setting_value?: Json
          updated_at?: string | null
        }
        Relationships: []
      }
      health_logs: {
        Row: {
          created_at: string | null
          id: string
          log_type: string
          logged_at: string | null
          notes: string | null
          unit: string | null
          user_id: string
          value: number | null
        }
        Insert: {
          created_at?: string | null
          id?: string
          log_type: string
          logged_at?: string | null
          notes?: string | null
          unit?: string | null
          user_id: string
          value?: number | null
        }
        Update: {
          created_at?: string | null
          id?: string
          log_type?: string
          logged_at?: string | null
          notes?: string | null
          unit?: string | null
          user_id?: string
          value?: number | null
        }
        Relationships: []
      }
      homepage_sections: {
        Row: {
          background_style: Json | null
          content: Json
          created_at: string
          created_by: string | null
          display_order: number
          id: string
          is_active: boolean
          layout_config: Json | null
          section_type: string
          title: string
          updated_at: string
        }
        Insert: {
          background_style?: Json | null
          content: Json
          created_at?: string
          created_by?: string | null
          display_order?: number
          id?: string
          is_active?: boolean
          layout_config?: Json | null
          section_type?: string
          title: string
          updated_at?: string
        }
        Update: {
          background_style?: Json | null
          content?: Json
          created_at?: string
          created_by?: string | null
          display_order?: number
          id?: string
          is_active?: boolean
          layout_config?: Json | null
          section_type?: string
          title?: string
          updated_at?: string
        }
        Relationships: []
      }
      library_resources: {
        Row: {
          category: string | null
          content: Json | null
          created_at: string | null
          created_by: string | null
          description: string | null
          file_size: number | null
          file_type: string | null
          file_url: string | null
          frequencies: Json | null
          id: string
          is_active: boolean | null
          stacks: Json | null
          tags: string[] | null
          title: string
          updated_at: string | null
        }
        Insert: {
          category?: string | null
          content?: Json | null
          created_at?: string | null
          created_by?: string | null
          description?: string | null
          file_size?: number | null
          file_type?: string | null
          file_url?: string | null
          frequencies?: Json | null
          id?: string
          is_active?: boolean | null
          stacks?: Json | null
          tags?: string[] | null
          title: string
          updated_at?: string | null
        }
        Update: {
          category?: string | null
          content?: Json | null
          created_at?: string | null
          created_by?: string | null
          description?: string | null
          file_size?: number | null
          file_type?: string | null
          file_url?: string | null
          frequencies?: Json | null
          id?: string
          is_active?: boolean | null
          stacks?: Json | null
          tags?: string[] | null
          title?: string
          updated_at?: string | null
        }
        Relationships: []
      }
      pages: {
        Row: {
          content: Json | null
          created_at: string | null
          created_by: string | null
          id: string
          is_active: boolean | null
          layout_config: Json | null
          slug: string
          title: string
          updated_at: string | null
        }
        Insert: {
          content?: Json | null
          created_at?: string | null
          created_by?: string | null
          id?: string
          is_active?: boolean | null
          layout_config?: Json | null
          slug: string
          title: string
          updated_at?: string | null
        }
        Update: {
          content?: Json | null
          created_at?: string | null
          created_by?: string | null
          id?: string
          is_active?: boolean | null
          layout_config?: Json | null
          slug?: string
          title?: string
          updated_at?: string | null
        }
        Relationships: []
      }
      profiles: {
        Row: {
          age: number | null
          avatar_url: string | null
          created_at: string
          email: string | null
          full_name: string | null
          height: number | null
          id: string
          phone: string | null
          updated_at: string
          weight: number | null
        }
        Insert: {
          age?: number | null
          avatar_url?: string | null
          created_at?: string
          email?: string | null
          full_name?: string | null
          height?: number | null
          id: string
          phone?: string | null
          updated_at?: string
          weight?: number | null
        }
        Update: {
          age?: number | null
          avatar_url?: string | null
          created_at?: string
          email?: string | null
          full_name?: string | null
          height?: number | null
          id?: string
          phone?: string | null
          updated_at?: string
          weight?: number | null
        }
        Relationships: []
      }
      protocols: {
        Row: {
          calculator_settings: Json | null
          created_at: string | null
          id: string
          is_active: boolean | null
          name: string
          notes: string | null
          peptide_data: Json
          schedule: Json | null
          updated_at: string | null
          user_id: string | null
        }
        Insert: {
          calculator_settings?: Json | null
          created_at?: string | null
          id?: string
          is_active?: boolean | null
          name: string
          notes?: string | null
          peptide_data: Json
          schedule?: Json | null
          updated_at?: string | null
          user_id?: string | null
        }
        Update: {
          calculator_settings?: Json | null
          created_at?: string | null
          id?: string
          is_active?: boolean | null
          name?: string
          notes?: string | null
          peptide_data?: Json
          schedule?: Json | null
          updated_at?: string | null
          user_id?: string | null
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          created_at: string | null
          id: string
          role: Database["public"]["Enums"]["user_role"]
          updated_at: string | null
          user_id: string
        }
        Insert: {
          created_at?: string | null
          id?: string
          role?: Database["public"]["Enums"]["user_role"]
          updated_at?: string | null
          user_id: string
        }
        Update: {
          created_at?: string | null
          id?: string
          role?: Database["public"]["Enums"]["user_role"]
          updated_at?: string | null
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      admin_settings_by_category: {
        Row: {
          category: string | null
          last_updated: string | null
          setting_keys: string[] | null
          settings: Json | null
        }
        Relationships: []
      }
    }
    Functions: {
      get_active_admin_settings: {
        Args: Record<PropertyKey, never>
        Returns: Json
      }
      get_maintenance_status: {
        Args: Record<PropertyKey, never>
        Returns: Json
      }
      get_user_role: {
        Args: { user_uuid: string }
        Returns: Database["public"]["Enums"]["user_role"]
      }
      is_admin: {
        Args: { user_uuid: string }
        Returns: boolean
      }
      is_feature_enabled: {
        Args: { feature_key: string }
        Returns: boolean
      }
    }
    Enums: {
      user_role: "admin" | "user"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      user_role: ["admin", "user"],
    },
  },
} as const
