import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AuthProvider } from "@/contexts/AuthContext";
import ErrorBoundary from "@/components/ErrorBoundary";
import ProtectedRoute from "@/components/ProtectedRoute";
import AdminRoute from "@/components/admin/AdminRoute";
import AdminLayout from "@/components/admin/AdminLayout";
import Navigation from "@/components/Navigation";
import Index from "./pages/Index";
import Calculator from "./pages/Calculator";
import Protocols from "./pages/Protocols";
import Tracking from "./pages/Tracking";
import Education from "./pages/Education";
import Settings from "./pages/Settings";
import Auth from "./pages/Auth";
import AdminRegistration from "./pages/AdminRegistration";
import AdminDashboard from "./pages/admin/AdminDashboard";
import UserManagement from "./pages/admin/UserManagement";
import PageManagement from "./pages/admin/PageManagement";
import ResourceManagement from "./pages/admin/ResourceManagement";
import AdminCalculatorSettings from "./pages/admin/AdminCalculatorSettings";
import ProtocolOversight from "./pages/admin/ProtocolOversight";
import HealthData from "./pages/admin/HealthData";
import AuditLogs from "./pages/admin/AuditLogs";
import AdminSettings from "./pages/admin/AdminSettings";
import HomepageSettings from "./pages/admin/HomepageSettings";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: 1,
      refetchOnWindowFocus: false,
    },
  },
});

function App() {
  return (
    <ErrorBoundary>
      <QueryClientProvider client={queryClient}>
        <AuthProvider>
          <TooltipProvider>
            <Toaster />
            <BrowserRouter>
              <div className="flex flex-col min-h-screen">
                <Routes>
                  {/* Public routes */}
                  <Route path="/auth" element={<Auth />} />
                  <Route path="/admin-registration" element={<AdminRegistration />} />
                  
                  {/* Protected routes with navigation */}
                  <Route path="/" element={
                    <ProtectedRoute>
                      <div className="flex flex-col min-h-screen">
                        <Navigation />
                        <main className="flex-1 page-content">
                          <Index />
                        </main>
                      </div>
                    </ProtectedRoute>
                  } />
                  <Route path="/calculator" element={
                    <ProtectedRoute>
                      <div className="flex flex-col min-h-screen">
                        <Navigation />
                        <main className="flex-1 page-content">
                          <Calculator />
                        </main>
                      </div>
                    </ProtectedRoute>
                  } />
                  <Route path="/protocols" element={
                    <ProtectedRoute>
                      <div className="flex flex-col min-h-screen">
                        <Navigation />
                        <main className="flex-1 page-content">
                          <Protocols />
                        </main>
                      </div>
                    </ProtectedRoute>
                  } />
                  <Route path="/tracking" element={
                    <ProtectedRoute>
                      <div className="flex flex-col min-h-screen">
                        <Navigation />
                        <main className="flex-1 page-content">
                          <Tracking />
                        </main>
                      </div>
                    </ProtectedRoute>
                  } />
                  <Route path="/education" element={
                    <ProtectedRoute>
                      <div className="flex flex-col min-h-screen">
                        <Navigation />
                        <main className="flex-1 page-content">
                          <Education />
                        </main>
                      </div>
                    </ProtectedRoute>
                  } />
                  <Route path="/settings" element={
                    <ProtectedRoute>
                      <div className="flex flex-col min-h-screen">
                        <Navigation />
                        <main className="flex-1 page-content">
                          <Settings />
                        </main>
                      </div>
                    </ProtectedRoute>
                  } />
                  
                  {/* Admin routes */}
                  <Route path="/admin" element={
                    <AdminRoute>
                      <AdminLayout>
                        <AdminDashboard />
                      </AdminLayout>
                    </AdminRoute>
                  } />
                  <Route path="/admin/homepage" element={
                    <AdminRoute>
                      <AdminLayout>
                        <HomepageSettings />
                      </AdminLayout>
                    </AdminRoute>
                  } />
                  <Route path="/admin/users" element={
                    <AdminRoute>
                      <AdminLayout>
                        <UserManagement />
                      </AdminLayout>
                    </AdminRoute>
                  } />
                  <Route path="/admin/pages" element={
                    <AdminRoute>
                      <AdminLayout>
                        <PageManagement />
                      </AdminLayout>
                    </AdminRoute>
                  } />
                  <Route path="/admin/resources" element={
                    <AdminRoute>
                      <AdminLayout>
                        <ResourceManagement />
                      </AdminLayout>
                    </AdminRoute>
                  } />
                  <Route path="/admin/protocols" element={
                    <AdminRoute>
                      <AdminLayout>
                        <ProtocolOversight />
                      </AdminLayout>
                    </AdminRoute>
                  } />
                  <Route path="/admin/calculator" element={
                    <AdminRoute>
                      <AdminLayout>
                        <AdminCalculatorSettings />
                      </AdminLayout>
                    </AdminRoute>
                  } />
                  <Route path="/admin/health-logs" element={
                    <AdminRoute>
                      <AdminLayout>
                        <HealthData />
                      </AdminLayout>
                    </AdminRoute>
                  } />
                  <Route path="/admin/audit" element={
                    <AdminRoute>
                      <AdminLayout>
                        <AuditLogs />
                      </AdminLayout>
                    </AdminRoute>
                  } />
                  <Route path="/admin/settings" element={
                    <AdminRoute>
                      <AdminLayout>
                        <AdminSettings />
                      </AdminLayout>
                    </AdminRoute>
                  } />
                  
                  {/* 404 route */}
                  <Route path="*" element={<NotFound />} />
                </Routes>
              </div>
            </BrowserRouter>
          </TooltipProvider>
        </AuthProvider>
      </QueryClientProvider>
    </ErrorBoundary>
  );
}

export default App;
