
import React from 'react';
import AdminSidebar from './AdminSidebar';
import UserMenu from '../UserMenu';

interface AdminLayoutProps {
  children: React.ReactNode;
}

const AdminLayout: React.FC<AdminLayoutProps> = ({ children }) => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background/95 to-primary/5">
      <div className="flex">
        <AdminSidebar />
        <div className="flex-1">
          <header className="glass-effect border-b border-purple-400/20 p-4">
            <div className="flex justify-between items-center">
              <h1 className="text-2xl font-bold text-white">Admin Dashboard</h1>
              <UserMenu />
            </div>
          </header>
          <main className="p-6">
            {children}
          </main>
        </div>
      </div>
    </div>
  );
};

export default AdminLayout;
