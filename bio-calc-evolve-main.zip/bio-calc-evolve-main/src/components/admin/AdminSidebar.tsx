
import React from 'react';
import { NavLink } from 'react-router-dom';
import { 
  Users, 
  FileText, 
  BookOpen, 
  Calculator, 
  Activity, 
  Settings, 
  Shield,
  BarChart3,
  FileCheck,
  Home
} from 'lucide-react';

const AdminSidebar = () => {
  const adminMenuItems = [
    { to: '/admin', icon: BarChart3, label: 'Dashboard', exact: true },
    { to: '/admin/homepage', icon: Home, label: 'Homepage Settings' },
    { to: '/admin/users', icon: Users, label: 'User Management' },
    { to: '/admin/pages', icon: FileText, label: 'Page Management' },
    { to: '/admin/resources', icon: BookOpen, label: 'Library Resources' },
    { to: '/admin/protocols', icon: FileCheck, label: 'Protocol Oversight' },
    { to: '/admin/calculator', icon: Calculator, label: 'Calculator Settings' },
    { to: '/admin/health-logs', icon: Activity, label: 'Health Data' },
    { to: '/admin/audit', icon: Shield, label: 'Audit Logs' },
    { to: '/admin/settings', icon: Settings, label: 'Admin Settings' },
  ];

  return (
    <div className="w-64 glass-card h-screen sticky top-0 p-6">
      <div className="mb-8">
        <h2 className="text-xl font-bold text-white mb-2">Admin Panel</h2>
        <p className="text-purple-300 text-sm">Manage your application</p>
      </div>

      <nav className="space-y-2">
        {adminMenuItems.map(({ to, icon: Icon, label, exact }) => (
          <NavLink
            key={to}
            to={to}
            end={exact}
            className={({ isActive }) =>
              `flex items-center space-x-3 px-4 py-3 rounded-xl transition-all duration-200 ${
                isActive
                  ? 'bg-gradient-to-r from-purple-500/20 to-indigo-500/20 text-purple-200 border border-purple-400/30'
                  : 'text-purple-300/80 hover:text-purple-200 hover:bg-white/10'
              }`
            }
          >
            <Icon className="h-5 w-5" />
            <span className="font-medium">{label}</span>
          </NavLink>
        ))}
      </nav>
    </div>
  );
};

export default AdminSidebar;
