
import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Bell } from 'lucide-react';
import { toast } from 'sonner';

const NotificationSettings = () => {
  const [settings, setSettings] = useState({
    emailNotifications: true,
    pushNotifications: false,
    reminderAlerts: true,
    weeklyReports: false
  });

  const handleToggle = (key: keyof typeof settings) => {
    setSettings(prev => ({
      ...prev,
      [key]: !prev[key]
    }));
    toast.success(`${key.replace(/([A-Z])/g, ' $1').toLowerCase()} ${!settings[key] ? 'enabled' : 'disabled'}`);
  };
  return (
    <Card className="glass-effect border-primary/20">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Bell className="h-5 w-5 text-primary" />
          Notification Settings
        </CardTitle>
        <CardDescription>Configure your reminder and alert preferences</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <Label htmlFor="email-notifications">Email Notifications</Label>
            <p className="text-sm text-muted-foreground">Receive updates via email</p>
          </div>
          <Switch 
            id="email-notifications" 
            checked={settings.emailNotifications}
            onCheckedChange={() => handleToggle('emailNotifications')}
          />
        </div>
        <div className="flex items-center justify-between">
          <div>
            <Label htmlFor="push-notifications">Push Notifications</Label>
            <p className="text-sm text-muted-foreground">Receive browser notifications</p>
          </div>
          <Switch 
            id="push-notifications" 
            checked={settings.pushNotifications}
            onCheckedChange={() => handleToggle('pushNotifications')}
          />
        </div>
        <div className="flex items-center justify-between">
          <div>
            <Label htmlFor="reminder-alerts">Reminder Alerts</Label>
            <p className="text-sm text-muted-foreground">Get notified about protocol schedules</p>
          </div>
          <Switch 
            id="reminder-alerts" 
            checked={settings.reminderAlerts}
            onCheckedChange={() => handleToggle('reminderAlerts')}
          />
        </div>
        <div className="flex items-center justify-between">
          <div>
            <Label htmlFor="weekly-reports">Weekly Reports</Label>
            <p className="text-sm text-muted-foreground">Receive weekly progress summaries</p>
          </div>
          <Switch 
            id="weekly-reports" 
            checked={settings.weeklyReports}
            onCheckedChange={() => handleToggle('weeklyReports')}
          />
        </div>
      </CardContent>
    </Card>
  );
};

export default NotificationSettings;
