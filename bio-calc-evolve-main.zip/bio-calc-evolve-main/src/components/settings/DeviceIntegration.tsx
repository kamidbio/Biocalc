
import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Smartphone, Heart, Activity, Watch } from 'lucide-react';
import { toast } from 'sonner';

const DeviceIntegration = () => {
  const [devices, setDevices] = useState([
    { 
      name: 'Apple Health', 
      status: 'Not Connected', 
      color: 'text-muted-foreground',
      icon: Heart,
      description: 'Sync health data from iPhone and Apple Watch'
    },
    { 
      name: 'Fitbit', 
      status: 'Not Connected', 
      color: 'text-muted-foreground',
      icon: Activity,
      description: 'Track activity, sleep, and heart rate'
    },
    { 
      name: 'Oura Ring', 
      status: 'Not Connected', 
      color: 'text-muted-foreground',
      icon: Watch,
      description: 'Monitor sleep quality and recovery metrics'
    },
    { 
      name: 'WHOOP', 
      status: 'Not Connected', 
      color: 'text-muted-foreground',
      icon: Activity,
      description: 'Track strain, recovery, and sleep performance'
    }
  ]);

  const handleDeviceToggle = (deviceName: string) => {
    setDevices(prev => prev.map(device => {
      if (device.name === deviceName) {
        const newStatus = device.status === 'Connected' ? 'Not Connected' : 'Connected';
        const newColor = newStatus === 'Connected' ? 'text-green-400' : 'text-muted-foreground';
        
        // Simulate API call for device connection
        if (newStatus === 'Connected') {
          toast.success(`${deviceName} connected successfully`);
        } else {
          toast.success(`${deviceName} disconnected`);
        }
        
        return { ...device, status: newStatus, color: newColor };
      }
      return device;
    }));
  };

  const getConnectionSwitch = (device: any) => {
    return device.status === 'Connected';
  };

  return (
    <Card className="glass-effect border-primary/20">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Smartphone className="h-5 w-5 text-primary" />
          Device Integration
        </CardTitle>
        <CardDescription>Connect your health devices for automatic data sync</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {devices.map((device) => {
          const IconComponent = device.icon;
          return (
            <div key={device.name} className="flex items-center justify-between p-4 rounded-lg bg-card/50 border border-primary/10">
              <div className="flex items-center gap-4">
                <div className="p-2 rounded-lg bg-primary/10">
                  <IconComponent className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <div className="font-medium text-foreground">{device.name}</div>
                  <div className="text-sm text-muted-foreground">{device.description}</div>
                  <div className={`text-sm font-medium ${device.color}`}>{device.status}</div>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <Switch 
                  checked={getConnectionSwitch(device)}
                  onCheckedChange={() => handleDeviceToggle(device.name)}
                />
              </div>
            </div>
          );
        })}

        <div className="pt-4 border-t border-primary/10">
          <p className="text-sm text-muted-foreground">
            Device connections are securely managed through official APIs. Your health data remains private and encrypted.
          </p>
        </div>
      </CardContent>
    </Card>
  );
};

export default DeviceIntegration;
