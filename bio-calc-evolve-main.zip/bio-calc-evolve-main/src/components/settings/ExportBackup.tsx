
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Download } from 'lucide-react';

interface ExportBackupProps {
  exportUserData: (dataType: 'profile' | 'protocols' | 'health' | 'all') => Promise<void>;
  exportHealthReport: () => Promise<void>;
  exportLoading: string | null;
}

const ExportBackup = ({ exportUserData, exportHealthReport, exportLoading }: ExportBackupProps) => {
  return (
    <Card className="glass-effect border-primary/20">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Download className="h-5 w-5 text-primary" />
          Export & Backup
        </CardTitle>
        <CardDescription>Download your health reports and backup data</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Button 
            variant="outline"
            onClick={exportHealthReport}
            disabled={exportLoading === 'health-report'}
          >
            {exportLoading === 'health-report' ? 'Exporting...' : 'Export Health Report'}
          </Button>
          <Button 
            variant="outline"
            onClick={() => exportUserData('protocols')}
            disabled={exportLoading === 'protocols'}
          >
            {exportLoading === 'protocols' ? 'Exporting...' : 'Download Protocol Data'}
          </Button>
          <Button 
            variant="outline"
            onClick={() => exportUserData('health')}
            disabled={exportLoading === 'health'}
          >
            {exportLoading === 'health' ? 'Exporting...' : 'Export Health Logs'}
          </Button>
          <Button 
            variant="outline"
            onClick={() => exportUserData('all')}
            disabled={exportLoading === 'all'}
          >
            {exportLoading === 'all' ? 'Exporting...' : 'Full Data Backup'}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default ExportBackup;
