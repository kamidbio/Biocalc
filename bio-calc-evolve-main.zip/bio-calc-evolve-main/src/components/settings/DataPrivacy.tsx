
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Shield } from 'lucide-react';

interface DataPrivacyProps {
  exportUserData: (dataType: 'profile' | 'protocols' | 'health' | 'all') => Promise<void>;
  exportLoading: string | null;
}

const DataPrivacy = ({ exportUserData, exportLoading }: DataPrivacyProps) => {
  return (
    <Card className="glass-effect border-primary/20">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Shield className="h-5 w-5 text-primary" />
          Data & Privacy
        </CardTitle>
        <CardDescription>Manage your data and privacy preferences</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <Label htmlFor="data-analytics">Usage Analytics</Label>
            <p className="text-sm text-muted-foreground">Help improve the app by sharing usage data</p>
          </div>
          <Switch id="data-analytics" />
        </div>
        <div className="flex items-center justify-between">
          <div>
            <Label htmlFor="community-data">Community Contributions</Label>
            <p className="text-sm text-muted-foreground">Contribute anonymized data to community insights</p>
          </div>
          <Switch id="community-data" />
        </div>
        <div className="flex justify-between">
          <Button 
            variant="outline" 
            onClick={() => exportUserData('all')}
            disabled={exportLoading === 'all'}
          >
            {exportLoading === 'all' ? 'Exporting...' : 'Export Data'}
          </Button>
          <Button variant="outline">Delete Account</Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default DataPrivacy;
