
import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Stethoscope, Settings } from 'lucide-react';
import { toast } from 'sonner';

const TelehealthIntegration = () => {
  const [settings, setSettings] = useState({
    dataSharing: false,
    labReminders: true,
    providerAccess: false
  });

  const [providerConfig, setProviderConfig] = useState({
    providerName: '',
    providerEmail: '',
    accessLevel: 'basic'
  });

  const [isConfigOpen, setIsConfigOpen] = useState(false);

  const handleToggle = (key: keyof typeof settings) => {
    setSettings(prev => ({
      ...prev,
      [key]: !prev[key]
    }));
    toast.success(`${key === 'dataSharing' ? 'Data sharing' : key === 'labReminders' ? 'Lab reminders' : 'Provider access'} ${!settings[key] ? 'enabled' : 'disabled'}`);
  };

  const handleProviderConfig = () => {
    // Simulate saving provider configuration
    if (providerConfig.providerName && providerConfig.providerEmail) {
      toast.success('Provider access configured successfully');
      setSettings(prev => ({ ...prev, providerAccess: true }));
      setIsConfigOpen(false);
    } else {
      toast.error('Please fill in all provider details');
    }
  };

  return (
    <Card className="glass-effect border-primary/20">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Stethoscope className="h-5 w-5 text-primary" />
          Telehealth Integration
        </CardTitle>
        <CardDescription>Connect with healthcare providers for lab coordination</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="flex items-center justify-between p-4 rounded-lg bg-card/50 border border-primary/10">
          <div>
            <Label htmlFor="telehealth-sync">Automatic Data Sharing</Label>
            <p className="text-sm text-muted-foreground">Share health data with your healthcare provider</p>
          </div>
          <Switch 
            id="telehealth-sync" 
            checked={settings.dataSharing}
            onCheckedChange={() => handleToggle('dataSharing')}
          />
        </div>

        <div className="flex items-center justify-between p-4 rounded-lg bg-card/50 border border-primary/10">
          <div>
            <Label htmlFor="lab-reminders">Lab Draw Reminders</Label>
            <p className="text-sm text-muted-foreground">Get reminded about scheduled lab work</p>
          </div>
          <Switch 
            id="lab-reminders" 
            checked={settings.labReminders}
            onCheckedChange={() => handleToggle('labReminders')}
          />
        </div>

        <div className="p-4 rounded-lg bg-card/50 border border-primary/10">
          <div className="flex items-center justify-between mb-4">
            <div>
              <Label>Provider Access Configuration</Label>
              <p className="text-sm text-muted-foreground">
                {settings.providerAccess ? 'Provider access is configured' : 'Configure healthcare provider access'}
              </p>
            </div>
            <div className={`px-2 py-1 rounded text-xs font-medium ${
              settings.providerAccess ? 'bg-green-500/20 text-green-400' : 'bg-gray-500/20 text-gray-400'
            }`}>
              {settings.providerAccess ? 'Active' : 'Inactive'}
            </div>
          </div>

          <Dialog open={isConfigOpen} onOpenChange={setIsConfigOpen}>
            <DialogTrigger asChild>
              <Button variant="outline" className="w-full">
                <Settings className="h-4 w-4 mr-2" />
                Configure Provider Access
              </Button>
            </DialogTrigger>
            <DialogContent className="glass-effect border-primary/20">
              <DialogHeader>
                <DialogTitle>Configure Provider Access</DialogTitle>
                <DialogDescription>
                  Set up secure access for your healthcare provider to view your health data and protocols.
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="provider-name">Provider Name</Label>
                  <Input 
                    id="provider-name"
                    placeholder="Dr. Smith / ABC Medical Center"
                    value={providerConfig.providerName}
                    onChange={(e) => setProviderConfig(prev => ({ ...prev, providerName: e.target.value }))}
                  />
                </div>
                <div>
                  <Label htmlFor="provider-email">Provider Email</Label>
                  <Input 
                    id="provider-email"
                    type="email"
                    placeholder="doctor@example.com"
                    value={providerConfig.providerEmail}
                    onChange={(e) => setProviderConfig(prev => ({ ...prev, providerEmail: e.target.value }))}
                  />
                </div>
                <div className="flex gap-3">
                  <Button onClick={handleProviderConfig} className="flex-1">
                    Save Configuration
                  </Button>
                  <Button variant="outline" onClick={() => setIsConfigOpen(false)}>
                    Cancel
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        <div className="pt-4 border-t border-primary/10">
          <p className="text-sm text-muted-foreground">
            All telehealth integrations are HIPAA compliant and use end-to-end encryption for data security.
          </p>
        </div>
      </CardContent>
    </Card>
  );
};

export default TelehealthIntegration;
