
import { NavLink } from 'react-router-dom';
import { Calculator, User, BookOpen, Activity, Settings, Home } from 'lucide-react';
import UserMenu from './UserMenu';

const Navigation = () => {
  const navItems = [
    { to: '/', icon: Home, label: 'Home' },
    { to: '/calculator', icon: Calculator, label: 'Calculator' },
    { to: '/protocols', icon: BookOpen, label: 'Protocols' },
    { to: '/tracking', icon: Activity, label: 'Tracking' },
    { to: '/education', icon: User, label: 'Education' },
    { to: '/settings', icon: Settings, label: 'Settings' },
  ];

  return (
    <>
      {/* Desktop Navigation - Top Center */}
      <nav className="hidden md:flex fixed top-6 left-1/2 transform -translate-x-1/2 z-50 bg-white/10 backdrop-blur-xl rounded-full px-6 py-3 border border-purple-400/20 shadow-2xl">
        <div className="flex items-center space-x-6">
          <div className="flex space-x-6">
            {navItems.map(({ to, icon: Icon, label }) => (
              <NavLink
                key={to}
                to={to}
                className={({ isActive }) =>
                  `flex items-center space-x-2 px-4 py-2 rounded-full transition-all duration-200 ${
                    isActive
                      ? 'bg-gradient-to-r from-purple-500/20 to-indigo-500/20 text-purple-200 border border-purple-400/30'
                      : 'text-purple-300/80 hover:text-purple-200 hover:bg-white/10'
                  }`
                }
              >
                <Icon className="h-4 w-4" />
                <span className="font-medium">{label}</span>
              </NavLink>
            ))}
          </div>
          <div className="pl-4 border-l border-purple-400/20">
            <UserMenu />
          </div>
        </div>
      </nav>

      {/* Mobile User Menu - Top Right */}
      <div className="fixed top-4 right-4 z-50 md:hidden">
        <UserMenu />
      </div>

      {/* Mobile Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 z-50 md:hidden bottom-nav-glass safe-area-bottom">
        <div className="flex items-center justify-around px-2 py-3">
          {navItems.map(({ to, icon: Icon, label }) => (
            <NavLink
              key={to}
              to={to}
              className={({ isActive }) =>
                `mobile-nav-item flex flex-col items-center justify-center p-3 rounded-xl min-w-[60px] transition-all duration-300 ${
                  isActive
                    ? 'active nav-item-active text-purple-200'
                    : 'text-purple-400/70 hover:text-purple-300 hover:bg-white/5'
                }`
              }
            >
              <Icon className="h-5 w-5 mb-1.5" />
              <span className="text-xs font-medium leading-none">{label}</span>
            </NavLink>
          ))}
        </div>
        {/* Safe area padding for devices with home indicator */}
        <div className="h-safe-bottom bg-transparent"></div>
      </nav>

      {/* Mobile bottom padding to prevent content overlap */}
      <div className="h-20 md:hidden pointer-events-none" />
    </>
  );
};

export default Navigation;
