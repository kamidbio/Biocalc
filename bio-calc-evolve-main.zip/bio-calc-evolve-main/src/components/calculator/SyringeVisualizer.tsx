
import React from 'react';
import { Card } from '@/components/ui/card';

interface SyringeVisualizerProps {
  drawAmount: number;
  maxVolume: number;
  units: 'ml' | 'units';
  syringeSize: string;
  remainingDoses: number;
}

const SyringeVisualizer: React.FC<SyringeVisualizerProps> = ({
  drawAmount,
  maxVolume,
  units,
  syringeSize,
  remainingDoses
}) => {
  // Generate tick marks for the syringe
  const generateTickMarks = () => {
    const marks = [];
    const increment = maxVolume <= 1 ? 0.1 : maxVolume <= 3 ? 0.5 : 1;
    
    for (let i = 0; i <= maxVolume; i += increment) {
      const position = (i / maxVolume) * 100;
      marks.push({ value: i.toFixed(1), position });
    }
    return marks;
  };

  const tickMarks = generateTickMarks();
  const fillPercentage = Math.min((drawAmount / maxVolume) * 100, 100);

  return (
    <Card className="p-6 bg-gradient-to-br from-blue-500/10 via-purple-500/10 to-blue-600/10 border border-blue-500/20 rounded-xl">
      <div className="grid gap-4">
        <div className="text-center">
          <div className="text-lg font-bold text-white mb-2">
            Draw amount: {drawAmount.toFixed(2)} {units}
          </div>
          <div className="text-md text-purple-300">
            Vial contains {remainingDoses.toFixed(2)} uses
          </div>
        </div>

        {/* Visual Syringe */}
        <div className="relative bg-white/10 rounded-lg p-6 backdrop-blur-sm border border-blue-400/30">
          {/* Syringe barrel */}
          <div className="relative mx-auto" style={{ width: '280px', height: '60px' }}>
            {/* Syringe outline */}
            <div className="absolute inset-0 border-2 border-gray-300 rounded-lg bg-white/90">
              {/* Fill indicator */}
              <div 
                className="h-full bg-gradient-to-r from-blue-500 to-purple-600 rounded-lg transition-all duration-500 ease-in-out"
                style={{ width: `${fillPercentage}%` }}
              />
              
              {/* Draw line indicator */}
              <div 
                className="absolute top-0 bottom-0 w-0.5 bg-red-500 z-10 transition-all duration-500"
                style={{ left: `${fillPercentage}%` }}
              />
            </div>
            
            {/* Plunger */}
            <div 
              className="absolute top-1/2 transform -translate-y-1/2 w-3 h-8 bg-gray-600 rounded-r transition-all duration-500"
              style={{ left: `${fillPercentage}%` }}
            />
          </div>

          {/* Measurement scale */}
          <div className="flex justify-between items-center mt-4 px-2">
            {tickMarks.map((mark, index) => (
              <div key={index} className="flex flex-col items-center">
                <div className="w-px h-3 bg-gray-400 mb-1" />
                <span className="text-xs text-gray-300 font-mono">
                  {mark.value}
                </span>
              </div>
            ))}
          </div>
          
          <div className="text-center mt-2">
            <span className="text-xs text-purple-300">Scale: 0 - {maxVolume} {units}</span>
          </div>
        </div>

        {/* Usage Instructions */}
        <div className="text-center bg-green-500/20 rounded-lg p-3 border border-green-400/30">
          <div className="text-green-300 text-sm font-medium">
            ↑ Draw to the red line position
          </div>
          <div className="text-xs text-green-200 mt-1">
            Fill: {fillPercentage.toFixed(1)}% of {syringeSize} syringe
          </div>
        </div>
      </div>
    </Card>
  );
};

export default SyringeVisualizer;
