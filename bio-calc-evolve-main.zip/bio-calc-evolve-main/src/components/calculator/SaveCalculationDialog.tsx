import { useState } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { CalculationResult } from '@/hooks/useCalculator';

interface SaveCalculationDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSave: (data: {
    calculationName: string;
    syringeType: string;
    syringeUnits: string;
    syringeVolume: string;
    waterAmount: string;
    peptideAmount: string;
    desiredDose: string;
    notes: string;
  }, result: CalculationResult) => void;
  calculationData: {
    syringeType: string;
    units: string;
    volume: string;
    waterAmount: string;
    peptideAmount: string;
    desiredDose: string;
  };
  result: CalculationResult;
  loading: boolean;
}

const SaveCalculationDialog = ({
  open,
  onOpenChange,
  onSave,
  calculationData,
  result,
  loading
}: SaveCalculationDialogProps) => {
  const [calculationName, setCalculationName] = useState('');
  const [notes, setNotes] = useState('');

  const handleSave = () => {
    if (!calculationName.trim()) {
      return;
    }

    onSave(
      {
        calculationName,
        syringeType: calculationData.syringeType,
        syringeUnits: calculationData.units,
        syringeVolume: calculationData.volume,
        waterAmount: calculationData.waterAmount,
        peptideAmount: calculationData.peptideAmount,
        desiredDose: calculationData.desiredDose,
        notes
      },
      result
    );

    // Reset form
    setCalculationName('');
    setNotes('');
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="glass-card">
        <DialogHeader>
          <DialogTitle>Save Calculation</DialogTitle>
          <DialogDescription>
            Save this calculation for future reference
          </DialogDescription>
        </DialogHeader>
        
        <div className="grid gap-4">
          <div className="grid gap-2">
            <Label htmlFor="calculation-name">Calculation Name *</Label>
            <Input
              id="calculation-name"
              value={calculationName}
              onChange={(e) => setCalculationName(e.target.value)}
              placeholder="e.g., BPC-157 Daily Dose"
              className="premium-input"
            />
          </div>
          
          <div className="grid gap-2">
            <Label htmlFor="notes">Notes (Optional)</Label>
            <Textarea
              id="notes"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Add any notes about this calculation..."
              className="premium-input min-h-[80px]"
            />
          </div>
          
          {/* Calculation Summary */}
          <div className="glass-card p-4 rounded-lg border border-primary/20">
            <h4 className="font-semibold mb-2 text-sm">Calculation Summary</h4>
            <div className="grid grid-cols-2 gap-2 text-xs">
              <div>
                <span className="text-muted-foreground">Peptide:</span> {calculationData.peptideAmount}mg
              </div>
              <div>
                <span className="text-muted-foreground">Water:</span> {calculationData.waterAmount}ml
              </div>
              <div>
                <span className="text-muted-foreground">Dose:</span> {calculationData.desiredDose}mg
              </div>
              <div>
                <span className="text-muted-foreground">Draw:</span> {result.drawUnits} units
              </div>
            </div>
          </div>
        </div>
        
        <DialogFooter>
          <Button
            variant="outline"
            onClick={() => onOpenChange(false)}
            disabled={loading}
          >
            Cancel
          </Button>
          <Button
            onClick={handleSave}
            disabled={loading || !calculationName.trim()}
            className="premium-gradient text-white"
          >
            {loading ? 'Saving...' : 'Save Calculation'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default SaveCalculationDialog;
