import { useState } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { addDays, addWeeks, startOfDay } from 'date-fns';

interface ReminderDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onCreateReminder: (reminderData: {
    reminderName: string;
    frequencyType: string;
    frequencyValue?: string;
    nextReminder: Date;
    notes?: string;
  }, calculationId?: string) => void;
  loading: boolean;
}

const ReminderDialog = ({
  open,
  onOpenChange,
  onCreateReminder,
  loading
}: ReminderDialogProps) => {
  const [reminderName, setReminderName] = useState('');
  const [frequencyType, setFrequencyType] = useState('daily');
  const [notes, setNotes] = useState('');

  const handleSave = () => {
    if (!reminderName.trim()) {
      return;
    }

    let nextReminder = new Date();
    
    switch (frequencyType) {
      case 'daily':
        nextReminder = addDays(startOfDay(new Date()), 1);
        break;
      case 'weekly':
        nextReminder = addWeeks(startOfDay(new Date()), 1);
        break;
      default:
        nextReminder = addDays(startOfDay(new Date()), 1);
    }

    onCreateReminder({
      reminderName,
      frequencyType,
      nextReminder,
      notes
    });

    // Reset form
    setReminderName('');
    setFrequencyType('daily');
    setNotes('');
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="glass-card">
        <DialogHeader>
          <DialogTitle>Create Reminder</DialogTitle>
          <DialogDescription>
            Set up a dosing reminder for this calculation
          </DialogDescription>
        </DialogHeader>
        
        <div className="grid gap-4">
          <div className="grid gap-2">
            <Label htmlFor="reminder-name">Reminder Name *</Label>
            <Input
              id="reminder-name"
              value={reminderName}
              onChange={(e) => setReminderName(e.target.value)}
              placeholder="e.g., BPC-157 Morning Dose"
              className="premium-input"
            />
          </div>
          
          <div className="grid gap-2">
            <Label htmlFor="frequency">Frequency</Label>
            <Select value={frequencyType} onValueChange={setFrequencyType}>
              <SelectTrigger className="premium-input">
                <SelectValue placeholder="Select frequency" />
              </SelectTrigger>
              <SelectContent className="glass-card">
                <SelectItem value="daily">Daily</SelectItem>
                <SelectItem value="weekly">Weekly</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div className="grid gap-2">
            <Label htmlFor="reminder-notes">Notes (Optional)</Label>
            <Textarea
              id="reminder-notes"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Add any notes for this reminder..."
              className="premium-input min-h-[80px]"
            />
          </div>
        </div>
        
        <DialogFooter>
          <Button
            variant="outline"
            onClick={() => onOpenChange(false)}
            disabled={loading}
          >
            Cancel
          </Button>
          <Button
            onClick={handleSave}
            disabled={loading || !reminderName.trim()}
            className="premium-gradient text-white"
          >
            {loading ? 'Creating...' : 'Create Reminder'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default ReminderDialog;