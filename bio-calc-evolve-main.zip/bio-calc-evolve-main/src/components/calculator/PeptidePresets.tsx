import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Sparkles, ChevronDown, ChevronUp } from 'lucide-react';
import { PeptidePreset } from '@/hooks/useCalculator';

interface PeptidePresetsProps {
  presets: PeptidePreset[];
  onPresetSelect: (preset: PeptidePreset, dosage: string) => void;
}

const PeptidePresets = ({ presets, onPresetSelect }: PeptidePresetsProps) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [isExpanded, setIsExpanded] = useState(false);

  const categories = [...new Set(presets.map(p => p.category))];
  const filteredPresets = selectedCategory === 'all' 
    ? presets 
    : presets.filter(p => p.category === selectedCategory);

  const categoryColors = {
    healing: 'bg-green-500/20 text-green-400',
    enhancement: 'bg-purple-500/20 text-purple-400',
    growth: 'bg-blue-500/20 text-blue-400',
    cosmetic: 'bg-pink-500/20 text-pink-400',
    weight: 'bg-orange-500/20 text-orange-400',
    nootropic: 'bg-cyan-500/20 text-cyan-400',
    general: 'bg-gray-500/20 text-gray-400'
  };

  return (
    <Card className="glass-card card-hover slide-up">
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-primary/20 flex items-center justify-center">
              <Sparkles className="h-4 w-4 text-primary" />
            </div>
            <div>
              <CardTitle className="text-xl">Peptide Presets</CardTitle>
              <CardDescription className="text-sm">
                Quick setup with common peptides
              </CardDescription>
            </div>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setIsExpanded(!isExpanded)}
            className="p-2"
          >
            {isExpanded ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
          </Button>
        </div>
      </CardHeader>
      
      {isExpanded && (
        <CardContent className="grid gap-4">
          {/* Category Filter */}
          <div className="grid gap-2">
            <label className="text-sm font-medium">Category</label>
            <Select value={selectedCategory} onValueChange={setSelectedCategory}>
              <SelectTrigger className="premium-input h-10">
                <SelectValue placeholder="Select category" />
              </SelectTrigger>
              <SelectContent className="glass-card">
                <SelectItem value="all">All Categories</SelectItem>
                {categories.map(category => (
                  <SelectItem key={category} value={category}>
                    {category.charAt(0).toUpperCase() + category.slice(1)}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Preset Cards */}
          <div className="grid gap-3 max-h-64 overflow-y-auto">
            {filteredPresets.map((preset) => (
              <div key={preset.id} className="glass-card p-4 rounded-lg border border-primary/20">
                <div className="grid grid-cols-[1fr_auto] gap-2 mb-2">
                  <div className="grid gap-1">
                    <h4 className="font-semibold text-sm">{preset.peptide_name}</h4>
                    <p className="text-xs text-muted-foreground">{preset.description}</p>
                  </div>
                  <Badge 
                    variant="secondary" 
                    className={`text-xs ${categoryColors[preset.category as keyof typeof categoryColors] || categoryColors.general}`}
                  >
                    {preset.category}
                  </Badge>
                </div>
                
                <div className="grid gap-2">
                  <div className="text-xs text-muted-foreground">
                    Typical: {preset.typical_concentration}mg/ml • {preset.recommended_syringe_type}
                  </div>
                  
                  <div className="grid grid-cols-3 gap-2">
                    {preset.common_dosages.map((dosage, index) => (
                      <Button
                        key={index}
                        variant="outline"
                        size="sm"
                        className="h-7 px-2 text-xs glass-card border-primary/30 hover:bg-primary/20"
                        onClick={() => onPresetSelect(preset, dosage)}
                      >
                        {dosage}mg
                      </Button>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>

          {filteredPresets.length === 0 && (
            <div className="text-center py-8 text-muted-foreground">
              <Sparkles className="h-8 w-8 mx-auto mb-2 opacity-50" />
              <p className="text-sm">No presets found for this category</p>
            </div>
          )}
        </CardContent>
      )}
    </Card>
  );
};

export default PeptidePresets;