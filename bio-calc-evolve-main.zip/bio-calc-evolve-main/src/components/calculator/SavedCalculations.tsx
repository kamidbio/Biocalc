import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { History, Heart, Trash2, Calendar, ChevronDown, ChevronUp } from 'lucide-react';
import { SavedCalculation } from '@/hooks/useCalculator';
import { formatDistanceToNow } from 'date-fns';

interface SavedCalculationsProps {
  calculations: SavedCalculation[];
  onLoad: (calculation: SavedCalculation) => void;
  onDelete: (calculationId: string) => void;
  onToggleFavorite: (calculationId: string, isFavorite: boolean) => void;
  onCreateReminder: (calculationId: string) => void;
  loading: boolean;
}

const SavedCalculations = ({ 
  calculations, 
  onLoad, 
  onDelete, 
  onToggleFavorite, 
  onCreateReminder, 
  loading 
}: SavedCalculationsProps) => {
  const [isExpanded, setIsExpanded] = useState(false);

  const favoriteCalculations = calculations.filter(calc => calc.is_favorite);
  const recentCalculations = calculations.slice(0, 5);

  return (
    <Card className="glass-card card-hover slide-up">
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-primary/20 flex items-center justify-center">
              <History className="h-4 w-4 text-primary" />
            </div>
            <div>
              <CardTitle className="text-xl">Saved Calculations</CardTitle>
              <CardDescription className="text-sm">
                Your calculation history
              </CardDescription>
            </div>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setIsExpanded(!isExpanded)}
            className="p-2"
          >
            {isExpanded ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
          </Button>
        </div>
      </CardHeader>
      
      {isExpanded && (
        <CardContent className="grid gap-4">
          {/* Favorites Section */}
          {favoriteCalculations.length > 0 && (
            <div className="grid gap-2">
              <h4 className="text-sm font-semibold flex items-center gap-2">
                <Heart className="h-4 w-4 text-red-400" />
                Favorites
              </h4>
              <div className="grid gap-2 max-h-32 overflow-y-auto">
                {favoriteCalculations.map((calc) => (
                  <CalculationCard
                    key={calc.id}
                    calculation={calc}
                    onLoad={onLoad}
                    onDelete={onDelete}
                    onToggleFavorite={onToggleFavorite}
                    onCreateReminder={onCreateReminder}
                    loading={loading}
                  />
                ))}
              </div>
            </div>
          )}

          {/* Recent Calculations */}
          <div className="grid gap-2">
            <h4 className="text-sm font-semibold">Recent Calculations</h4>
            <div className="grid gap-2 max-h-64 overflow-y-auto">
              {recentCalculations.length > 0 ? (
                recentCalculations.map((calc) => (
                  <CalculationCard
                    key={calc.id}
                    calculation={calc}
                    onLoad={onLoad}
                    onDelete={onDelete}
                    onToggleFavorite={onToggleFavorite}
                    onCreateReminder={onCreateReminder}
                    loading={loading}
                  />
                ))
              ) : (
                <div className="text-center py-8 text-muted-foreground">
                  <History className="h-8 w-8 mx-auto mb-2 opacity-50" />
                  <p className="text-sm">No saved calculations yet</p>
                  <p className="text-xs">Save your first calculation to see it here</p>
                </div>
              )}
            </div>
          </div>
        </CardContent>
      )}
    </Card>
  );
};

interface CalculationCardProps {
  calculation: SavedCalculation;
  onLoad: (calculation: SavedCalculation) => void;
  onDelete: (calculationId: string) => void;
  onToggleFavorite: (calculationId: string, isFavorite: boolean) => void;
  onCreateReminder: (calculationId: string) => void;
  loading: boolean;
}

const CalculationCard = ({ 
  calculation, 
  onLoad, 
  onDelete, 
  onToggleFavorite, 
  onCreateReminder,
  loading 
}: CalculationCardProps) => {
  return (
    <div className="glass-card p-3 rounded-lg border border-primary/20 grid gap-2">
      <div className="grid grid-cols-[1fr_auto] gap-2">
        <div className="grid gap-1">
          <h5 className="font-semibold text-sm">{calculation.calculation_name}</h5>
          <p className="text-xs text-muted-foreground">
            {formatDistanceToNow(new Date(calculation.created_at), { addSuffix: true })}
          </p>
        </div>
        <div className="grid grid-cols-2 gap-1">
          <Button
            variant="ghost"
            size="sm"
            className="h-7 w-7 p-0"
            onClick={() => onToggleFavorite(calculation.id, calculation.is_favorite)}
            disabled={loading}
          >
            <Heart 
              className={`h-3 w-3 ${calculation.is_favorite ? 'fill-red-400 text-red-400' : 'text-muted-foreground'}`} 
            />
          </Button>
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button
                variant="ghost"
                size="sm"
                className="h-7 w-7 p-0 hover:text-red-400"
                disabled={loading}
              >
                <Trash2 className="h-3 w-3" />
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent className="glass-card">
              <AlertDialogHeader>
                <AlertDialogTitle>Delete Calculation</AlertDialogTitle>
                <AlertDialogDescription>
                  Are you sure you want to delete "{calculation.calculation_name}"? This action cannot be undone.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Cancel</AlertDialogCancel>
                <AlertDialogAction onClick={() => onDelete(calculation.id)}>
                  Delete
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </div>
      </div>
      
      <div className="grid grid-cols-[1fr_auto] gap-2 text-xs">
        <div className="grid grid-cols-2 gap-2">
          <Badge variant="secondary" className="text-xs">
            {calculation.desired_dose}mg
          </Badge>
          <Badge variant="outline" className="text-xs">
            {calculation.syringe_type}
          </Badge>
        </div>
        <div className="text-muted-foreground">
          {calculation.calculated_draw_units} units
        </div>
      </div>
      
      <div className="grid grid-cols-[1fr_auto] gap-2">
        <Button
          variant="outline"
          size="sm"
          className="h-7 text-xs glass-card border-primary/30"
          onClick={() => onLoad(calculation)}
          disabled={loading}
        >
          Load
        </Button>
        <Button
          variant="outline"
          size="sm"
          className="h-7 px-2 text-xs glass-card border-primary/30"
          onClick={() => onCreateReminder(calculation.id)}
          disabled={loading}
        >
          <Calendar className="h-3 w-3" />
        </Button>
      </div>
    </div>
  );
};

export default SavedCalculations;