import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { ToggleGroup, ToggleGroupItem } from '@/components/ui/toggle-group';
import { Slider } from '@/components/ui/slider';
import { Calculator, Save, RotateCcw, Target, Info, Calendar, Clock } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Calendar as CalendarComponent } from '@/components/ui/calendar';
import { Checkbox } from '@/components/ui/checkbox';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';
import SyringeVisualizer from './SyringeVisualizer';

interface CalculationResult {
  drawAmount: string;
  drawUnits: string;
  concentration: string;
  remainingDoses: number;
  duration: string;
  dailyDose: number;
  explanation: string;
}

interface SolvedResult {
  solvedValue: string;
  solvedField: string;
  explanation: string;
  math: string;
}

interface CalculatorFormProps {
  onSave?: (calculation: any, result: CalculationResult) => void;
}

const CalculatorForm: React.FC<CalculatorFormProps> = ({ onSave }) => {
  const [peptideName, setPeptideName] = useState('');
  const [units, setUnits] = useState<'ml' | 'units'>('units');
  const [syringeSize, setSyringeSize] = useState('1ml');
  const [peptideAmount, setPeptideAmount] = useState('');
  const [peptideUnit, setPeptideUnit] = useState<'mg' | 'mcg'>('mg');
  const [liquidAmount, setLiquidAmount] = useState('');
  const [desiredDose, setDesiredDose] = useState('');
  const [doseUnit, setDoseUnit] = useState<'mcg' | 'mg'>('mg');
  const [desiredUnits, setDesiredUnits] = useState('');
  const [dosingSchedule, setDosingSchedule] = useState('daily');
  const [splitDays, setSplitDays] = useState('5');
  
  // New fields
  const [vialCount, setVialCount] = useState('1');
  const [usageDuration, setUsageDuration] = useState('');
  const [usagePeriod, setUsagePeriod] = useState<'days' | 'weeks' | 'months'>('weeks');
  const [dosesPerWeek, setDosesPerWeek] = useState<string[]>(['Monday']);
  const [shotTimes, setShotTimes] = useState<string[]>(['morning']);
  const [startDate, setStartDate] = useState<Date>();
  const [endDate, setEndDate] = useState<Date>();
  
  const [result, setResult] = useState<CalculationResult | null>(null);
  const [solvedResult, setSolvedResult] = useState<SolvedResult | null>(null);
  const [sliderValue, setSliderValue] = useState<number[]>([0]);
  const [concentration, setConcentration] = useState(0);

  const syringeSizes = [
    { ml: '0.3ml', units: '30 units', value: '0.3ml', maxVolume: 0.3 },
    { ml: '0.5ml', units: '50 units', value: '0.5ml', maxVolume: 0.5 },
    { ml: '1ml', units: '100 units', value: '1ml', maxVolume: 1.0 },
    { ml: '3ml', units: '300 units', value: '3ml', maxVolume: 3.0 }
  ];

  const daysOfWeek = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
  const timeOptions = ['morning', 'afternoon', 'evening', 'night'];

  // Helper functions

  // Check how many fields are blank
  const getBlankFields = () => {
    const fields = [];
    if (!peptideAmount) fields.push('peptideAmount');
    if (!liquidAmount) fields.push('liquidAmount');
    if (!desiredDose) fields.push('desiredDose');
    if (!desiredUnits) fields.push('desiredUnits');
    return fields;
  };

  const blankFields = getBlankFields();
  const canCalculate = blankFields.length <= 1;
  const isSolveMode = blankFields.length === 1;

  const getSyringeMaxUnits = () => {
    return syringeSize === '0.3ml' ? 30 : 
           syringeSize === '0.5ml' ? 50 : 
           syringeSize === '1ml' ? 100 : 300;
  };

  const getSyringeMax = () => {
    const selectedSyringe = syringeSizes.find(s => s.value === syringeSize);
    return selectedSyringe?.maxVolume || 1;
  };

  const handleDosesPerWeekChange = (day: string, checked: boolean) => {
    if (checked) {
      setDosesPerWeek([...dosesPerWeek, day]);
    } else {
      setDosesPerWeek(dosesPerWeek.filter(d => d !== day));
    }
  };

  const handleShotTimesChange = (time: string, checked: boolean) => {
    if (checked) {
      setShotTimes([...shotTimes, time]);
    } else {
      setShotTimes(shotTimes.filter(t => t !== time));
    }
  };

  const selectAllDays = () => {
    setDosesPerWeek(daysOfWeek);
  };

  const clearAllDays = () => {
    setDosesPerWeek([]);
  };

  // Calculation functions

  const calculateEstimatedDraws = () => {
    if (!result || !vialCount || !usageDuration) return null;
    
    const totalVials = parseInt(vialCount);
    const duration = parseInt(usageDuration);
    const dosesPerVial = result.remainingDoses;
    const totalDoses = totalVials * dosesPerVial;
    
    let daysOfUse = 0;
    if (usagePeriod === 'days') {
      daysOfUse = duration;
    } else if (usagePeriod === 'weeks') {
      daysOfUse = duration * 7;
    } else if (usagePeriod === 'months') {
      daysOfUse = duration * 30;
    }
    
    const dosesPerDay = dosesPerWeek.length * shotTimes.length;
    const totalNeededDoses = daysOfUse * dosesPerDay;
    
    return {
      totalDoses,
      totalNeededDoses,
      willLastDays: Math.floor(totalDoses / dosesPerDay),
      reorderDate: startDate ? new Date(startDate.getTime() + (totalDoses / dosesPerDay - 7) * 24 * 60 * 60 * 1000) : null
    };
  };

  const solveForMissingValue = () => {
    if (blankFields.length !== 1) return null;

    const A = parseFloat(peptideAmount) || 0;
    const V = parseFloat(liquidAmount) || 0;
    const D = parseFloat(desiredDose) || 0;
    const U = parseFloat(desiredUnits) || 0;
    const maxUnits = getSyringeMaxUnits();

    const blankField = blankFields[0];
    let solvedValue = '';
    let explanation = '';
    let math = '';

    switch (blankField) {
      case 'liquidAmount':
        if (A && D && U) {
          const calculatedV = (A * U * 0.01) / D;
          solvedValue = calculatedV.toFixed(2);
          explanation = `You should add ${solvedValue}mL of water to your ${A}mg vial so that each ${D}mg dose requires ${U} units on your syringe.`;
          math = `Formula: V = (A × U × 0.01) / D\nV = (${A} × ${U} × 0.01) / ${D}\nV = ${solvedValue}mL`;
        }
        break;

      case 'desiredDose':
        if (A && V && U) {
          const calculatedD = (A / V) * U * 0.01;
          solvedValue = calculatedD.toFixed(2);
          explanation = `With ${A}mg in ${V}mL of water, drawing ${U} units will give you ${solvedValue}mg per dose.`;
          math = `Formula: D = (A / V) × U × 0.01\nD = (${A} / ${V}) × ${U} × 0.01\nD = ${solvedValue}mg`;
        }
        break;

      case 'desiredUnits':
        if (A && V && D) {
          const calculatedU = (D * V * 100) / A;
          solvedValue = calculatedU.toFixed(1);
          explanation = `To get ${D}mg per dose from your ${A}mg in ${V}mL solution, you need to draw ${solvedValue} units on your syringe.`;
          math = `Formula: U = (D × V × 100) / A\nU = (${D} × ${V} × 100) / ${A}\nU = ${solvedValue} units`;
          
          if (calculatedU > maxUnits) {
            explanation += ` ⚠️ Warning: This exceeds your ${syringeSize} syringe capacity of ${maxUnits} units.`;
          }
        }
        break;

      case 'peptideAmount':
        if (V && D && U) {
          const calculatedA = (D * V) / (U * 0.01);
          solvedValue = calculatedA.toFixed(0);
          explanation = `You need a ${solvedValue}mg vial to achieve ${D}mg doses using ${U} units with ${V}mL of water.`;
          math = `Formula: A = (D × V) / (U × 0.01)\nA = (${D} × ${V}) / (${U} × 0.01)\nA = ${solvedValue}mg`;
        }
        break;
    }

    return {
      solvedValue,
      solvedField: blankField,
      explanation,
      math
    };
  };

  const calculateDosage = () => {
    if (isSolveMode) {
      const solved = solveForMissingValue();
      if (solved) {
        setSolvedResult(solved);
        
        switch (solved.solvedField) {
          case 'liquidAmount':
            setLiquidAmount(solved.solvedValue);
            break;
          case 'desiredDose':
            setDesiredDose(solved.solvedValue);
            break;
          case 'desiredUnits':
            setDesiredUnits(solved.solvedValue);
            break;
          case 'peptideAmount':
            setPeptideAmount(solved.solvedValue);
            break;
        }
        
        setTimeout(() => {
          performNormalCalculation(solved);
        }, 100);
      }
      return;
    }

    performNormalCalculation();
  };

  const performNormalCalculation = (solvedData?: SolvedResult) => {
    const currentPeptideAmount = solvedData?.solvedField === 'peptideAmount' ? solvedData.solvedValue : peptideAmount;
    const currentLiquidAmount = solvedData?.solvedField === 'liquidAmount' ? solvedData.solvedValue : liquidAmount;
    const currentDesiredDose = solvedData?.solvedField === 'desiredDose' ? solvedData.solvedValue : desiredDose;
    
    if (!currentPeptideAmount || !currentDesiredDose || !currentLiquidAmount) {
      return;
    }

    const peptideAmountNum = parseFloat(currentPeptideAmount);
    const desiredDoseNum = parseFloat(currentDesiredDose);
    const liquidAmountNum = parseFloat(currentLiquidAmount);

    let peptideMcg = peptideAmountNum;
    if (peptideUnit === 'mg') {
      peptideMcg = peptideAmountNum * 1000;
    }

    let desiredMcg = desiredDoseNum;
    if (doseUnit === 'mg') {
      desiredMcg = desiredDoseNum * 1000;
    }

    let dailyDoseMcg = desiredMcg;
    let dosesPerWeekNum = 7;
    
    if (dosingSchedule === 'weekly') {
      dailyDoseMcg = desiredMcg / 7;
      dosesPerWeekNum = 1;
    } else if (dosingSchedule === 'split') {
      const splitDaysNum = parseInt(splitDays);
      dailyDoseMcg = desiredMcg / splitDaysNum;
      dosesPerWeekNum = splitDaysNum;
    }

    const concentrationMcgPerMl = peptideMcg / liquidAmountNum;
    setConcentration(concentrationMcgPerMl);
    
    const drawVolumeML = dailyDoseMcg / concentrationMcgPerMl;
    
    let drawAmount: string;
    let drawUnits: string;
    
    if (units === 'ml') {
      drawAmount = drawVolumeML.toFixed(3);
      drawUnits = 'ml';
    } else {
      const selectedSyringe = syringeSizes.find(s => s.value === syringeSize);
      const maxVolume = selectedSyringe?.maxVolume || 1;
      const maxUnits = syringeSize === '0.3ml' ? 30 : 
                      syringeSize === '0.5ml' ? 50 : 
                      syringeSize === '1ml' ? 100 : 300;
      
      const unitsPerML = maxUnits / maxVolume;
      const drawUnitsCalc = drawVolumeML * unitsPerML;
      
      drawAmount = drawUnitsCalc.toFixed(1);
      drawUnits = 'units';
    }

    const maxUnits = syringeSize === '0.3ml' ? 30 : 
                     syringeSize === '0.5ml' ? 50 : 
                     syringeSize === '1ml' ? 100 : 300;
    
    if (units === 'units') {
      setSliderValue([parseFloat(drawAmount)]);
    } else {
      const selectedSyringe = syringeSizes.find(s => s.value === syringeSize);
      const maxVolume = selectedSyringe?.maxVolume || 1;
      const unitsPerML = maxUnits / maxVolume;
      setSliderValue([parseFloat(drawAmount) * unitsPerML]);
    }

    const totalDoses = Math.floor(liquidAmountNum / drawVolumeML);
    
    let duration: string;
    if (dosingSchedule === 'daily') {
      duration = `${totalDoses} days`;
    } else if (dosingSchedule === 'weekly') {
      const weeks = Math.floor(totalDoses);
      duration = `${weeks} weeks`;
    } else {
      const splitDaysNum = parseInt(splitDays);
      const totalWeeks = Math.floor(totalDoses / splitDaysNum);
      duration = `${totalWeeks} weeks (${splitDaysNum} doses per week)`;
    }

    const concentrationDisplay = (concentrationMcgPerMl / 1000).toFixed(2);
    const scheduleText = dosingSchedule === 'daily' ? 'daily dose' : 
                        dosingSchedule === 'weekly' ? 'weekly dose' : 
                        `dose ${splitDays} times per week`;

    const explanation = `You need to pull ${drawAmount} ${drawUnits} on your syringe for each ${scheduleText}. This vial will last you about ${duration}.`;

    const calculationResult: CalculationResult = {
      drawAmount,
      drawUnits,
      concentration: concentrationDisplay,
      remainingDoses: totalDoses,
      duration,
      dailyDose: dailyDoseMcg / 1000,
      explanation
    };

    setResult(calculationResult);
  };

  const handleReset = () => {
    setPeptideName('');
    setPeptideAmount('');
    setLiquidAmount('');
    setDesiredDose('');
    setDesiredUnits('');
    setVialCount('1');
    setUsageDuration('');
    setUsagePeriod('weeks');
    setDosesPerWeek(['Monday']);
    setShotTimes(['morning']);
    setStartDate(undefined);
    setEndDate(undefined);
    setResult(null);
    setSolvedResult(null);
    setSliderValue([0]);
  };

  const handleSave = () => {
    if (!result) return;
    
    const calculationData = {
      peptideName,
      syringeType: syringeSize,
      syringeUnits: units === 'units' ? result.drawAmount : (parseFloat(result.drawAmount) * (syringeSize === '0.3ml' ? 30 : syringeSize === '0.5ml' ? 50 : syringeSize === '1ml' ? 100 : 300) / getSyringeMax()).toString(),
      syringeVolume: getSyringeMax().toString(),
      waterAmount: liquidAmount,
      peptideAmount: peptideAmount,
      desiredDose: desiredDose,
      vialCount,
      usageDuration,
      usagePeriod,
      dosesPerWeek,
      shotTimes,
      startDate: startDate?.toISOString(),
      endDate: endDate?.toISOString(),
      calculationName: `${peptideName || 'Peptide'} calculation - ${new Date().toLocaleDateString()}`,
      notes: ''
    };
    
    onSave?.(calculationData, result);
  };

  const estimatedDraws = calculateEstimatedDraws();

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      {/* Header */}
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold text-primary mb-2">B.I.O | CALC</h1>
        <p className="text-muted-foreground">Calculate your dosing, track your protocols, and manage your peptide schedule</p>
      </div>

      {/* Main Calculator Card */}
      <Card className="glass-card border-primary/20">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-primary">
            <Calculator className="h-5 w-5" />
            Peptide Calculator
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Product Information */}
          <div className="space-y-4">
            <div>
              <Label htmlFor="peptideName">Product Name</Label>
              <Input
                id="peptideName"
                placeholder="e.g., NAD+"
                value={peptideName}
                onChange={(e) => setPeptideName(e.target.value)}
                className="glass-input mt-2"
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="peptideAmount">Vial Amount</Label>
                <div className="flex gap-2 mt-2">
                  <Input
                    id="peptideAmount"
                    type="number"
                    placeholder="500"
                    value={peptideAmount}
                    onChange={(e) => setPeptideAmount(e.target.value)}
                    className={blankFields.includes('peptideAmount') ? 'glass-input border-yellow-500 flex-1' : 'glass-input flex-1'}
                  />
                  <ToggleGroup
                    type="single"
                    value={peptideUnit}
                    onValueChange={(value) => setPeptideUnit(value as 'mg' | 'mcg')}
                    className="h-10"
                  >
                    <ToggleGroupItem value="mg" className="px-3">mg</ToggleGroupItem>
                    <ToggleGroupItem value="mcg" className="px-3">mcg</ToggleGroupItem>
                  </ToggleGroup>
                </div>
              </div>

              <div>
                <Label htmlFor="desiredDose">Desired Dose</Label>
                <div className="flex gap-2 mt-2">
                  <Input
                    id="desiredDose"
                    type="number"
                    placeholder="50"
                    value={desiredDose}
                    onChange={(e) => setDesiredDose(e.target.value)}
                    className={blankFields.includes('desiredDose') ? 'glass-input border-yellow-500 flex-1' : 'glass-input flex-1'}
                  />
                  <ToggleGroup
                    type="single"
                    value={doseUnit}
                    onValueChange={(value) => setDoseUnit(value as 'mg' | 'mcg')}
                    className="h-10"
                  >
                    <ToggleGroupItem value="mg" className="px-3">mg</ToggleGroupItem>
                    <ToggleGroupItem value="mcg" className="px-3">mcg</ToggleGroupItem>
                  </ToggleGroup>
                </div>
              </div>
            </div>

            <div>
              <Label htmlFor="vialCount">How many vials do you have of this peptide?</Label>
              <Input
                id="vialCount"
                type="number"
                placeholder="1"
                value={vialCount}
                onChange={(e) => setVialCount(e.target.value)}
                className="glass-input w-24 mt-2"
              />
            </div>
          </div>

          {/* Usage Planning */}
          <div className="space-y-4">
            <div>
              <Label>How long do you plan to use it:</Label>
              <div className="flex flex-col gap-2 mt-2">
                <ToggleGroup
                  type="single"
                  value={usagePeriod}
                  onValueChange={(value) => setUsagePeriod(value as 'days' | 'weeks' | 'months')}
                  className="justify-start"
                >
                  <ToggleGroupItem value="days" className="px-4">Days</ToggleGroupItem>
                  <ToggleGroupItem value="weeks" className="px-4">Weeks</ToggleGroupItem>
                  <ToggleGroupItem value="months" className="px-4">Months</ToggleGroupItem>
                </ToggleGroup>
                <Input
                  type="number"
                  placeholder="1"
                  value={usageDuration}
                  onChange={(e) => setUsageDuration(e.target.value)}
                  className="glass-input w-24"
                />
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-3">
                <Label>How often per week:</Label>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  onClick={dosesPerWeek.length === daysOfWeek.length ? clearAllDays : selectAllDays}
                  className="text-xs h-6 px-2"
                >
                  Choose All
                </Button>
              </div>
              <div className="grid grid-cols-7 gap-2">
                {daysOfWeek.map((day) => (
                  <div key={day} className="flex flex-col items-center space-y-2">
                    <Checkbox
                      id={day}
                      checked={dosesPerWeek.includes(day)}
                      onCheckedChange={(checked) => handleDosesPerWeekChange(day, checked as boolean)}
                    />
                    <Label htmlFor={day} className="text-xs cursor-pointer">
                      {day.slice(0, 3)}
                    </Label>
                  </div>
                ))}
              </div>
            </div>

            <div>
              <Label>Shot time:</Label>
              <div className="grid grid-cols-2 gap-4 mt-2">
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="morning"
                      checked={shotTimes.includes('morning')}
                      onCheckedChange={(checked) => handleShotTimesChange('morning', checked as boolean)}
                    />
                    <Label htmlFor="morning" className="text-sm cursor-pointer">Morning</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="evening"
                      checked={shotTimes.includes('evening')}
                      onCheckedChange={(checked) => handleShotTimesChange('evening', checked as boolean)}
                    />
                    <Label htmlFor="evening" className="text-sm cursor-pointer">Evening</Label>
                  </div>
                </div>
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="afternoon"
                      checked={shotTimes.includes('afternoon')}
                      onCheckedChange={(checked) => handleShotTimesChange('afternoon', checked as boolean)}
                    />
                    <Label htmlFor="afternoon" className="text-sm cursor-pointer">Afternoon</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="night"
                      checked={shotTimes.includes('night')}
                      onCheckedChange={(checked) => handleShotTimesChange('night', checked as boolean)}
                    />
                    <Label htmlFor="night" className="text-sm cursor-pointer">Night</Label>
                  </div>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label>Start Date</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className={cn(
                        "w-full justify-start text-left font-normal glass-card mt-2",
                        !startDate && "text-muted-foreground"
                      )}
                    >
                      <Calendar className="mr-2 h-4 w-4" />
                      {startDate ? format(startDate, "PPP") : "Pick a date"}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <CalendarComponent
                      mode="single"
                      selected={startDate}
                      onSelect={setStartDate}
                      initialFocus
                    />
                  </PopoverContent>
                </Popover>
              </div>

              <div>
                <Label>End Date</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className={cn(
                        "w-full justify-start text-left font-normal glass-card mt-2",
                        !endDate && "text-muted-foreground"
                      )}
                    >
                      <Calendar className="mr-2 h-4 w-4" />
                      {endDate ? format(endDate, "PPP") : "Select start date"}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <CalendarComponent
                      mode="single"
                      selected={endDate}
                      onSelect={setEndDate}
                      initialFocus
                      disabled={(date) => startDate ? date < startDate : false}
                    />
                  </PopoverContent>
                </Popover>
              </div>
            </div>
          </div>

          {/* Configuration Section - Side by Side */}
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="liquidAmount">BAC Water Needed</Label>
                <div className="flex gap-2 mt-2">
                  <Input
                    id="liquidAmount"
                    type="number"
                    step="0.1"
                    placeholder="2"
                    value={liquidAmount}
                    onChange={(e) => setLiquidAmount(e.target.value)}
                    className={blankFields.includes('liquidAmount') ? 'glass-input border-yellow-500 flex-1' : 'glass-input flex-1'}
                  />
                  <div className="flex items-center px-3 bg-muted rounded-md text-sm">ml</div>
                </div>
              </div>

              <div>
                <Label htmlFor="syringeSize">Syringe Size</Label>
                <div className="flex gap-2 mt-2">
                  <Input
                    id="desiredUnits"
                    type="number"
                    step="0.1"
                    placeholder="10"
                    value={desiredUnits}
                    onChange={(e) => setDesiredUnits(e.target.value)}
                    className={blankFields.includes('desiredUnits') ? 'glass-input border-yellow-500 flex-1' : 'glass-input flex-1'}
                  />
                  <ToggleGroup
                    type="single"
                    value={units}
                    onValueChange={(value) => setUnits(value as 'ml' | 'units')}
                    className="h-10"
                  >
                    <ToggleGroupItem value="ml" className="px-3">ml</ToggleGroupItem>
                    <ToggleGroupItem value="units" className="px-3">units</ToggleGroupItem>
                  </ToggleGroup>
                </div>
                <ToggleGroup
                  type="single"
                  value={syringeSize}
                  onValueChange={(value) => setSyringeSize(value || '1ml')}
                  className="grid grid-cols-4 gap-1 mt-2"
                >
                  {syringeSizes.map((size) => (
                    <ToggleGroupItem
                      key={size.value}
                      value={size.value}
                      className="text-xs px-2 py-1 glass-card"
                    >
                      {units === 'ml' ? size.ml : `${size.units.split(' ')[0]}U`}
                    </ToggleGroupItem>
                  ))}
                </ToggleGroup>
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex gap-4 pt-4">
            <Button
              onClick={calculateDosage}
              disabled={!canCalculate}
              className="flex-1 glass-button-primary"
            >
              <Calculator className="h-4 w-4 mr-2" />
              {isSolveMode ? 'Solve' : 'Calculate'}
            </Button>
            
            <Button
              onClick={handleReset}
              variant="outline"
              className="glass-card border-primary/30"
            >
              <RotateCcw className="h-4 w-4 mr-2" />
              Reset
            </Button>
          </div>
          
          {/* Helper Text */}
          {blankFields.length > 1 && (
            <div className="bg-blue-50 dark:bg-blue-950 border border-blue-200 dark:border-blue-800 rounded-lg p-3">
              <p className="text-sm text-blue-700 dark:text-blue-300">
                <Info className="h-4 w-4 inline mr-1" />
                Fill in at least 3 fields to calculate the 4th automatically.
              </p>
            </div>
          )}
          
          {isSolveMode && (
            <div className="bg-yellow-50 dark:bg-yellow-950 border border-yellow-200 dark:border-yellow-800 rounded-lg p-3">
              <p className="text-sm text-yellow-700 dark:text-yellow-300">
                <Target className="h-4 w-4 inline mr-1" />
                I'll solve for the missing value automatically!
              </p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Syringe Visualizer */}
      {result && (
        <Card className="glass-card border-primary/20">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-primary">
              <Target className="h-5 w-5" />
              Syringe Visualizer
            </CardTitle>
          </CardHeader>
          <CardContent>
            <SyringeVisualizer
              drawAmount={parseFloat(result.drawAmount)}
              maxVolume={getSyringeMax()}
              units={units}
              syringeSize={syringeSize}
              remainingDoses={result.remainingDoses}
            />
            
            {/* Interactive Slider */}
            <div className="mt-6 space-y-4">
              <Label className="text-sm font-medium">Precise Draw Amount</Label>
              <div className="px-4">
                <Slider
                  value={sliderValue}
                  onValueChange={setSliderValue}
                  max={units === 'units' ? getSyringeMaxUnits() : getSyringeMax()}
                  min={0}
                  step={units === 'units' ? 0.5 : 0.01}
                  className="w-full"
                />
              </div>
              <div className="flex justify-between text-sm text-muted-foreground">
                <span>0 {units}</span>
                <span className="font-medium text-primary">
                  {sliderValue[0]?.toFixed(units === 'units' ? 1 : 2)} {units}
                </span>
                <span>{units === 'units' ? getSyringeMaxUnits() : getSyringeMax()} {units}</span>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Protocol Summary Card */}
      {result && (
        <Card className="glass-card border-primary/20">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-primary">
              <Target className="h-5 w-5" />
              Protocol Summary
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label className="text-sm font-medium text-muted-foreground">Vials Available</Label>
                <div className="text-2xl font-bold text-primary">{vialCount || 1}</div>
              </div>
              <div>
                <Label className="text-sm font-medium text-muted-foreground">Duration</Label>
                <div className="text-2xl font-bold text-primary">
                  {usageDuration} {usagePeriod?.slice(0, -1)}{usageDuration !== '1' ? usagePeriod?.slice(-1) : ''}
                </div>
              </div>
              <div>
                <Label className="text-sm font-medium text-muted-foreground">Estimated vials needed</Label>
                <div className="text-2xl font-bold text-primary">{estimatedDraws?.totalNeededDoses ? Math.ceil(estimatedDraws.totalNeededDoses / result.remainingDoses) : 0}</div>
              </div>
              <div>
                <Label className="text-sm font-medium text-muted-foreground">BAC Water Needed</Label>
                <div className="text-2xl font-bold text-primary">{liquidAmount} ml</div>
              </div>
              <div>
                <Label className="text-sm font-medium text-muted-foreground">Syringe Size</Label>
                <div className="text-2xl font-bold text-primary">{units === 'ml' ? syringeSize : `${syringeSize.replace('ml', '')}ml (${getSyringeMaxUnits()} unit)`}</div>
              </div>
            </div>

            <div className="flex gap-4">
              <Button onClick={handleSave} className="glass-button-primary">
                <Save className="h-4 w-4 mr-2" />
                Save Protocol
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

    </div>
  );
};

export default CalculatorForm;
