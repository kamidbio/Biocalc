
import React from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useAdmin } from '@/hooks/useAdmin';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { User, Settings, LogOut, Shield } from "lucide-react";
import { Link } from 'react-router-dom';

const UserMenu = () => {
  const { user, signOut } = useAuth();
  const { isAdmin } = useAdmin();

  if (!user) {
    return (
      <Link to="/auth">
        <Button variant="ghost" className="text-purple-300 hover:text-purple-200">
          Sign In
        </Button>
      </Link>
    );
  }

  const userInitials = user.email?.charAt(0).toUpperCase() || 'U';

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" className="relative h-10 w-10 rounded-full">
          <Avatar className="h-10 w-10 border-2 border-purple-400/30">
            <AvatarFallback className="bg-purple-500/20 text-purple-300">
              {userInitials}
            </AvatarFallback>
          </Avatar>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent 
        className="w-56 glass-card border-purple-400/30" 
        align="end" 
        forceMount
      >
        <DropdownMenuLabel className="font-normal">
          <div className="flex flex-col space-y-1">
            <p className="text-sm font-medium leading-none text-white">
              {user.email}
            </p>
            <p className="text-xs leading-none text-purple-300">
              {user.email}
            </p>
          </div>
        </DropdownMenuLabel>
        <DropdownMenuSeparator className="bg-purple-400/20" />
        
        {isAdmin && (
          <>
            <DropdownMenuItem asChild className="text-purple-300 hover:text-purple-200 hover:bg-purple-500/20">
              <Link to="/admin" className="flex items-center">
                <Shield className="mr-2 h-4 w-4" />
                <span>Admin Panel</span>
              </Link>
            </DropdownMenuItem>
            <DropdownMenuSeparator className="bg-purple-400/20" />
          </>
        )}
        
        <DropdownMenuItem asChild className="text-purple-300 hover:text-purple-200 hover:bg-purple-500/20">
          <Link to="/settings" className="flex items-center">
            <Settings className="mr-2 h-4 w-4" />
            <span>Settings</span>
          </Link>
        </DropdownMenuItem>
        
        <DropdownMenuSeparator className="bg-purple-400/20" />
        
        <DropdownMenuItem
          onClick={signOut}
          className="text-red-400 hover:text-red-300 hover:bg-red-500/20"
        >
          <LogOut className="mr-2 h-4 w-4" />
          <span>Log out</span>
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
};

export default UserMenu;
