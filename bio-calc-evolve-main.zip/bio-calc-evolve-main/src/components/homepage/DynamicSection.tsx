import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Calculator, Save, Stethoscope, Star, Users, TrendingUp } from 'lucide-react';
import { Link } from 'react-router-dom';

interface SectionProps {
  title: string;
  content: any;
  sectionType: string;
}

const iconMap = {
  calculator: Calculator,
  save: Save,
  stethoscope: Stethoscope,
  star: Star,
  users: Users,
  trending: TrendingUp,
};

const DynamicSection: React.FC<SectionProps> = ({ title, content, sectionType }) => {
  const renderHeroSection = () => (
    <section className="relative min-h-[70vh] flex items-center justify-center bg-gradient-to-br from-background via-background/95 to-primary/5">
      <div className="container mx-auto px-4 text-center">
        <div className="max-w-4xl mx-auto space-y-6">
          {content.heading && (
            <h1 className="text-4xl md:text-6xl font-bold bg-gradient-to-r from-foreground to-primary bg-clip-text text-transparent">
              {content.heading}
            </h1>
          )}
          {content.subheading && (
            <p className="text-xl md:text-2xl text-muted-foreground font-medium">
              {content.subheading}
            </p>
          )}
          {content.description && (
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              {content.description}
            </p>
          )}
          {content.showButton && content.buttonText && (
            <div className="pt-4">
              <Link to={content.buttonLink || '/calculator'}>
                <Button size="lg" className="text-lg px-8 py-6">
                  {content.buttonText}
                </Button>
              </Link>
            </div>
          )}
        </div>
      </div>
    </section>
  );

  const renderFeaturesSection = () => (
    <section className="py-16 bg-background">
      <div className="container mx-auto px-4">
        {content.heading && (
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">{content.heading}</h2>
            {content.description && (
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                {content.description}
              </p>
            )}
          </div>
        )}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {content.features?.map((feature: any, index: number) => {
            const IconComponent = iconMap[feature.icon as keyof typeof iconMap] || Calculator;
            return (
              <Card key={index} className="text-center hover:shadow-lg transition-all duration-300">
                <CardHeader>
                  <div className="mx-auto mb-4 p-4 rounded-full bg-primary/10 w-fit">
                    <IconComponent className="h-8 w-8 text-primary" />
                  </div>
                  <CardTitle className="text-xl">{feature.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-base">
                    {feature.description}
                  </CardDescription>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>
    </section>
  );

  const renderContentSection = () => (
    <section className="py-16 bg-muted/50">
      <div className="container mx-auto px-4">
        <div className={`grid ${content.layout === 'text-image' ? 'md:grid-cols-2' : 'grid-cols-1'} gap-12 items-center`}>
          <div className="space-y-6">
            {content.heading && (
              <h2 className="text-3xl md:text-4xl font-bold">{content.heading}</h2>
            )}
            {content.description && (
              <p className="text-lg text-muted-foreground leading-relaxed">
                {content.description}
              </p>
            )}
            {content.features && (
              <ul className="space-y-3">
                {content.features.map((feature: string, index: number) => (
                  <li key={index} className="flex items-center gap-3">
                    <div className="w-2 h-2 bg-primary rounded-full"></div>
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>
            )}
            {content.buttonText && (
              <Link to={content.buttonLink || '/calculator'}>
                <Button className="mt-4">
                  {content.buttonText}
                </Button>
              </Link>
            )}
          </div>
          {content.layout === 'text-image' && content.image && (
            <div className="order-first md:order-last">
              <img
                src={content.image}
                alt={content.heading || 'Content image'}
                className="rounded-lg shadow-lg w-full h-auto"
              />
            </div>
          )}
        </div>
      </div>
    </section>
  );

  const renderStatsSection = () => (
    <section className="py-16 bg-primary/5">
      <div className="container mx-auto px-4">
        {content.heading && (
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">{content.heading}</h2>
          </div>
        )}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {content.stats?.map((stat: any, index: number) => (
            <div key={index} className="text-center">
              <div className="text-4xl md:text-5xl font-bold text-primary mb-2">
                {stat.value}
              </div>
              <div className="text-lg text-muted-foreground">
                {stat.label}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );

  const renderCTASection = () => (
    <section className="py-16 bg-gradient-to-r from-primary to-primary/80">
      <div className="container mx-auto px-4 text-center">
        <div className="max-w-3xl mx-auto space-y-6 text-primary-foreground">
          {content.heading && (
            <h2 className="text-3xl md:text-4xl font-bold">{content.heading}</h2>
          )}
          {content.description && (
            <p className="text-lg opacity-90">{content.description}</p>
          )}
          {content.buttonText && (
            <Link to={content.buttonLink || '/calculator'}>
              <Button variant="secondary" size="lg" className="mt-4">
                {content.buttonText}
              </Button>
            </Link>
          )}
        </div>
      </div>
    </section>
  );

  const renderTestimonialsSection = () => (
    <section className="py-16 bg-background">
      <div className="container mx-auto px-4">
        {content.heading && (
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">{content.heading}</h2>
          </div>
        )}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {content.testimonials?.map((testimonial: any, index: number) => (
            <Card key={index}>
              <CardContent className="p-6">
                <p className="text-muted-foreground mb-4 italic">
                  "{testimonial.quote}"
                </p>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
                    <span className="font-semibold text-primary">
                      {testimonial.name?.charAt(0)}
                    </span>
                  </div>
                  <div>
                    <div className="font-semibold">{testimonial.name}</div>
                    <div className="text-sm text-muted-foreground">
                      {testimonial.role}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );

  const renderTextSection = () => (
    <section className="py-16 bg-background">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto text-center space-y-6">
          {content.heading && (
            <h2 className="text-3xl md:text-4xl font-bold">{content.heading}</h2>
          )}
          {content.description && (
            <p className="text-lg text-muted-foreground leading-relaxed">
              {content.description}
            </p>
          )}
        </div>
      </div>
    </section>
  );

  switch (sectionType) {
    case 'hero':
      return renderHeroSection();
    case 'features':
      return renderFeaturesSection();
    case 'content':
      return renderContentSection();
    case 'stats':
      return renderStatsSection();
    case 'cta':
      return renderCTASection();
    case 'testimonials':
      return renderTestimonialsSection();
    case 'text':
      return renderTextSection();
    default:
      return renderTextSection();
  }
};

export default DynamicSection;